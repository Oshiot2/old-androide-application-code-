package com.eston.webservice;

import android.content.Context;
import android.util.Log;

import okhttp3.Response;

public class WSGetWiFiConfigure {

    private String TAG = WSGetWiFiConfigure.class.getName();
    private Context context;
    private String message = "";
    private int status = 0;
    private boolean success;

    public WSGetWiFiConfigure(Context context) {
        this.context = context;
    }

    public int getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public boolean isSuccess() {
        return success;
    }

    public Integer executeService(String wifiName, String password) {

        final String url = WSConstants.WIFI_SETUP + "s=" + wifiName + "&p=" + password;
        Log.e(TAG, "URL ==>  " + url);
        final Response response = new WSUtils().callServiceHttpGetAuth(context, url);
        Log.e(TAG, "Response ==>  " + response);
        return parseResponse(response);
    }

    private Integer parseResponse(final Response response) {
        if (response != null) {
            message = response.message();
            status = response.code();
            if (status == (WSConstants.PARAMS_SUCCESS)) {
                success = true;
            }
        } else {
            message = "Failed to connect to";
        }
        return status;
    }
}
