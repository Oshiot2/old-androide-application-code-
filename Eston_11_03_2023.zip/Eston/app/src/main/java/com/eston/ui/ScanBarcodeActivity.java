package com.eston.ui;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.eston.R;
import com.google.zxing.Result;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ScanBarcodeActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler {
    private ZXingScannerView mScannerView;
    private String TAG = ScanBarcodeActivity.class.getName();
    private boolean isResult = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mScannerView = new ZXingScannerView(this);
        setContentView(mScannerView);
    }

    @Override
    public void onResume() {
        super.onResume();
        mScannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
        mScannerView.startCamera();          // Start camera on resume
    }

    @Override
    public void onPause() {
        super.onPause();
        mScannerView.stopCamera();           // Stop camera on pause
    }

    @Override
    public void handleResult(Result rawResult) {
        // Do something with the result here
        Log.v(TAG, rawResult.getText()); // Prints scan results
        Log.v(TAG, rawResult.getBarcodeFormat().toString()); // Prints the scan format (qrcode, pdf417 etc.)

        if (!isResult) {

            final Dialog mDialog = new Dialog(this);

            mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mDialog.setContentView(R.layout.is_it_correct_dialog);
            mDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            mDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

            TextView tvResult = mDialog.findViewById(R.id.tvResult);
            AppCompatButton btnRetry = mDialog.findViewById(R.id.btnRetry);
            Button btnYes = mDialog.findViewById(R.id.btnYes);

            tvResult.setText("Result: " + rawResult.getText());

            btnRetry.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mScannerView.resumeCameraPreview(ScanBarcodeActivity.this);
                    isResult = false;
                    mDialog.dismiss();
                }
            });

            btnYes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mDialog.dismiss();
                    Intent intent = new Intent(ScanBarcodeActivity.this,CreateNewRoomActivity.class);
                    intent.putExtra("BARCODE", rawResult.getText());
                    startActivity(intent);
                    finish();
                }
            });

            mDialog.show();

//            AlertDialog.Builder builder = new AlertDialog.Builder(ScanBarcodeActivity.this);
//            builder.setTitle("Result:- " + rawResult.getText());
//            builder.setMessage("It is correct?");
//            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                public void onClick(DialogInterface dialog, int id) {
//                    Intent resultIntent = new Intent();
//                    resultIntent.putExtra("BARCODE", rawResult.getText());
//                    setResult(Activity.RESULT_OK, resultIntent);
//                    finish();
//                }
//            });
//            builder.setNegativeButton("Retry", new DialogInterface.OnClickListener() {
//                public void onClick(DialogInterface dialog, int id) {
//                    // If you would like to resume scanning, call this method below:
//                    mScannerView.resumeCameraPreview(ScanBarcodeActivity.this);
//                    isResult = false;
//                }
//            });
//            builder.show();
        }
    }
}