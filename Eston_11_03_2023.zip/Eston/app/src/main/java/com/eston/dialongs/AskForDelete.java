package com.eston.dialongs;

public interface AskForDelete {

    void onCancelClick();

    void onOkClick();

}