package com.eston.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bartoszlipinski.recyclerviewheader2.RecyclerViewHeader;
import com.eston.EstonApp;
import com.eston.R;
import com.eston.adapter.CreateRoomDevicesListAdapter;
import com.eston.dataBase.model.Device;
import com.eston.dataBase.model.Room;
import com.eston.dialongs.PhotoSelectionAsk;
import com.eston.dialongs.PhotoSelectionListeners;
import com.eston.interfaces.ClickListener;
import com.eston.utils.Constants;
import com.eston.utils.Utils;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yalantis.ucrop.UCrop;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.eston.utils.Constants.ICON_SELECTION_ACTIVITY_REQUEST_CODE;
import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

public class CreateNewRoomActivity extends AppCompatActivity implements ClickListener {

    private String TAG = CreateNewRoomActivity.class.getName();
    private static final int SECOND_ACTIVITY_REQUEST_CODE = 101;

    private Context mContext;
    private Toolbar toolbar;
    private TextView toolbar_Title;
    private RecyclerView recyclerView;
    //    private FloatingActionButton addNewDevice;
    private ImageView addRoomImage, iv_room_image;
    ArrayList<Device> deviceList = new ArrayList<>();
    CreateRoomDevicesListAdapter roomDevicesListAdapter;
    private File destination;
    private Uri imageToUploadUri;
    private String filePath = "";
    private String room_mad = "";
    private String roomMode = "";
    //    private String HUBID = "";
    private String MACID = "";
    private ProgressDialog progressDialog;
    private long mLastClickTime = 0;

    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;
    private MqttHelper mqttHelper;

    private Button btnSave;

    @Override
    public void onBackPressed() {
        // super.onBackPressed();
        overridePendingTransition(R.anim.anim_trans_right_in, R.anim.anim_trans_right_out);
        if (mqttHelper != null)
//            mqttHelper.unSubscribeTopic("eston/" + MACID + "/relayscan/response");
            mqttHelper.unSubscribeTopic("/" + MACID + "/RES");
        Intent returnIntent = new Intent();
        setResult(Constants.ROOM_ACTIVITY_RESULT_CODE, returnIntent);
        finish();
    }

    private void getIntentData() {
        if (getIntent() != null) {
            MACID = getIntent().getStringExtra("BARCODE").substring(0, getIntent().getStringExtra("BARCODE").length() - 2);
            Log.e(TAG, "getIntentData()MACID: " + MACID);
            saveMacId(MACID);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_creat_new_room3);

        mContext = this;



        /*
         * Init Toolbar
         * */
        initToolbar();

        /*
         * Init View
         * */
        initView();

        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference("users");
        mFirebaseDatabase.keepSynced(true);

        /*
         * Get Intent Data
         * */
        getIntentData();

//        checkHubAdded();

    }


    private void initToolbar() {
//        toolbar = findViewById(R.id.toolbar);
        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

//        toolbar_Title = toolbar.findViewById(R.id.txt_title);
//        toolbar_Title.setText("Create New Room");

    }

    private void initView() {
        recyclerView = findViewById(R.id.devices_recyclerview);
//        addNewDevice = findViewById(R.id.fab_Add_New_Device);
        iv_room_image = findViewById(R.id.iv_room_image);
        addRoomImage = findViewById(R.id.iv_add_room_image);
        btnSave = findViewById(R.id.btnSave);

        recyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        roomDevicesListAdapter = new CreateRoomDevicesListAdapter(mContext, deviceList, CreateNewRoomActivity.this);
        recyclerView.setAdapter(roomDevicesListAdapter);

//        RecyclerViewHeader recyclerHeader = (RecyclerViewHeader) findViewById(R.id.header);
//        recyclerHeader.attachTo(recyclerView);

        Intent intent = getIntent();
        if (intent != null) {
            if (intent.hasExtra("BARCODE")) {
                String returnString = intent.getStringExtra("BARCODE");
                Log.e(TAG, "returnString " + returnString);
                setRoom(returnString);
            }
        }


//        addNewDevice.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                try {
//                    Intent intent = new Intent(CreateNewRoomActivity.this, ScanBarcodeActivity.class);
//                    startActivityForResult(intent, SECOND_ACTIVITY_REQUEST_CODE);
//
////                    if (SystemClock.elapsedRealtime() - mLastClickTime < 5000) {
////                        return;
////                    }
////                    mLastClickTime = SystemClock.elapsedRealtime();
////
////                    progressDialog = Utils.showProgressDialog(mContext, "Checking for new room..", false);
////                    mqttHelper.publishTopicWithListener("/eston/" + HUBID + "/query", "1", new IMqttActionListener() {
////                        @Override
////                        public void onSuccess(IMqttToken asyncActionToken) {
////                            Log.e(TAG, "=======publishTopicWithListener========== onSuccess " + asyncActionToken.getClient().getServerURI());
////                            Utils.dismissProgressDialog(progressDialog);
////                        }
////
////                        @Override
////                        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
////                            Utils.dismissProgressDialog(progressDialog);
////                            Toast.makeText(mContext, "Can not able to get scan new device", Toast.LENGTH_LONG).show();
////                        }
////                    });
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });

        addRoomImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SystemClock.elapsedRealtime() - mLastClickTime < 2000) {
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                if (Utils.checkPermission(CreateNewRoomActivity.this)) {
                    PhotoSelectionAsk photoSelectionAsk = new PhotoSelectionAsk(mContext, "Header Photo", new PhotoSelectionListeners() {
                        @Override
                        public void onCameraClick() {
                            captureImageFromCamera();
                        }

                        @Override
                        public void onGalleryClick() {
                            selectImageFromGallery();
                        }

                        @Override
                        public void onRemoveClick() {
                            filePath = "";
                            destination = null;
                            imageToUploadUri = null;
                            iv_room_image.setImageDrawable(getResources().getDrawable(R.drawable.bed_room));
                        }
                    });
                    photoSelectionAsk.show();

                }
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("CheckResult")
            @Override
            public void onClick(View view) {
                if (SystemClock.elapsedRealtime() - mLastClickTime < 2000) {
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                if (TextUtils.isEmpty(roomDevicesListAdapter.roomName)) {
                    Toast.makeText(mContext, "Please enter room name", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (deviceList.size() <= 0) {
                    Toast.makeText(mContext, "Please scan device first", Toast.LENGTH_SHORT).show();
                    return;
                }

                for (int i = 0; i < deviceList.size(); i++) {
                    if (TextUtils.isEmpty(deviceList.get(i).deviceName)) {
                        Toast.makeText(mContext, "Please enter device name at position " + (i + 1), Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                progressDialog = Utils.showProgressDialog(mContext, getString(R.string.msg_loading), false);

                Room room = new Room();
                room.uid = EstonApp.preferenceGetString(PREF_USER_UID, "");
                room.roomUUID = room_mad;
                room.roomImage = filePath;
                room.roomName = roomDevicesListAdapter.roomName;

                for (int i = 0; i < deviceList.size(); i++) {
                    deviceList.get(i).did = i;
                    deviceList.get(i).uid = EstonApp.preferenceGetString(PREF_USER_UID, "");
                    deviceList.get(i).rid = room_mad;
                }

                DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.ROOMS_TABLE.ROOMS).child(room_mad);

                namesRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        if (snapshot.getValue() == null) {
                            Map<String, Object> map = new HashMap<>();
                            map.put(Constants.ROOMS_TABLE.UID, EstonApp.preferenceGetString(PREF_USER_UID, ""));
                            map.put(Constants.ROOMS_TABLE.UUID, room_mad);
                            map.put(Constants.ROOMS_TABLE.NAME, roomDevicesListAdapter.roomName);
                            map.put(Constants.ROOMS_TABLE.IMAGE, filePath);
                            Log.e(TAG, "map " + map);

                            namesRef.updateChildren(map);
                            namesRef.child(Constants.ROOMS_TABLE.DEVICES).setValue(deviceList);

                            Log.e(TAG, "btnSaveMACID:: " + MACID);
                            Log.e(TAG, "roomDevicesListAdapter.roomName:: " + roomDevicesListAdapter.roomName);
                            Log.e(TAG, "roomMode:: " + roomMode);
                            Log.e(TAG, "room_mad:: " + room_mad);
//                            mqttHelper.publishTopic("/eston/" + MACID + "/newroom/submit",
//                                    roomDevicesListAdapter.roomName + "&" + roomMode + "&" + room_mad);
                            mqttHelper.publishTopic(MACID,roomDevicesListAdapter.roomName + "&" + roomMode + "&" + room_mad);
                            Utils.dismissProgressDialog(progressDialog);
                            onBackPressed();

//                            namesRef.updateChildren(map).addOnSuccessListener(new OnSuccessListener<Void>() {
//                                @Override
//                                public void onSuccess(Void runnable) {
//                                    namesRef.child(Constants.ROOMS_TABLE.DEVICES).setValue(deviceList)
//                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
//                                                @Override
//                                                public void onSuccess(Void runnable) {
//                                                    mqttHelper.publishTopic("/eston/" + HUBID + "/newroom/submit",
//                                                            roomDevicesListAdapter.roomName + "&" + roomMode + "&" + room_mad);
//                                                    Utils.dismissProgressDialog(progressDialog);
//                                                    onBackPressed();
//                                                }
//                                            })
//                                            .addOnFailureListener(new OnFailureListener() {
//                                                @Override
//                                                public void onFailure(@NonNull Exception runnable) {
//                                                    Utils.dismissProgressDialog(progressDialog);
//                                                    Toast.makeText(mContext, "Error " + runnable.getMessage(), Toast.LENGTH_SHORT).show();
//                                                }
//                                            });
//                                }
//                            }).addOnFailureListener(new OnFailureListener() {
//                                @Override
//                                public void onFailure(@NonNull Exception runnable) {
//                                    Utils.dismissProgressDialog(progressDialog);
//                                    Toast.makeText(mContext, "Error " + runnable.getMessage(), Toast.LENGTH_SHORT).show();
//                                }
//                            });
                        } else {
                            Utils.dismissProgressDialog(progressDialog);
                            Toast.makeText(mContext, "This room is already exist in your account.", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Utils.dismissProgressDialog(progressDialog);
                        Toast.makeText(mContext, "Error " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void checkHubAdded() {
        String firebaseUserId = EstonApp.preferenceGetString(PREF_USER_UID, "");
        DatabaseReference userRef = mFirebaseDatabase.child(firebaseUserId).child(Constants.SETTINGS.SETTINGS);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    Object td = dataSnapshot.getValue();
                    HashMap<String, String> settings = (HashMap<String, String>) td;
                    Log.e(TAG, "settings " + settings);
                    if (settings != null && !Objects.requireNonNull(settings.get(Constants.SETTINGS.MACID)).isEmpty()) {
                        MACID = settings.get(Constants.SETTINGS.MACID);
                        Log.e(TAG, "checkHubAdded()MACID::: " + MACID);
                        initMqtt();
                    } else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        builder.setTitle("Error");
                        builder.setMessage("Can't fetch Mac ID from server. Please try again later!!");
                        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                onBackPressed();
                            }
                        });
                        builder.show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "error " + error.getMessage());
            }
        });
    }

    private void saveMacId(String MacID) {
        if (Utils.isNetworkAvailable(this)) {
            progressDialog = Utils.showProgressDialog(this, "Saving data...", false);
            HashMap<String, Object> result = new HashMap<>();
            result.put(Constants.SETTINGS.MACID, MacID);
            mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                    .child(Constants.SETTINGS.SETTINGS)
                    .updateChildren(result, new DatabaseReference.CompletionListener() {
                        @Override
                        public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                            Utils.dismissProgressDialog(progressDialog);
                            if (databaseError != null) {
                                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), databaseError.getMessage(), true, CreateNewRoomActivity.this);
                            } else {
                                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Saved successfully", false, CreateNewRoomActivity.this);

                                initMqtt();
//                                checkHubAdded();
                            }
                        }
                    });
        }
    }

    //TODO Remove plug at initialization
    private void initMqtt() {
        try {
            mqttHelper = EstonApp.getMqttHelper();
//            mqttHelper.subscribeTopic("/eston/" + MACID + "/relayscan/response");
            mqttHelper.subscribeTopic("/" + MACID + "/RES");
            mqttHelper.setCallback(new MqttCallbackExtended() {
                @Override
                public void connectComplete(boolean reconnect, String serverURI) {
                    Log.e(TAG, "=======connectComplete========== reconnect " + reconnect + " serverURI " + serverURI);
                }

                @Override
                public void connectionLost(Throwable cause) {
                    Log.e(TAG, "=======connectionLost==========" + cause);
                }

                @Override
                public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                    try {
                        Log.e(TAG, "=======topic==========" + topic);
                        Log.e(TAG, "=======messageArrived==========" + mqttMessage);
                        String data = "";
                        String mode = ""; //R0123456789102@
                        if (mqttMessage.toString().length() == 15) {
                            data = mqttMessage.toString().substring((mqttMessage.toString().indexOf("R") + 1), mqttMessage.toString().indexOf("@"));
                            Log.e(TAG, "data " + data);
                            room_mad = data.substring(0, 12);
                            Log.e(TAG, "data " + room_mad);
//                            mode = String.valueOf(data.charAt(data.length() - 1));
                            mode = data.substring(data.length() - 2);
                            Log.e(TAG, "mode " + mode);
                        }
//                        if (topic.equals("/eston/" + MACID + "/relayscan/response")) {
                        if (topic.equals("/" + MACID + "/RES")) {
                            deviceList = new ArrayList<>();
                            roomMode = mode;
                            switch (mode) {
                                case ("00"):
                                    for (int i = 0; i < 1; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }
                                    break;
                                case ("01"):
                                    for (int i = 0; i < 2; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }
                                    break;
                                case ("02"): {
                                    deviceList = new ArrayList<>();
                                    for (int i = 0; i < 4; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }
//                                    Device asd1 = new Device();
//                                    asd1.deviceName = "Plug";
//                                    asd1.deviceOnOffState = 0;
//                                    asd1.devicePOS = 3;
//                                    asd1.deviceImage = 1;
//                                    asd1.deviceType = 0;
//                                    deviceList.add(asd1);
                                    break;
                                }
                                case ("03"): {
                                    deviceList = new ArrayList<>();
                                    for (int i = 0; i < 4; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }
//                                    Device asd1 = new Device();
//                                    asd1.deviceName = "Plug";
//                                    asd1.deviceOnOffState = 0;
//                                    asd1.devicePOS = 3;
//                                    asd1.deviceImage = 1;
//                                    asd1.deviceType = 0;
//                                    deviceList.add(asd1);

                                    Device asd2 = new Device();
                                    asd2.deviceName = "Fan";
                                    asd2.deviceOnOffState = 0;
                                    asd2.deviceFanCurrentValue = 1;
                                    asd2.devicePOS = 12;
                                    asd2.deviceType = 1;
                                    asd2.deviceImage = 2;
                                    deviceList.add(asd2);
                                    break;
                                }
                                case ("04"): {
                                    deviceList = new ArrayList<>();
                                    for (int i = 0; i < 6; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }
//                                    Device asd1 = new Device();
//                                    asd1.deviceName = "Plug";
//                                    asd1.deviceOnOffState = 0;
//                                    asd1.devicePOS = 5;
//                                    asd1.deviceImage = 1;
//                                    asd1.deviceType = 0;
//                                    deviceList.add(asd1);

                                    Device asd2 = new Device();
                                    asd2.deviceName = "Fan";
                                    asd2.deviceOnOffState = 0;
                                    asd2.devicePOS = 12;
                                    asd2.deviceFanCurrentValue = 1;
                                    asd2.deviceType = 1;
                                    asd2.deviceImage = 2;
                                    deviceList.add(asd2);
                                    break;
                                }
                                case ("05"): {
                                    deviceList = new ArrayList<>();
                                    for (int i = 0; i < 10; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }
//                                    Device asd1 = new Device();
//                                    asd1.deviceName = "Plug";
//                                    asd1.deviceOnOffState = 0;
//                                    asd1.devicePOS = 5;
//                                    asd1.deviceImage = 1;
//                                    asd1.deviceType = 0;
//                                    deviceList.add(asd1);
//
//                                    Device asd3 = new Device();
//                                    asd3.deviceName = "Fan";
//                                    asd3.deviceOnOffState = 0;
//                                    asd3.devicePOS = 6;
//                                    asd3.deviceFanCurrentValue = 1;
//                                    asd3.deviceType = 1;
//                                    asd3.deviceImage = 2;
//                                    deviceList.add(asd3);
//
//                                    Device asd0 = new Device();
//                                    asd0.deviceName = "Switch";
//                                    asd0.deviceOnOffState = 0;
//                                    asd0.devicePOS = 7;
//                                    asd0.deviceImage = 0;
//                                    asd0.deviceType = 0;
//                                    deviceList.add(asd0);
//
//                                    Device asd2 = new Device();
//                                    asd2.deviceName = "Plug";
//                                    asd2.deviceOnOffState = 0;
//                                    asd2.devicePOS = 8;
//                                    asd2.deviceImage = 1;
//                                    asd2.deviceType = 0;
//                                    deviceList.add(asd2);
//
//                                    Device asd4 = new Device();
//                                    asd4.deviceName = "Fan";
//                                    asd4.deviceOnOffState = 0;
//                                    asd4.devicePOS = 13;
//                                    asd4.deviceFanCurrentValue = 1;
//                                    asd4.deviceType = 1;
//                                    asd4.deviceImage = 2;
//                                    deviceList.add(asd4);
                                    break;
                                }
                                case ("06"): {
                                    deviceList = new ArrayList<>();
                                    for (int i = 0; i < 8; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }

//                                    Device asd1 = new Device();
//                                    asd1.deviceName = "Plug";
//                                    asd1.deviceOnOffState = 0;
//                                    asd1.devicePOS = 5;
//                                    asd1.deviceImage = 1;
//                                    asd1.deviceType = 0;
//                                    deviceList.add(asd1);
//
//                                    Device asd3 = new Device();
//                                    asd3.deviceName = "Fan";
//                                    asd3.deviceOnOffState = 0;
//                                    asd3.devicePOS = 6;
//                                    asd3.deviceFanCurrentValue = 1;
//                                    asd3.deviceType = 1;
//                                    asd3.deviceImage = 2;
//                                    deviceList.add(asd3);
//
//                                    for (int i = 0; i < 5; i++) {
//                                        Device asd = new Device();
//                                        asd.deviceName = "Switch";
//                                        asd.deviceOnOffState = 0;
//                                        asd.devicePOS = (7 + i);
//                                        asd.deviceImage = 0;
//                                        asd.deviceType = 0;
//                                        deviceList.add(asd);
//                                    }
//
//                                    Device asd2 = new Device();
//                                    asd2.deviceName = "Plug";
//                                    asd2.deviceOnOffState = 0;
//                                    asd2.devicePOS = 12;
//                                    asd2.deviceImage = 1;
//                                    asd2.deviceType = 0;
//                                    deviceList.add(asd2);
//
//                                    Device asd4 = new Device();
//                                    asd4.deviceName = "Fan";
//                                    asd4.deviceOnOffState = 0;
//                                    asd4.devicePOS = 13;
//                                    asd4.deviceFanCurrentValue = 1;
//                                    asd4.deviceType = 1;
//                                    asd4.deviceImage = 2;
//                                    deviceList.add(asd4);
                                    for (int i = 12; i < 14; i++) {
                                        Device asd4 = new Device();
                                        asd4.deviceName = "Fan";
                                        asd4.deviceOnOffState = 0;
                                        asd4.devicePOS = i;
                                        asd4.deviceFanCurrentValue = 1;
                                        asd4.deviceType = 1;
                                        asd4.deviceImage = 2;
                                        deviceList.add(asd4);
                                    }
                                    break;
                                }
                                case ("07"): {
                                    deviceList = new ArrayList<>();
                                    for (int i = 0; i < 12; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }

                                    for (int i = 12; i < 14; i++) {
                                        Device asd4 = new Device();
                                        asd4.deviceName = "Fan";
                                        asd4.deviceOnOffState = 0;
                                        asd4.devicePOS = i;
                                        asd4.deviceFanCurrentValue = 1;
                                        asd4.deviceType = 1;
                                        asd4.deviceImage = 2;
                                        deviceList.add(asd4);
                                    }
                                    break;
                                }
                                case ("08"): {
                                    deviceList = new ArrayList<>();
                                    for (int i = 0; i < 8; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }


                                    Device asd4 = new Device();
                                    asd4.deviceName = "Fan";
                                    asd4.deviceOnOffState = 0;
                                    asd4.devicePOS = 12;
                                    asd4.deviceFanCurrentValue = 1;
                                    asd4.deviceType = 1;
                                    asd4.deviceImage = 2;
                                    deviceList.add(asd4);

                                    break;
                                }
                                case ("09"): {
                                    deviceList = new ArrayList<>();
                                    for (int i = 0; i < 10; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }

                                    Device asd4 = new Device();
                                    asd4.deviceName = "Fan";
                                    asd4.deviceOnOffState = 0;
                                    asd4.devicePOS = 12;
                                    asd4.deviceFanCurrentValue = 1;
                                    asd4.deviceType = 1;
                                    asd4.deviceImage = 2;
                                    deviceList.add(asd4);
                                    break;
                                }
                                case ("10"): {
                                    deviceList = new ArrayList<>();
                                    for (int i = 0; i < 10; i++) {
                                        Device asd = new Device();
                                        asd.deviceName = "Switch";
                                        asd.deviceOnOffState = 0;
                                        asd.devicePOS = i;
                                        asd.deviceImage = 0;
                                        asd.deviceType = 0;
                                        deviceList.add(asd);
                                    }


                                    for (int i = 12; i < 14; i++) {
                                        Device asd4 = new Device();
                                        asd4.deviceName = "Fan";
                                        asd4.deviceOnOffState = 0;
                                        asd4.devicePOS = i;
                                        asd4.deviceFanCurrentValue = 1;
                                        asd4.deviceType = 1;
                                        asd4.deviceImage = 2;
                                        deviceList.add(asd4);
                                    }

                                    break;
                                }
                            }
                            roomDevicesListAdapter = new CreateRoomDevicesListAdapter(mContext, deviceList, CreateNewRoomActivity.this);
                            recyclerView.setAdapter(roomDevicesListAdapter);
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "ERROR " + e.getMessage());
                        e.printStackTrace();
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    Log.e(TAG, "=======deliveryComplete========== " + token.getClient().getServerURI());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Capture Image from Camera
    private void captureImageFromCamera() {

        Intent chooserIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File directory = Utils.getRootDir(Constants.DIRECTORY.PROFILE_DIR, Constants.DIRECTORY.IMAGE_DIR);
        destination = new File(directory, setImageName());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
            imageToUploadUri = FileProvider.getUriForFile(mContext, getApplicationContext().getPackageName() + ".provider", destination);
        else {
            imageToUploadUri = Uri.fromFile(destination);
        }
        chooserIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageToUploadUri);
        chooserIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        chooserIntent.putExtra("return-data", true);
        startActivityForResult(chooserIntent, Constants.PHOTO_CONST.TYPE_PHOTO_PICK_FROM_CAMERA);
        overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);

    }

    // Select Image from Gallery
    private void selectImageFromGallery() {

        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Complete action using"), Constants.PHOTO_CONST.TYPE_PHOTO_PICK_FROM_FILE);
        overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);

    }

    private String setImageName() {
        String name = "";
        String imgExt = ".jpg";
        name = Utils.getDateString() + imgExt;
        return name;
    }

    @Override
    public void onItemClick(View view, int position) {
        Intent i = new Intent(this, IconSelectionActivity.class);
        i.putExtra("position", position);
        startActivityForResult(i, ICON_SELECTION_ACTIVITY_REQUEST_CODE);
        overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
    }

    private void setRoom(String data) {

        if (data.length() == 14) {
            Log.e(TAG, "data " + data);
            room_mad = data.substring(0, 12);
            Log.e(TAG, "room_mad " + room_mad);
//            String mode = String.valueOf(data.charAt(data.length() - 1));
            String mode = data.substring(data.length() - 2);
            Log.e(TAG, "mode " + mode);

            deviceList = new ArrayList<>();
            roomMode = mode;

            if (Integer.parseInt(mode) > 10) {
                Toast.makeText(getApplicationContext(), "Invalid Mode", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            switch (mode) {
                case ("00"):
                    for (int i = 0; i < 1; i++) {
                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }
                    break;
                case ("01"):
                    for (int i = 0; i < 2; i++) {
                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }
                    break;
                case ("02"): {
                    deviceList = new ArrayList<>();
                    for (int i = 0; i < 4; i++) {
                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }
//                    Device asd1 = new Device();
//                    asd1.deviceName = "Plug";
//                    asd1.deviceOnOffState = 0;
//                    asd1.devicePOS = 3;
//                    asd1.deviceImage = 1;
//                    asd1.deviceType = 0;
//                    deviceList.add(asd1);

                    break;
                }
                case ("03"): {
                    deviceList = new ArrayList<>();
                    for (int i = 0; i < 4; i++) {

                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }
//                    Device asd1 = new Device();
//                    asd1.deviceName = "Plug";
//                    asd1.deviceOnOffState = 0;
//                    asd1.devicePOS = 3;
//                    asd1.deviceImage = 1;
//                    asd1.deviceType = 0;
//                    deviceList.add(asd1);

                    Device asd2 = new Device();
                    asd2.deviceName = "Fan";
                    asd2.deviceOnOffState = 0;
                    asd2.deviceFanCurrentValue = 1;
                    asd2.devicePOS = 12;
                    asd2.deviceType = 1;
                    asd2.deviceImage = 2;
                    deviceList.add(asd2);
                    break;
                }
                case ("04"): {
                    deviceList = new ArrayList<>();
                    for (int i = 0; i < 6; i++) {
                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }
//                    Device asd1 = new Device();
//                    asd1.deviceName = "Plug";
//                    asd1.deviceOnOffState = 0;
//                    asd1.devicePOS = 5;
//                    asd1.deviceImage = 1;
//                    asd1.deviceType = 0;
//                    deviceList.add(asd1);

                    Device asd2 = new Device();
                    asd2.deviceName = "Fan";
                    asd2.deviceOnOffState = 0;
                    asd2.devicePOS = 12;
                    asd2.deviceFanCurrentValue = 1;
                    asd2.deviceType = 1;
                    asd2.deviceImage = 2;
                    deviceList.add(asd2);
                    break;
                }
                case ("05"): {
                    deviceList = new ArrayList<>();
                    for (int i = 0; i < 10; i++) {
                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }
//                    Device asd1 = new Device();
//                    asd1.deviceName = "Plug";
//                    asd1.deviceOnOffState = 0;
//                    asd1.devicePOS = 5;
//                    asd1.deviceImage = 1;
//                    asd1.deviceType = 0;
//                    deviceList.add(asd1);
//
//                    Device asd3 = new Device();
//                    asd3.deviceName = "Fan";
//                    asd3.deviceOnOffState = 0;
//                    asd3.devicePOS = 6;
//                    asd3.deviceFanCurrentValue = 1;
//                    asd3.deviceType = 1;
//                    asd3.deviceImage = 2;
//                    deviceList.add(asd3);
//
//                    Device asd0 = new Device();
//                    asd0.deviceName = "Switch";
//                    asd0.deviceOnOffState = 0;
//                    asd0.devicePOS = 7;
//                    asd0.deviceImage = 0;
//                    asd0.deviceType = 0;
//                    deviceList.add(asd0);
//
//                    Device asd2 = new Device();
//                    asd2.deviceName = "Plug";
//                    asd2.deviceOnOffState = 0;
//                    asd2.devicePOS = 8;
//                    asd2.deviceImage = 1;
//                    asd2.deviceType = 0;
//                    deviceList.add(asd2);
//
//                    Device asd4 = new Device();
//                    asd4.deviceName = "Fan";
//                    asd4.deviceOnOffState = 0;
//                    asd4.devicePOS = 13;
//                    asd4.deviceFanCurrentValue = 1;
//                    asd4.deviceType = 1;
//                    asd4.deviceImage = 2;
//                    deviceList.add(asd4);
                    break;
                }
                case ("06"): {
                    deviceList = new ArrayList<>();
                    for (int i = 0; i < 8; i++) {
                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }

//                    Device asd1 = new Device();
//                    asd1.deviceName = "Plug";
//                    asd1.deviceOnOffState = 0;
//                    asd1.devicePOS = 5;
//                    asd1.deviceImage = 1;
//                    asd1.deviceType = 0;
//                    deviceList.add(asd1);

//                    Device asd3 = new Device();
//                    asd3.deviceName = "Fan";
//                    asd3.deviceOnOffState = 0;
//                    asd3.devicePOS = 6;
//                    asd3.deviceFanCurrentValue = 1;
//                    asd3.deviceType = 1;
//                    asd3.deviceImage = 2;
//                    deviceList.add(asd3);

//                    for (int i = 0; i < 5; i++) {
//                        Device asd = new Device();
//                        asd.deviceName = "Switch";
//                        asd.deviceOnOffState = 0;
//                        asd.devicePOS = (7 + i);
//                        asd.deviceImage = 0;
//                        asd.deviceType = 0;
//                        deviceList.add(asd);
//                    }
//
//                    Device asd2 = new Device();
//                    asd2.deviceName = "Plug";
//                    asd2.deviceOnOffState = 0;
//                    asd2.devicePOS = 12;
//                    asd2.deviceImage = 1;
//                    asd2.deviceType = 0;
//                    deviceList.add(asd2);

                    for (int i = 12; i < 14; i++) {
                        Device asd4 = new Device();
                        asd4.deviceName = "Fan";
                        asd4.deviceOnOffState = 0;
                        asd4.devicePOS = i;
                        asd4.deviceFanCurrentValue = 1;
                        asd4.deviceType = 1;
                        asd4.deviceImage = 2;
                        deviceList.add(asd4);
                    }
                    break;
                }
                case ("07"): {
                    deviceList = new ArrayList<>();
                    for (int i = 0; i < 12; i++) {
                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }

                    for (int i = 12; i < 14; i++) {
                        Device asd4 = new Device();
                        asd4.deviceName = "Fan";
                        asd4.deviceOnOffState = 0;
                        asd4.devicePOS = i;
                        asd4.deviceFanCurrentValue = 1;
                        asd4.deviceType = 1;
                        asd4.deviceImage = 2;
                        deviceList.add(asd4);
                    }
                    break;
                }
                case ("08"): {
                    deviceList = new ArrayList<>();
                    for (int i = 0; i < 8; i++) {
                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }


                    Device asd4 = new Device();
                    asd4.deviceName = "Fan";
                    asd4.deviceOnOffState = 0;
                    asd4.devicePOS = 12;
                    asd4.deviceFanCurrentValue = 1;
                    asd4.deviceType = 1;
                    asd4.deviceImage = 2;
                    deviceList.add(asd4);

                    break;
                }
                case ("09"): {
                    deviceList = new ArrayList<>();
                    for (int i = 0; i < 10; i++) {
                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }

                    Device asd4 = new Device();
                    asd4.deviceName = "Fan";
                    asd4.deviceOnOffState = 0;
                    asd4.devicePOS = 12;
                    asd4.deviceFanCurrentValue = 1;
                    asd4.deviceType = 1;
                    asd4.deviceImage = 2;
                    deviceList.add(asd4);
                    break;
                }
                case ("10"): {
                    deviceList = new ArrayList<>();
                    for (int i = 0; i < 10; i++) {
                        Device asd = new Device();
                        asd.deviceName = "Switch";
                        asd.deviceOnOffState = 0;
                        asd.devicePOS = i;
                        asd.deviceImage = 0;
                        asd.deviceType = 0;
                        deviceList.add(asd);
                    }


                    for (int i = 12; i < 14; i++) {
                        Device asd4 = new Device();
                        asd4.deviceName = "Fan";
                        asd4.deviceOnOffState = 0;
                        asd4.devicePOS = i;
                        asd4.deviceFanCurrentValue = 1;
                        asd4.deviceType = 1;
                        asd4.deviceImage = 2;
                        deviceList.add(asd4);
                    }

                    break;
                }
            }
            roomDevicesListAdapter = new CreateRoomDevicesListAdapter(mContext, deviceList, CreateNewRoomActivity.this);
            recyclerView.setAdapter(roomDevicesListAdapter);
        } else {
            new AlertDialog.Builder(CreateNewRoomActivity.this)
                    .setMessage("Please scan proper room!")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                        }
                    })
                    .show();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "onActivityResult requestCode " + requestCode + " resultCode " + resultCode);
//        if (requestCode == SECOND_ACTIVITY_REQUEST_CODE) {
//            if (resultCode == RESULT_OK) {
//                // Get String data from Intent
//                String returnString = data.getStringExtra("BARCODE");
//                Log.e(TAG, "returnString " + returnString);
//                setRoom(returnString);
//            }
//        } else
        if (requestCode == ICON_SELECTION_ACTIVITY_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                Integer position = data.getIntExtra("position", 0);
                Integer result = data.getIntExtra("result", 0);
                deviceList.get(position).deviceImage = result;
                roomDevicesListAdapter.notifyItemChanged(position + 1);
            }
        } else if (requestCode == Constants.PHOTO_CONST.TYPE_PHOTO_PICK_FROM_CAMERA && resultCode == RESULT_OK) {
            if (imageToUploadUri != null) {
                String mFilePath = destination.getPath();
                imageToUploadUri = Uri.fromFile(new File(mFilePath));
                doCrop();
            }
        } else if (requestCode == Constants.PHOTO_CONST.TYPE_PHOTO_PICK_FROM_FILE && resultCode == RESULT_OK) {

            String mFilePath = Utils.getRealPathFromURI(mContext, data.getData());
            if (!TextUtils.isEmpty(mFilePath)) {
                imageToUploadUri = Uri.fromFile(new File(mFilePath));
                doCrop();
            } else {
                Toast.makeText(mContext, "Can't find file", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == UCrop.REQUEST_CROP && resultCode == RESULT_OK) {
            try {
                String imgProfilePath = imageToUploadUri.getPath();
                if (imgProfilePath != null) {
                    filePath = imgProfilePath;
                    iv_room_image.setImageURI(Uri.fromFile(new File(filePath)));
                } else {
                    Toast.makeText(mContext, "Can't find file", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Crop Image
     */
    private void doCrop() {
        UCrop.of(imageToUploadUri, imageToUploadUri)
                .withAspectRatio(3, 2)
                .start(CreateNewRoomActivity.this);

    }

}
