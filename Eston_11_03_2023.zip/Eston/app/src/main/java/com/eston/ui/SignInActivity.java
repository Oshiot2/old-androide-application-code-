package com.eston.ui;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.text.method.SingleLineTransformationMethod;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.eston.EstonApp;
import com.eston.R;
import com.eston.utils.Utils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;


public class SignInActivity extends AppCompatActivity {

    private String TAG = SignInActivity.class.getName();

    private ProgressDialog progressDialog;
    TextInputEditText edtEmailAddress;
    TextInputEditText edtPassword;
    Button SignIn;
    TextView Signup, txt_forgotpass;
    CheckBox cbPassword;

    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_signin2);

        edtEmailAddress = findViewById(R.id.edtEmailid);
        edtPassword = findViewById(R.id.edtPassword);
        SignIn = findViewById(R.id.btn_SignIn);
        txt_forgotpass = findViewById(R.id.txt_forgotpass);
        Signup = findViewById(R.id.txt_SignUp_LoginActivity);
        cbPassword = findViewById(R.id.cbPassword);

        //initialise firebase
        initFirebase();

        cbPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtPassword.getTransformationMethod().getClass().getSimpleName().equals("PasswordTransformationMethod")) {
                    edtPassword.setTransformationMethod(new SingleLineTransformationMethod());
                } else {
                    edtPassword.setTransformationMethod(new PasswordTransformationMethod());
                }
                edtPassword.setSelection(edtPassword.getText().length());
            }
        });

        SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isValidData()) {

                    if (Build.VERSION.SDK_INT >= 23) {
                        setPermission();
                    } else {
                        startSetUpActivity();
                    }
                }
            }
        });
        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignInActivity.this, SignUpActivity.class));
//                overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
            }
        });
        txt_forgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignInActivity.this, ForgotPasswordActivity.class));
//                overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
            }
        });
    }

    private void initFirebase() {
        //Get Firebase auth instance
        auth = FirebaseAuth.getInstance();
    }


    private void setPermission() {
        Utils.setRunTimePermission(SignInActivity.this);

        if (ActivityCompat.checkSelfPermission(SignInActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(SignInActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startSetUpActivity();
        }
    }

    private void startSetUpActivity() {
        if (Utils.isOnline(this)) {
            //show progress bar
            progressDialog = Utils.showProgressDialog(this, getString(R.string.msg_loading), false);

            String email = edtEmailAddress.getText().toString().trim();
            String password = edtPassword.getText().toString().trim();

            auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(SignInActivity.this,
                            new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    //dismiss progressbar
                                    Utils.dismissProgressDialog(progressDialog);

                                    // If sign in fails, display a message to the user. If sign in succeeds
                                    // the auth state listener will be notified and logic to handle the
                                    // signed in user can be handled in the listener.
                                    if (!task.isSuccessful()) {
                                        //display message like user is already register
                                        // or your account disable from firebase

                                        Log.e(TAG, " task.getException() " + task.getException());
                                        Toast.makeText(SignInActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    } else {
                                        EstonApp.preferencePutString(PREF_USER_UID, task.getResult().getUser().getUid());
                                        startActivity(new Intent(SignInActivity.this, MainActivity.class));
                                        overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
                                        finish();
                                    }
                                }
                            });
        } else {
            Toast.makeText(this, getResources().getString(R.string.No_internet_available), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        // If request is cancelled, the result arrays are empty.
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startSetUpActivity();
        }
    }

    private boolean isValidData() {
        String msg = "";
        boolean error = false;
        if (edtEmailAddress.getText().toString().isEmpty()) {
            error = true;
            msg = getString(R.string.please_enter) + " " + getString(R.string.email_address).toLowerCase();
            edtEmailAddress.requestFocus();
        } else if (!Utils.validateEmail(edtEmailAddress.getText().toString().trim())) {
            error = true;
            msg = getString(R.string.please_enter) + " " + getString(R.string.valid_email_address).toLowerCase();
            edtEmailAddress.requestFocus();
        } else if (edtPassword.getText().toString().isEmpty()) {
            error = true;
            msg = getString(R.string.please_enter) + " " + getString(R.string.password).toLowerCase();
            edtPassword.requestFocus();
        } else if (edtPassword.getText().toString().length() < 5) {
            error = true;
            msg = getString(R.string.password_should_be_eight_character_including_upper_case_lower_case_number_and_special_character);
        }

        if (msg.isEmpty()) {
            error = false;
        } else {
            error = true;
            Toast.makeText(this, "" + msg, Toast.LENGTH_SHORT).show();
        }
        return error;
    }
}
