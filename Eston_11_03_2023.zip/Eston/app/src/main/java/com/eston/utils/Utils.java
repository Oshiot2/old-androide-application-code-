package com.eston.utils;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import com.eston.EstonApp;
import com.google.android.material.snackbar.Snackbar;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;

import com.eston.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.eston.utils.Constants.USERDATA.PREF_THEME;

/**
 * Created by techno-30 on 24/1/18.
 */

public class Utils {

    private static Utils ourInstance = new Utils();
    public static CustomDialog custDailog = null;
    private static int oldId = 0;

    final public static int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;

    private Utils() {
    }

    public static Utils getInstance() {
        return ourInstance;
    }

    /**
     * Check if internet connection is available or not
     *
     * @param context
     * @return true, if internet is available
     */
    public static boolean isNetworkAvailable(final Context context) {
        boolean isNetAvailable = false;
        if (context != null) {
            final ConnectivityManager mConnectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (mConnectivityManager != null) {
                final NetworkInfo activeNetwork = mConnectivityManager.getActiveNetworkInfo();
                if (activeNetwork != null) isNetAvailable = true;
            }
        }
        return isNetAvailable;
    }


    public static void showNoInternetDialog(final Context context) {
        displayDialog(context, context.getString(R.string.msg_no_internet));
    }

    /**
     * Display dialog with message and a ok button
     *
     * @param context
     * @param msg
     */
    public static void displayDialog(final Context context, final String msg) {
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setCancelable(false);
        alertDialog.setMessage(msg);
        alertDialog.setPositiveButton(context.getString(android.R.string.ok), new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }


    /**
     * Method to show progress dialog
     *
     * @param mActivity
     * @param message
     * @param isCancelable
     * @return dialog
     */
    public static ProgressDialog showProgressDialog(final Context mActivity, final String message, boolean isCancelable) {
        final ProgressDialog mDialog = new ProgressDialog(mActivity);
        mDialog.show();
        mDialog.setCancelable(isCancelable);
        mDialog.setCanceledOnTouchOutside(false);
        mDialog.setMessage(message);
        return mDialog;
    }

    /**
     * Method to dismiss progress dialog
     *
     * @param progressDialog
     */
    public static final void dismissProgressDialog(ProgressDialog progressDialog) {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    public static void showProgress(Context context) {
        try {
            if (custDailog != null && custDailog.isShowing())
                custDailog.dismiss();
            if (custDailog == null)
                custDailog = new CustomDialog(context);
            custDailog.setCancelable(false);
            custDailog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void dismissProgress() {
        if (custDailog != null && custDailog.isShowing())
            custDailog.dismiss();
        custDailog = null;
    }


    /**
     * Call snackbar which will disapper in 3-5 seconds
     *
     * @param view
     * @param message
     * @return Snackbar
     */
    public static Snackbar showSnackbarNonSticky(final View view, final String message, final boolean isTypeError, final Context context) {
        final Snackbar snackbar = Snackbar.make(view, message, Snackbar.LENGTH_SHORT);
        View snackBarView = snackbar.getView();
        if (isTypeError) {
            snackBarView.setBackgroundColor(ContextCompat.getColor(context, R.color.red));
        } else {
            snackBarView.setBackgroundColor(ContextCompat.getColor(context, R.color.colorPrimary));
        }
        snackbar.show();
        return snackbar;
    }


    /**
     * Hides keyboard from screen if it is showing
     *
     * @param mActivity requires for checking keyboard is open or not
     */
    public void hideSoftKeyboard(Activity mActivity) {
        if (mActivity != null && !mActivity.isFinishing()) {
            final InputMethodManager inputMethodManager = (InputMethodManager) mActivity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            if (inputMethodManager.isActive()) {
                if (mActivity.getCurrentFocus() != null) {
                    inputMethodManager.hideSoftInputFromWindow(mActivity.getCurrentFocus().getWindowToken(), 0);
                }
            }
        }
    }

    /*
     *To validate email id
     * @param email requires for checking valid email or not
     *
     */
    public boolean emailValidation(final String email) {
        if (!TextUtils.isEmpty(email))
            if (Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                return true;
            }
        return false;
    }

    /*
     *To validate url
     * @param url requires for checking valid url or not
     *
     */
    public boolean urlValidation(final String url) {
        if (!TextUtils.isEmpty(url))
            if (Patterns.WEB_URL.matcher(url).matches()) {
                return true;
            }
        return false;
    }

    /*
     * To Get UTC Date from ISO Format
     * @param ISO Format Date Requires for get UTC Date
     * */
    public static String getUTCDateFromISO(String dateInString) {
        SimpleDateFormat form = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

        String formatedDate = null;
        Date date;
        try {
            date = form.parse(dateInString);
            SimpleDateFormat postFormater = new SimpleDateFormat("dd.MM.yyyy'; 'HH:mm aa");
            formatedDate = postFormater.format(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return formatedDate;
    }

    public static void setRunTimePermission(final Activity activity) {

        List<String> permissionsNeeded = new ArrayList<String>();

        final List<String> permissionsList = new ArrayList<String>();

        /*if (!addPermission(activity, permissionsList, Manifest.permission.INTERNET))
            permissionsNeeded.add(Manifest.permission.INTERNET);
        if (!addPermission(activity, permissionsList, Manifest.permission.ACCESS_NETWORK_STATE))
            permissionsNeeded.add(Manifest.permission.ACCESS_NETWORK_STATE);
        if (!addPermission(activity, permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            permissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!addPermission(activity, permissionsList, Manifest.permission.READ_EXTERNAL_STORAGE))
            permissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (!addPermission(activity, permissionsList, Manifest.permission.CAMERA))
            permissionsNeeded.add(Manifest.permission.CAMERA);*/
        if (!addPermission(activity, permissionsList, Manifest.permission.ACCESS_FINE_LOCATION))
            permissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!addPermission(activity, permissionsList, Manifest.permission.ACCESS_COARSE_LOCATION))
            permissionsNeeded.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        /*if (!addPermission(activity, permissionsList, Manifest.permission.READ_PHONE_STATE))
            permissionsNeeded.add(Manifest.permission.READ_PHONE_STATE);*/


        if (permissionsList.size() > 0) {

            ActivityCompat.requestPermissions(activity, permissionsList.toArray(new String[permissionsList.size()]),
                    REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);

        }
        return;
    }

    private static boolean addPermission(Activity activity, List<String> permissionsList, String permission) {
        if (ActivityCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(permission);
            // Check for Rationale Option
            if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, permission))
                return false;
        }
        return true;
    }

    /*
     * Check Permission at Runtime for abow Marshmallow Version
     * */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public static boolean checkPermission(final Context context) {

        int currentAPIVersion = Build.VERSION.SDK_INT;
        String[] PERMISSIONS = {Manifest.permission.CAMERA,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE};

        if (currentAPIVersion >= android.os.Build.VERSION_CODES.M) {

            for (String permission : PERMISSIONS) {
                if (ContextCompat.checkSelfPermission(context, permission)
                        != PackageManager.PERMISSION_GRANTED) {

                    if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permission)) {

                        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
                        alertBuilder.setCancelable(true);
                        alertBuilder.setTitle(R.string.label_permission_necessary);
                        alertBuilder.setMessage(R.string.label_external_storage_permission);

                        alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int which) {

                                ActivityCompat.requestPermissions((Activity) context, new String[]{
                                        Manifest.permission.CAMERA,
                                        Manifest.permission.READ_EXTERNAL_STORAGE,
                                        Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                            }
                        });
                        AlertDialog alert = alertBuilder.create();
                        alert.show();
                    } else {
                        ActivityCompat.requestPermissions((Activity) context, new String[]{
                                Manifest.permission.CAMERA,
                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                    }
                    return false;
                } else {
                    return true;
                }
            }
        } else {
            return true;
        }
        return true;
    }

    public static File getRootDir(String Directory, String subDirectory) {

        String root = Environment.getExternalStorageDirectory().toString();
        File myDir = new File(root + "/"
                + Constants.DIRECTORY.ROOT_DIR + "/" + Directory + "/" + subDirectory);
        myDir.mkdirs();
        return myDir;
    }

    /*
     * To Copy to Clipboard
     * */
    public static void setClipboard(Context context, String text) {
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        android.content.ClipData clip = android.content.ClipData.newPlainText("Copied Text", text);
        clipboard.setPrimaryClip(clip);
    }


    public Bitmap getBitmapFromUri(ContentResolver contentResolver, Uri fileUri) throws IOException {
        Bitmap bitmap = MediaStore.Images.Media.getBitmap(contentResolver, fileUri);
        return bitmap;
    }

    public Bitmap getBitmapFromFile(String filePath) throws IOException {
        Bitmap bitmap = BitmapFactory.decodeFile(filePath);
        return bitmap;
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is Google Photos.
     */
    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is Google Drive.
     */
    private static boolean isGoogleDriveUri(Uri uri) {
        return "com.google.android.apps.docs.storage".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is Google Drive.
     */
    private static boolean isGoogleDriveUri1(Uri uri) {
        return "com.google.android.apps.docs.storage.legacy".equals(uri.getAuthority());
    }

    public static String getDataColumn(Context context, Uri uri, String selection, String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {column};

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }

        return null;
    }

    public String convertImageToBase64(String imagePath) {
        String encodedImage = "";
        if (!TextUtils.isEmpty(imagePath)) {
            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
            byte[] byteArrayImage = stream.toByteArray();
            encodedImage = Base64.encodeToString(byteArrayImage, Base64.DEFAULT);

            Log.e("convertImageToBase64 ", "Image File size = " + byteArrayImage.length);
            Log.e("convertImageToBase64 ", "encodedImage.length()= " + encodedImage.length());
        }
        return encodedImage;
    }

    public String convertVideoToBase64(String filePath) {

        String encodedBase64 = "";
        File originalFile = new File(filePath);
        try {
            FileInputStream fileInputStreamReader = new FileInputStream(originalFile);
            byte[] byteArrayVideo = new byte[(int) originalFile.length()];
            fileInputStreamReader.read(byteArrayVideo);
            encodedBase64 = new String(Base64.encode(byteArrayVideo, Base64.DEFAULT));

            Log.e("convertVideoToBase64 ", "Video File size = " + byteArrayVideo.length);
            Log.e("convertVideoToBase64 ", "encodedVideo.length()= " + encodedBase64.length());

        } catch (IOException e) {
            e.printStackTrace();
        }
        return encodedBase64;
    }

    // Get Real path of file from URI
    public String getRealPathFromUri(Context context, Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = {MediaStore.Images.Media.DATA};
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public String getYouTubeThumbnail(String youTubeUrl) {
        String pattern = "(?<=youtu.be/|watch\\?v=|/videos/|embed\\/)[^#\\&\\?]*";
        Pattern compiledPattern = Pattern.compile(pattern);
        Matcher matcher = compiledPattern.matcher(youTubeUrl);
        if (matcher.find()) {
            String s = "http://img.youtube.com/vi/" + matcher.group() + "/mqdefault.jpg";
            return s;
        } else {
            return "error";
        }
    }

    /*
     * For Set Current Timestamp Name
     * */
    public static String getDateString() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
    }

    public String copyFile(File sourceFile, File directory, String imageName) throws IOException {
        File dest = new File(directory, imageName);
        File destFile = new File(dest.getAbsolutePath());

        FileChannel source = null;
        FileChannel destination = null;
        source = new FileInputStream(sourceFile).getChannel();
        destination = new FileOutputStream(destFile).getChannel();
        if (destination != null && source != null) {
            destination.transferFrom(source, 0, source.size());
        }
        if (source != null) {
            source.close();
        }
        if (destination != null) {
            destination.close();
        }
        return destFile.getPath();
    }

    public static String getRealPathFromURI(Context context, Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = {MediaStore.Images.Media.DATA};
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public String getFileName(String filePath) {
        return filePath.substring(filePath.lastIndexOf("/") + 1);
    }

    public static Drawable getSelectedDrawableById(Context mContext, Integer index) {

        try {
            TypedArray ta = mContext.getResources().obtainTypedArray(R.array.ld_DeviceIcons);
            Drawable[] icons = new Drawable[ta.length()];
            for (int i = 0; i < ta.length(); i++) {
                int id = ta.getResourceId(i, 0);
                if (id != 0) {
                    icons[i] = ContextCompat.getDrawable(mContext, id);
                }
            }
            ta.recycle();
            return icons[index];
        } catch (Exception e) {
            TypedArray ta = mContext.getResources().obtainTypedArray(R.array.ld_DeviceIcons);
            int id = ta.getResourceId(0, 0);
            ta.recycle();
            return ContextCompat.getDrawable(mContext, id);
        }
    }

    // Check Network Status
    public static boolean isOnline(Context context) {
        try {
            ConnectivityManager conMgr = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = conMgr.getActiveNetworkInfo();
            if (info != null && info.isConnected())
                return true;
            // else {
            //Toast.makeText(context, context.getResources().getString(R.string.No_internet_available), Toast.LENGTH_SHORT).show();
            // }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            // Log.error("Utils :: isonline() ", e);
            return false;
        }
    }

    public static boolean validateEmail(String email) {
        if (email
                .matches("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*")
                && email.length() > 0) {
            return true;
        }
        return false;
    }

    public static boolean isValidPassword(String password) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{5,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();
    }

    public static int getCurrentTheme() {
        int current = EstonApp.preferenceGetInteger(PREF_THEME, 1);
        int currentTheme = 0;
        if (current == 1) {
            currentTheme = R.style.AppTheme;
        } else if (current == 2) {
            currentTheme = R.style.TwoTheme;
        } else if (current == 3) {
            currentTheme = R.style.ThreeTheme;
        } else if (current == 4) {
            currentTheme = R.style.FourTheme;
        } else if (current == 5) {
            currentTheme = R.style.FiveTheme;
        } else if (current == 6) {
            currentTheme = R.style.SixTheme;
        }
        return currentTheme;
    }

    public static int getPrimaryThemeColor(Context context) {
        int colorAttr;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            colorAttr = android.R.attr.colorPrimary;
        } else {
            colorAttr = context.getResources().getIdentifier("colorPrimary", "attr", context.getPackageName());
        }
        TypedValue outValue = new TypedValue();
        context.getTheme().resolveAttribute(colorAttr, outValue, true);
        return outValue.data;
    }

    public static String getTimestamp() {
        return String.valueOf(TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
    }
}
