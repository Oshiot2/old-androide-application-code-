package com.eston.ui;

import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.eston.EstonApp;
import com.eston.R;
import com.eston.dialongs.AskForDelete;
import com.eston.dialongs.DialogAsk;
import com.eston.fragment.SchedulerFragment;
import com.eston.fragment.MyHomeFragment;
import com.eston.fragment.PrivacyPolicyFragment;
import com.eston.fragment.SettingFragment;
import com.eston.fragment.WiFiSetupFragment;
import com.eston.utils.Utils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.yarolegovich.slidingrootnav.SlidingRootNav;
import com.yarolegovich.slidingrootnav.SlidingRootNavBuilder;

import java.util.Arrays;

import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

public class MainActivity extends AppCompatActivity implements DrawerAdapter.OnItemSelectedListener {

    private static final int POS_HOME = 0;
    private static final int POS_SETTING = 1;
//    private static final int POS_SCHEDULER = 2;
    private static final int POS_WIFI_SETUP = 2;
    private static final int POS_PRIVACY_POLICY = 3;
    private static final int POS_LOGOUT = 4;
    private String[] screenTitles;
    private Drawable[] screenIcons;
    private SlidingRootNav slidingRootNav;
    private Fragment mCurrentFrag;

    ImageView wifiImage;

    @Override
    public void onBackPressed() {
        if (mCurrentFrag instanceof MyHomeFragment) {
            finish();
        } else {
            Fragment selectedScreen = MyHomeFragment.createFor(screenTitles[POS_HOME]);
            showFragment(selectedScreen);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        slidingRootNav = new SlidingRootNavBuilder(this)
                .withToolbarMenuToggle(toolbar)
                .withMenuOpened(false)
                .withContentClickableWhenMenuOpened(false)
                .withSavedState(savedInstanceState)
                .withMenuLayout(R.layout.menu_left_drawer)
                .inject();

        screenIcons = loadScreenIcons();
        screenTitles = loadScreenTitles();

        DrawerAdapter adapter = new DrawerAdapter(Arrays.asList(
                createItemFor(POS_HOME).setChecked(true),
                createItemFor(POS_SETTING),
//                createItemFor(POS_SCHEDULER),
                createItemFor(POS_WIFI_SETUP),
                createItemFor(POS_PRIVACY_POLICY),
                createItemFor(POS_LOGOUT)));
        adapter.setListener(this);

        TextView userEmail = findViewById(R.id.userEmail);
        RecyclerView list = findViewById(R.id.list);
        list.setNestedScrollingEnabled(false);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        adapter.setSelected(0);

        FirebaseUser userSender = FirebaseAuth.getInstance().getCurrentUser();
        String emailSender = userSender.getEmail();
        userEmail.setText(emailSender);

        wifiImage = findViewById(R.id.iv_wifi);
        wifiImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
            }
        });
    }

    @Override
    public void onItemSelected(int position) {
        slidingRootNav.closeMenu();

        if (position == POS_HOME) {
            Fragment selectedScreen = MyHomeFragment.createFor(screenTitles[position]);
            showFragment(selectedScreen);
        }else if (position == POS_SETTING) {
            Fragment selectedScreen = SettingFragment.createFor(screenTitles[position]);
            showFragment(selectedScreen);
        }
//        else if (position == POS_SCHEDULER) {
//            Fragment selectedScreen = SchedulerFragment.createFor(screenTitles[position]);
//            showFragment(selectedScreen);
//        }
        else if (position == POS_WIFI_SETUP) {
            Fragment selectedScreen = WiFiSetupFragment.createFor(screenTitles[position]);
            showFragment(selectedScreen);
        }
        else if (position == POS_PRIVACY_POLICY) {
            Fragment selectedScreen = PrivacyPolicyFragment.createFor(screenTitles[position]);
            showFragment(selectedScreen);
        }  else if (position == POS_LOGOUT) {
            DialogAsk asd = new DialogAsk(this, "Are you sure you want to log out?", new AskForDelete() {
                @Override
                public void onCancelClick() {

                }

                @Override
                public void onOkClick() {
                    EstonApp.preferencePutString(PREF_USER_UID, null);
                    startActivity(new Intent(MainActivity.this, SignInActivity.class));
                    overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
                    finish();
                }
            });
            asd.show(false);
        }
    }

    private void showFragment(Fragment fragment) {
        mCurrentFrag = fragment;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, fragment)
                .commit();
    }

    @SuppressWarnings("rawtypes")
    private DrawerItem createItemFor(int position) {
        return new SimpleItem(screenIcons[position], screenTitles[position])
                .withIconTint(color(R.color.whiteColor))
                .withTextTint(color(R.color.whiteColor))
                .withSelectedIconTint(Utils.getPrimaryThemeColor(this))
                .withSelectedTextTint(Utils.getPrimaryThemeColor(this));
    }

    private String[] loadScreenTitles() {
        return getResources().getStringArray(R.array.ld_activityScreenTitles);
    }

    private Drawable[] loadScreenIcons() {
        TypedArray ta = getResources().obtainTypedArray(R.array.ld_activityScreenIcons);
        Drawable[] icons = new Drawable[ta.length()];
        for (int i = 0; i < ta.length(); i++) {
            int id = ta.getResourceId(i, 0);
            if (id != 0) {
                icons[i] = ContextCompat.getDrawable(this, id);
            }
        }
        ta.recycle();
        return icons;
    }

    @ColorInt
    private int color(@ColorRes int res) {
        return ContextCompat.getColor(this, res);
    }

}