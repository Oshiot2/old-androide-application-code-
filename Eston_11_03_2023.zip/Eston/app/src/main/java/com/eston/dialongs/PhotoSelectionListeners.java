package com.eston.dialongs;

public interface PhotoSelectionListeners {

    void onCameraClick();

    void onGalleryClick();

    void onRemoveClick();

}