package com.eston.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bartoszlipinski.recyclerviewheader2.RecyclerViewHeader;
import com.eston.EstonApp;
import com.eston.R;
import com.eston.adapter.RoomDevicesListAdapter;
import com.eston.dataBase.model.Device;
import com.eston.dataBase.model.Room;
import com.eston.interfaces.DeviceItemClickListener;
import com.eston.utils.Constants;
import com.eston.utils.Utils;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class RoomActivity extends AppCompatActivity implements DeviceItemClickListener {

    private String TAG = RoomActivity.class.getName();

    private Context mContext;
    private Toolbar toolbar;
    private TextView txt_title,tvRoomName;

    private RecyclerView recyclerView;
    private RoomDevicesListAdapter roomDevicesListAdapter;

    private MqttHelper mqttHelper;
    private Room topicsHelper;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_trans_right_in, R.anim.anim_trans_right_out);
        mqttHelper.unSubscribeTopic("umesh1234/eston/query/response");
        finish();
    }

    private void getIntentData() {
        if (getIntent() != null) {
            topicsHelper = (Room) getIntent().getSerializableExtra(Constants.TOPICS);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room2);

        mContext = this;

        /*
         * Get Intent Data
         * */
        getIntentData();

        /*
         * Init Toolbar
         * */
        initToolbar();

        /*
         * Init View
         * */
        initView();
    }

    private void initToolbar() {
//        toolbar = findViewById(R.id.toolbar);
        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

//        toolbar_Title = toolbar.findViewById(R.id.txt_title);
        txt_title.setText(topicsHelper.roomName);
        tvRoomName.setText(topicsHelper.roomName);

//        ImageView iv_more = toolbar.findViewById(R.id.iv_more);
//        iv_more.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                showMenu(v);
//            }
//        });
    }

    private void initView() {
        recyclerView = (RecyclerView) findViewById(R.id.devices_recyclerview);
        roomDevicesListAdapter = new RoomDevicesListAdapter(mContext, topicsHelper.devices, RoomActivity.this);

        GridLayoutManager layoutManager = new GridLayoutManager(mContext, 2);
        layoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                switch (roomDevicesListAdapter.getItemViewType(position)) {
                    case 0:
                        return 2;
                    case 1:
                        return 1;
                    default:
                        return -1;
                }
            }
        });

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(roomDevicesListAdapter);

//        RecyclerViewHeader recyclerHeader = (RecyclerViewHeader) findViewById(R.id.header);
//        recyclerHeader.attachTo(recyclerView);

        mqttHelper = EstonApp.getMqttHelper();
        mqttHelper.subscribeTopic("umesh1234/eston/query/response");
        mqttHelper.publishTopic("umesh1234/eston/query", "OK");
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.e(TAG, "=======connectComplete==========");
            }

            @Override
            public void connectionLost(Throwable cause) {
                Log.e(TAG, "=======connectionLost==========");
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Log.e(TAG, "=======topic==========" + topic);
                Log.e(TAG, "=======messageArrived==========" + message);
                if ("umesh1234/eston/query/response".equals(topic)) {
                    if (message != null) {
                        for (int i = 0; i < message.toString().length(); i++) {
                            if (i < 6) {
                                topicsHelper.devices.get(i).deviceOnOffState = Integer.valueOf(message.toString().substring(i, (i + 1)));
                            } else {
                                topicsHelper.devices.get(6).deviceOnOffState = Integer.valueOf(message.toString().substring(6, 7));
                                topicsHelper.devices.get(6).deviceFanCurrentValue = Integer.valueOf(message.toString().substring(7, 8));
                            }
                        }
                        roomDevicesListAdapter.notifyDataSetChanged();
                    }
                }

            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.e(TAG, "=======deliveryComplete==========");
            }
        });
    }

    @Override
    public void onItemClick(Object item, int position) {

        String msg = "";
        if (((Device) item).deviceType == 1) {
            if (((Device) item).deviceOnOffState == 1) {
                msg = (position + 1) + "0";
            } else {
                msg = (position + 1) + "" + ((Device) item).deviceFanCurrentValue;
            }
        } else {
            if (((Device) item).deviceOnOffState == 1) {
                msg = (position + 1) + "0";
            } else {
                msg = (position + 1) + "1";
            }
        }
        mqttHelper.publishTopicWithListener("umesh1234/eston/sendstate", msg, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Log.e(TAG, "Publish Success");
                ((Device) item).deviceOnOffState = ((Device) item).deviceOnOffState == 1 ? 0 : 1;
                topicsHelper.devices.set(position, ((Device) item));
                roomDevicesListAdapter.notifyItemChanged(position);
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Log.e(TAG, "Publish Fail : " + exception);
                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Publish Failed", true, RoomActivity.this);
            }
        });

    }

    @Override
    public void onFanFunctionClick(Object item, Integer IsPlus, int position) {
        if (((Device) item).deviceOnOffState == 0) {
            Utils.showSnackbarNonSticky(recyclerView, "Fan is in off mode", true, RoomActivity.this);
            return;
        }
        int currentCount = 0;
        if (IsPlus == 1) {
            currentCount = ((Device) item).deviceFanCurrentValue + 1;
        } else {
            currentCount = ((Device) item).deviceFanCurrentValue - 1;
        }
        Integer finalCurrentCount = currentCount;
        mqttHelper.publishTopicWithListener("umesh1234/eston/sendstate",
                (position + 1) + "" + currentCount,
                new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        Log.e(TAG, "Publish Success");
                        ((Device) item).deviceFanCurrentValue = finalCurrentCount;
                        topicsHelper.devices.set(position, ((Device) item));
                        roomDevicesListAdapter.notifyItemChanged(position);
                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        Log.e(TAG, "Publish Fail : " + exception);
                        Utils.showSnackbarNonSticky(recyclerView, "Publish Failed", true, RoomActivity.this);
                    }
                });

    }

    public void showMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenuInflater().inflate(R.menu.room_options, popup.getMenu());
        try {
            Field[] fields = popup.getClass().getDeclaredFields();
            for (Field field : fields) {
                if ("mPopup".equals(field.getName())) {
                    field.setAccessible(true);
                    Object menuPopupHelper = field.get(popup);
                    Class<?> classPopupHelper = Class.forName(menuPopupHelper.getClass().getName());
                    Method setForceIcons = classPopupHelper.getMethod("setForceShowIcon", boolean.class);
                    setForceIcons.invoke(menuPopupHelper, true);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        popup.show();
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                return true;
            }
        });

    }
}
