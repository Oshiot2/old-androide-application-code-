package com.eston.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.eston.R;
import com.eston.adapter.IconSelectionAdapter;
import com.eston.interfaces.ClickListener;
import com.eston.utils.Utils;

import java.util.ArrayList;

public class IconSelectionActivity extends AppCompatActivity implements ClickListener {

    private String TAG = IconSelectionActivity.class.getName();

    private Context mContext;
    private Toolbar toolbar;
    private TextView toolbar_Title;
    private RecyclerView recyclerView;
    ArrayList<Drawable> deviceList;
    IconSelectionAdapter iconSelectionAdapter;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_trans_right_in, R.anim.anim_trans_right_out);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_icon_selection);

        mContext = this;

        /*
         * Init Toolbar
         * */
        initToolbar();

        /*
         * Init View
         * */
        initView();
    }

    private void initToolbar() {
//        toolbar = findViewById(R.id.toolbar);
        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

//        toolbar_Title = toolbar.findViewById(R.id.txt_title);
//        toolbar_Title.setText("Select Icon");

    }

    private void initView() {
        recyclerView = findViewById(R.id.devices_recyclerview);
        deviceList = new ArrayList<>();
        TypedArray ta = mContext.getResources().obtainTypedArray(R.array.ld_DeviceIcons);
        for (int i = 0; i < ta.length(); i++) {
            int id = ta.getResourceId(i, 0);
            if (id != 0) {
                deviceList.add(ContextCompat.getDrawable(mContext, id));
            }
        }
        ta.recycle();

        recyclerView.setLayoutManager(new GridLayoutManager(mContext, 4));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        iconSelectionAdapter = new IconSelectionAdapter(mContext, deviceList, IconSelectionActivity.this);
        recyclerView.setAdapter(iconSelectionAdapter);

    }

    @Override
    public void onItemClick(View view, int position) {
        Intent returnIntent = new Intent();
        returnIntent.putExtra("position", getIntent().getIntExtra("position", 0));
        returnIntent.putExtra("result", position);
        setResult(Activity.RESULT_OK, returnIntent);
        onBackPressed();
    }
}
