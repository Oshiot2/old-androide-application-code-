package com.eston.utils;

public interface Constants {

    String ON = "ON";
    String OFF = "OFF";
    String DONE = "done";
    String TOPICS = "topics";
    String ROOMS = "room_list";
    String GROUP_POS = "group_pos";
    String CHILD_POS = "child_pos";
    String FOLDER_NAME = "OTA Firmware";

    int ICON_SELECTION_ACTIVITY_REQUEST_CODE = 110;

    int ROOM_ACTIVITY_REQUEST_CODE = 111;
    int ROOM_ACTIVITY_RESULT_CODE = 112;


    public interface PHOTO_CONST {
        String PHOTOS = "Photos";
        String CAMERA = "Camera";
        int TYPE_PHOTO_PICK_FROM_CAMERA = 1;
        int TYPE_PHOTO_PICK_FROM_FILE = 2;
        int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    }


    public interface DIRECTORY {

        // Internal Storage Folder Name
        String ROOT_DIR = "HobbsRepair";
        String PROFILE_DIR = "Profile";
        String IMAGE_DIR = "Image";
    }

    public interface MQTT {

        String SCAN_NEW_HUB = "/eston/hub/query";
        String SCAN_NEW_HUB_RESPONSE = "/eston/hubscan/response";
        String WIFI_SUBMIT = "/eston/wifi/submit";
        String WIFI_SUBMIT_RESPONSE = "/eston/wifi/submit/response";

    }
    public interface USERDATA {

        String PREF_USER_UID = "PREF_USER_UID";
        String PREF_THEME = "PREF_USER_THEME";

    }
    public interface SETTINGS {

        String SETTINGS = "Settings";
        String PIN = "pin";
        String HUBID = "HubId";
        String MACID = "MacId";
        String SSID = "SSID";
        String PASSWORD = "Password";
        String SERVERTYPE = "serverType";

    }

    public interface ROOMS_TABLE {

        String ROOMS = "Rooms";
        String DEVICES = "devices";
        String UID = "uid";
        String UUID = "roomUUID";
        String NAME = "roomName";
        String IMAGE = "roomImage";
    }


    public interface SCHEDULE {

        String SCHEDULER = "Scheduler";

    }

}
