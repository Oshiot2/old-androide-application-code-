package com.eston.dataBase.model;

import androidx.room.Entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Entity
public class Schedule implements Serializable {

    public Integer Action = 1; // add/ delete
    public String Mac; //room mac
    public Integer Switch =1;//device pos
    public Integer State = 0; //on off
    public Integer DaysCount = 0; // number of day from week count
    public ArrayList<Integer> DaysNumber;// list of day from week count
    public String Time = "00:00"; // tome for scheduler
    public String Sch_No = "0"; // ?
    public String sid; //schedule id
    public String rid; // room id
    public String roomName; // room name
    public String deviceName; // device name
    public Integer isDeleted = 0;

    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("Action", this.Action);
        result.put("Mac", this.Mac);
        result.put("Switch", this.Switch);
        result.put("State", this.State);
        result.put("DaysCount", this.DaysCount);
        result.put("DaysNumber", this.DaysNumber);
        result.put("Time", this.Time);
        result.put("Sch_No", this.Sch_No);
        result.put("sid", this.sid);
        result.put("rid", this.rid);
        result.put("roomName", this.roomName);
        result.put("deviceName", this.deviceName);
        result.put("isDeleted", this.isDeleted);
        return result;
    }

    @Override
    public String toString() {
        return "Schedule{" +
                "Action=" + Action +
                ", Mac='" + Mac + '\'' +
                ", Switch=" + Switch +
                ", State=" + State +
                ", DaysCount=" + DaysCount +
                ", DaysNumber=" + DaysNumber +
                ", Time='" + Time + '\'' +
                ", Sch_No='" + Sch_No + '\'' +
                ", sid='" + sid + '\'' +
                ", rid='" + rid + '\'' +
                ", roomName='" + roomName + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", isDeleted=" + isDeleted +
                '}';
    }
}