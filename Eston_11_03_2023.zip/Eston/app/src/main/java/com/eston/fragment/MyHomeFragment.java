package com.eston.fragment;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.eston.EstonApp;
import com.eston.R;

import com.eston.adapter.HomeItemsListAdapter;
import com.eston.dataBase.model.Device;
import com.eston.dataBase.model.Room;
import com.eston.dialongs.AskFroPin;
import com.eston.interfaces.HomeAdapterItemClickListener;
import com.eston.ui.CreateNewRoomActivity;
import com.eston.ui.MqttHelper;
import com.eston.ui.RoomNewActivity;
import com.eston.utils.Constants;
import com.eston.utils.Utils;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONObject;

import java.io.Serializable;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

import javax.crypto.Mac;


//TODO Swipe up get stuatus online/Offline
public class MyHomeFragment extends Fragment implements HomeAdapterItemClickListener {

    private static final String TAG = MyHomeFragment.class.getName();
    private static final String EXTRA_TEXT = "text";
    private String pin = "";
    private String MacId = "";
    private int SERVERTYPE = 0;
//    ImageView iv_Logo;
    private ProgressDialog progressDialog;
    private ProgressBar progressRoom;
    private TextView txt_NoROOM;
    ArrayList<Room> roomArrayList = new ArrayList<>();
    private RecyclerView recyclerView;
    HomeItemsListAdapter homeItemsListAdapter;
    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;
    private MqttHelper mqttHelper;

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mqttHelper != null) {
            if (roomArrayList.size() > 0) {
                mqttHelper.unSubscribeTopic(roomArrayList.get(0).getSubscribeAddress(MacId));
            }
        }
    }

    public static MyHomeFragment createFor(String text) {
        MyHomeFragment fragment = new MyHomeFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_my_home, container, false);
        Bundle args = getArguments();
        final String text = args != null ? args.getString(EXTRA_TEXT) : "";
        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        TextView txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setText("Home");
//        txt_title.setVisibility(View.GONE);
//        ImageView iv_wifi = toolbar.findViewById(R.id.iv_wifi);
//        iv_wifi.setVisibility(View.VISIBLE);
//        iv_Logo = toolbar.findViewById(R.id.iv_Logo);
//        iv_Logo.setVisibility(View.VISIBLE);
//        iv_Logo.setColorFilter(ContextCompat.getColor(getActivity(), R.color.While), android.graphics.PorterDuff.Mode.SRC_IN);

        progressRoom = view.findViewById(R.id.progressRoom);
        txt_NoROOM = view.findViewById(R.id.txt_NoROOM);
        recyclerView = view.findViewById(R.id.my_home_recyclerview);

        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference("users");
        mFirebaseDatabase.keepSynced(true);

        if (Utils.checkPermission(getActivity())) {
            progressDialog = Utils.showProgressDialog(getActivity(), "Loading...", false);
        }
        checkHubAdded();

        return view;
    }

    private void checkHubAdded() {

        String firebaseUserId = EstonApp.preferenceGetString(PREF_USER_UID, "");
        DatabaseReference userRef = mFirebaseDatabase.child(firebaseUserId).child(Constants.SETTINGS.SETTINGS);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    Object td = dataSnapshot.getValue();

                    HashMap<String, Objects> settings = (HashMap<String, Objects>) td;
                    Log.e(TAG, "settings " + settings);
                    if (settings != null) {
                        if (settings.containsKey(Constants.SETTINGS.PIN) && settings.get(Constants.SETTINGS.PIN) != null) {
                            pin = String.valueOf(settings.get(Constants.SETTINGS.PIN));
                        }
                        if (settings.containsKey(Constants.SETTINGS.SERVERTYPE) && settings.get(Constants.SETTINGS.SERVERTYPE) != null
                                && Integer.parseInt(String.valueOf(settings.get(Constants.SETTINGS.SERVERTYPE))) == 0) {
                            SERVERTYPE = 0;
                        } else {
                            SERVERTYPE = 1;
                        }
                        if (settings.containsKey(Constants.SETTINGS.MACID) && settings.get(Constants.SETTINGS.MACID) != null) {
                            MacId = String.valueOf(settings.get(Constants.SETTINGS.MACID));
                            if (!MacId.isEmpty()) {
                                getRoomList();
                            } else {
                                MacId = "";
                                txt_NoROOM.setText("Can't fetch MacId from server.\nPlease setup MacId first from setting!!");
                                txt_NoROOM.setVisibility(View.VISIBLE);
                                recyclerView.setVisibility(View.GONE);
                                progressRoom.setVisibility(View.GONE);
                                Utils.dismissProgressDialog(progressDialog);
                            }
                        } else {
                            MacId = "";
                            txt_NoROOM.setText("Can't fetch MacId from server.\nPlease setup MacId first from setting!!");
                            txt_NoROOM.setVisibility(View.VISIBLE);
                            recyclerView.setVisibility(View.GONE);
                            progressRoom.setVisibility(View.GONE);
                            Utils.dismissProgressDialog(progressDialog);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    txt_NoROOM.setText("Network error.\nPlease try again.");
                    txt_NoROOM.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                    progressRoom.setVisibility(View.GONE);
                    Utils.dismissProgressDialog(progressDialog);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "error " + error.getMessage());
                txt_NoROOM.setText("Network error.\nPlease try again. ");
                txt_NoROOM.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
                progressRoom.setVisibility(View.GONE);
                Utils.dismissProgressDialog(progressDialog);
            }
        });
    }

    private void getRoomList() {

        DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                .child(Constants.ROOMS_TABLE.ROOMS);

        namesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.getValue() != null) {
                    roomArrayList = new ArrayList<Room>();
                    for (DataSnapshot child : snapshot.getChildren()) {
                        try {
                            Room room = child.getValue(Room.class);
                            ArrayList<Device> devices = new ArrayList<Device>();
                            for (int i = 0; i < room.devices.size(); i++) {
                                if (room.devices.get(i) != null && room.devices.get(i).isDeleted == 0)
                                    devices.add(room.devices.get(i));
                            }
                            room.devices = devices;
                            roomArrayList.add(room);
                            setupUI(roomArrayList);
                        } catch (Exception e) {
                            e.printStackTrace();
                            txt_NoROOM.setText("Network error " + e.getMessage());
                            txt_NoROOM.setVisibility(View.VISIBLE);
                            recyclerView.setVisibility(View.GONE);
                            progressRoom.setVisibility(View.GONE);
                            Utils.dismissProgressDialog(progressDialog);
                        }
                    }
                } else {
                    txt_NoROOM.setText("Please create room from settings");
                    txt_NoROOM.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                    progressRoom.setVisibility(View.GONE);
                    Utils.dismissProgressDialog(progressDialog);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                txt_NoROOM.setText("Network error " + error.getMessage());
                txt_NoROOM.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
                progressRoom.setVisibility(View.GONE);
                Utils.dismissProgressDialog(progressDialog);
            }
        });
    }

    private void setupUI(List<Room> rooms) {

        progressRoom.setVisibility(View.GONE);
        txt_NoROOM.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);


        roomArrayList = (ArrayList<Room>) rooms;
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setHasFixedSize(true);
        homeItemsListAdapter = new HomeItemsListAdapter(getActivity(), roomArrayList, MyHomeFragment.this);
        recyclerView.setAdapter(homeItemsListAdapter);
        if (getActivity() != null) {
            mqttHelper = EstonApp.getMqttHelperWithReconnect(getActivity().getApplicationContext(), SERVERTYPE);
        }

        initMqtt();
//        Thread t = new Thread() {
//            public void run() {
//                try {
//                    sleep(3000);
//                    if (getActivity() != null) {
//                        getActivity().runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                Utils.dismissProgressDialog(progressDialog);
//                            }
//                        });
//                        initMqtt();
//                    }
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//            }
//        };
//        t.start();
    }

    private static String convertStringArrayToString(String[] strArr, String delimiter) {
        StringBuilder sb = new StringBuilder();
        for (String str : strArr)
            sb.append(str).append(delimiter);
        return sb.substring(0, sb.length() - 1);
    }

    private void initMqtt() {

        try {
            if (getActivity() != null) {

                if (roomArrayList.size() > 0) {

//                    String [] macIDs = new String[roomArrayList.size()];
//
//                    for (int i=0; i<roomArrayList.size(); i++){
//                        macIDs[i] = roomArrayList.get(i).roomUUID;
//                        Log.e("MyHomeFrag",roomArrayList.get(i).roomUUID);
//                    }
//                    mqttHelper.subscribeTopic(roomArrayList.get(0).getSubscribeAddress(convertStringArrayToString(macIDs,",")));
//                    mqttHelper.subscribeTopic(roomArrayList.get(0).getSubscribeAddress(MacId));
                    for (int i=0; i<roomArrayList.size(); i++){
                        mqttHelper.subscribeTopic("/" + roomArrayList.get(i).roomUUID + "/RES");
                        Log.e("MyHomeFrag",roomArrayList.get(i).roomUUID);
                    }
                    Utils.dismissProgressDialog(progressDialog);
//                    mqttHelper.publishTopic(roomArrayList.get(0).getPublishAddress(MacId), "2");
//                    mqttHelper.publishTopic(roomArrayList.get(0).getPublishControlAddress(MacId),"");
                }
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (getActivity() != null)
                            if (mqttHelper.getMqttAndroidClient().isConnected()) {
//                                iv_Logo.clearColorFilter();
                            } else {
//                                iv_Logo.setColorFilter(ContextCompat.getColor(getActivity(), R.color.While), android.graphics.PorterDuff.Mode.SRC_IN);
                            }
                    }
                });

                mqttHelper.setCallback(new MqttCallbackExtended() {
                    @Override
                    public void connectComplete(boolean reconnect, String serverURI) {
                        Log.e(TAG, "=======connectComplete========== reconnect " + reconnect + " serverURI " + serverURI);
//                        if (reconnect && getActivity() != null)
//                            Utils.showSnackbarNonSticky(getActivity().findViewById(android.R.id.content), "Reconnect successfully", true, getActivity());

                        if (getActivity() != null)
                            if (mqttHelper.getMqttAndroidClient().isConnected()) {
//                                iv_Logo.clearColorFilter();
                            } else {
//                                iv_Logo.setColorFilter(ContextCompat.getColor(getActivity(), R.color.While), android.graphics.PorterDuff.Mode.SRC_IN);
                            }
                    }

                    @Override
                    public void connectionLost(Throwable cause) {
                        Log.e(TAG, "=======connectionLost==========" + cause);
//                        if (getActivity() != null && cause != null)
//                            Utils.showSnackbarNonSticky(getActivity().findViewById(android.R.id.content), cause.getMessage(), true, getActivity());

                        if (getActivity() != null)
                            if (mqttHelper.getMqttAndroidClient().isConnected()) {
//                                iv_Logo.clearColorFilter();
                            } else {
//                                iv_Logo.setColorFilter(ContextCompat.getColor(getActivity(), R.color.While), android.graphics.PorterDuff.Mode.SRC_IN);
                            }
                    }

                    @Override
                    public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                        try {
                            Log.e(TAG, "=======topic==========" + topic);
                            Log.e(TAG, "=======messageArrived==========" + mqttMessage);
                            for (int i = 0; i < roomArrayList.size(); i++) {
                                if (topic.toString().equals(roomArrayList.get(i).getSubscribeAddress(MacId))) {

                                    if (mqttMessage != null && mqttMessage.toString().length() == 31) {
                                        String data = "", macId = "";
                                        macId = mqttMessage.toString().substring((mqttMessage.toString().indexOf("M") + 1), mqttMessage.toString().indexOf("R"));
                                        data = mqttMessage.toString().substring((mqttMessage.toString().indexOf("R") + 1), mqttMessage.toString().indexOf("@"));
                                        Log.e(TAG, "macId " + macId);
                                        Log.e(TAG, "roomArrayList.get(i).roomUUID " + roomArrayList.get(i).roomUUID);
                                        Log.e(TAG, "data " + data);

                                        if (macId.equalsIgnoreCase(roomArrayList.get(i).roomUUID)) {
                                            Log.e(TAG, "=======topic match========== " + roomArrayList.get(i).devices.size());
                                            for (int j = 0; j < roomArrayList.get(i).devices.size(); j++) {
                                                if (roomArrayList.get(i).devices.get(j).devicePOS <= 5) {
                                                    Log.e(TAG, "=======topic match  <= 5 ========== " + Integer.valueOf(String.valueOf(data.charAt(j))));
                                                    roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(j)));
                                                } else if (roomArrayList.get(i).devices.get(j).devicePOS == 6) {
                                                    Log.e(TAG, "=======topic match  == 6 ========== " + Integer.valueOf(String.valueOf(data.charAt(6))));
                                                    Log.e(TAG, "=======topic match  == 6 ========== " + Integer.valueOf(String.valueOf(data.charAt(7))));
                                                    roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
                                                    roomArrayList.get(i).devices.get(j).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
                                                } else if (roomArrayList.get(i).devices.get(j).devicePOS > 6 && roomArrayList.get(i).devices.get(j).devicePOS <= 12) {
                                                    Log.e(TAG, "=======topic match  6==12 ========== " + Integer.valueOf(String.valueOf(data.charAt(j + 1))));
                                                    roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(j + 1)));
                                                } else if (roomArrayList.get(i).devices.get(j).devicePOS == 13) {
                                                    Log.e(TAG, "=======topic match  ==13 ========== " + Integer.valueOf(String.valueOf(data.charAt(14))));
                                                    Log.e(TAG, "=======topic match  ==13 ========== " + Integer.valueOf(String.valueOf(data.charAt(15))));
                                                    roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(14)));
                                                    roomArrayList.get(i).devices.get(j).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(15)));
                                                }
                                            }
                                            Log.e(TAG, "roomArrayList.get(i).devices " + roomArrayList.get(i).devices);
                                            homeItemsListAdapter.notifyItemChanged(i);
                                            updateOnDatabase(roomArrayList.get(i), roomArrayList.get(i).devices);
                                            break;
                                        }

//                                    Integer deviceOnOffState_POS_0 = Integer.valueOf(String.valueOf(data.charAt(0)));
//                                    Integer deviceOnOffStatePOS_1 = Integer.valueOf(String.valueOf(data.charAt(1)));
//                                    if (roomArrayList.get(i).devices.size() == 2) {
//                                        roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
//                                        roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
//                                    } else if (roomArrayList.get(i).devices.size() == 4) {
//                                        roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
//                                        roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
//                                        roomArrayList.get(i).devices.get(2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(2)));
//                                        roomArrayList.get(i).devices.get(3).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(3)));
//                                    } else if (roomArrayList.get(i).devices.size() == 5) {
//                                        roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
//                                        roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
//                                        roomArrayList.get(i).devices.get(2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(2)));
//                                        roomArrayList.get(i).devices.get(3).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(3)));
//
//                                        roomArrayList.get(i).devices.get(4).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
//                                        roomArrayList.get(i).devices.get(4).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
//
//                                    } else if (roomArrayList.get(i).devices.size() == 7) {
//                                        roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
//                                        roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
//                                        roomArrayList.get(i).devices.get(2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(2)));
//                                        roomArrayList.get(i).devices.get(3).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(3)));
//                                        roomArrayList.get(i).devices.get(4).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(4)));
//                                        roomArrayList.get(i).devices.get(5).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(5)));
//
//                                        roomArrayList.get(i).devices.get(6).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
//                                        roomArrayList.get(i).devices.get(6).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
//
//                                    } else if (roomArrayList.get(i).devices.size() == 10) {
//                                        roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
//                                        roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
//                                        roomArrayList.get(i).devices.get(2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(2)));
//                                        roomArrayList.get(i).devices.get(3).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(3)));
//                                        roomArrayList.get(i).devices.get(4).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(4)));
//                                        roomArrayList.get(i).devices.get(5).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(5)));
//
//                                        roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
//                                        roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 2).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
//
//                                        roomArrayList.get(i).devices.get(6).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(8)));
//                                        roomArrayList.get(i).devices.get(7).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(9)));
//
//                                        roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 1).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(14)));
//                                        roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 1).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(15)));
//
//                                    } else if (roomArrayList.get(i).devices.size() == 14) {
//                                        roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
//                                        roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
//                                        roomArrayList.get(i).devices.get(2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(2)));
//                                        roomArrayList.get(i).devices.get(3).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(3)));
//                                        roomArrayList.get(i).devices.get(4).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(4)));
//                                        roomArrayList.get(i).devices.get(5).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(5)));
//
//                                        roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
//                                        roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 2).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
//
//                                        roomArrayList.get(i).devices.get(6).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(8)));
//                                        roomArrayList.get(i).devices.get(7).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(9)));
//                                        roomArrayList.get(i).devices.get(8).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(10)));
//                                        roomArrayList.get(i).devices.get(9).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(11)));
//                                        roomArrayList.get(i).devices.get(10).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(12)));
//                                        roomArrayList.get(i).devices.get(11).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(13)));
//
//                                        roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 1).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(14)));
//                                        roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 1).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(15)));
//                                    }
                                    }
                                }
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "ERROR " + e.getMessage());
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void deliveryComplete(IMqttDeliveryToken token) {
                        Log.e(TAG, "=======deliveryComplete==========" + token);
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateOnDatabase(Room room, ArrayList<Device> devices) {
        try {
            for (int i = 0; i < devices.size(); i++) {
                Utils.getInstance().hideSoftKeyboard(getActivity());
                DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.ROOMS_TABLE.ROOMS)
                        .child(room.roomUUID)
                        .child(Constants.ROOMS_TABLE.DEVICES)
                        .child(String.valueOf(devices.get(i).did));
                namesRef.updateChildren(devices.get(i).toMap());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
//        for (int i = 0; i < devices.size(); i++) {
//            DatabaseClient.getInstance(getActivity())
//                    .getAppDatabase()
//                    .deviceDao()
//                    .update(devices.get(i));
//        }
    }

    @Override
    public void onItemClick(Room homeItems, int position) {

        Intent intent = new Intent(getActivity(), RoomNewActivity.class);
        Bundle args = new Bundle();
        args.putSerializable(Constants.ROOMS, (Serializable) roomArrayList);
        args.putSerializable(Constants.TOPICS, homeItems);
        intent.putExtra("BUNDLE", args);
        intent.putExtra("pos", position);
        startActivityForResult(intent, Constants.ROOM_ACTIVITY_REQUEST_CODE);
//        if (mqttHelper != null && mqttHelper.getMqttAndroidClient().isConnected()) {
//
//            Log.e(TAG, "mqttHelper.getMqttAndroidClient().isConnected() " + mqttHelper.getMqttAndroidClient().isConnected());
//
//            Intent intent = new Intent(getActivity(), RoomNewActivity.class);
//            Bundle args = new Bundle();
//            args.putSerializable(Constants.ROOMS, (Serializable) roomArrayList);
//            args.putSerializable(Constants.TOPICS, homeItems);
//            intent.putExtra("BUNDLE", args);
//            startActivityForResult(intent, Constants.ROOM_ACTIVITY_REQUEST_CODE);
//            getActivity().overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
//        }
//        else {
//            Utils.showSnackbarNonSticky(getActivity().findViewById(android.R.id.content), "Device did not connected", true, getActivity());
//        }
    }

    @Override
    public void onDeleteClick(Room homeItems, int position) {
//        Intent intent = new Intent(getActivity(), RoomNewActivity.class);
//        Bundle args = new Bundle();
//        args.putSerializable(Constants.ROOMS, (Serializable) roomArrayList);
//        args.putSerializable(Constants.TOPICS, homeItems);
//        intent.putExtra("BUNDLE", args);
//        startActivityForResult(intent, Constants.ROOM_ACTIVITY_REQUEST_CODE);
//        getActivity().overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);

//        AskFroPin askFroPin = new AskFroPin(getActivity(), "Verify Pin", new AskFroPin.AskForPinListener() {
//            @Override
//            public void onDone() {
//                progressDialog = Utils.showProgressDialog(getActivity(), "Deleting...", false);
//                Utils.getInstance().hideSoftKeyboard(getActivity());
//                DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
//                        .child(Constants.ROOMS_TABLE.ROOMS).child(homeItems.roomUUID);
//                namesRef.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
//                    @Override
//                    public void onSuccess(Void runnable) {
//                        Utils.dismissProgressDialog(progressDialog);
//                        roomArrayList.remove(position);
//                        homeItemsListAdapter.notifyItemRemoved(position);
//                    }
//                }).addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(Exception runnable) {
//                        Utils.dismissProgressDialog(progressDialog);
//                        Toast.makeText(getActivity(), "Error " + runnable.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                });
//            }
//        });
//        askFroPin.show(pin);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "onActivityResult requestCode " + requestCode + " resultCode " + resultCode);
        if (requestCode == Constants.ROOM_ACTIVITY_REQUEST_CODE && resultCode == Constants.ROOM_ACTIVITY_RESULT_CODE) {
            checkHubAdded();
        }
    }

}
