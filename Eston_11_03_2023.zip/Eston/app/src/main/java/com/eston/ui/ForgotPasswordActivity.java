package com.eston.ui;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.eston.EstonApp;
import com.eston.R;
import com.eston.utils.Utils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;


public class ForgotPasswordActivity extends AppCompatActivity {

    private String TAG = ForgotPasswordActivity.class.getName();

    private ProgressDialog progressDialog;
    TextInputEditText edtEmailAddress;
    Button SignIn;

    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_forgotpass2);

        edtEmailAddress = findViewById(R.id.edtEmailid);
        SignIn = findViewById(R.id.btn_SignIn);

        //initialise firebase
        initFirebase();

        SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isValidData()) {
                    if (Build.VERSION.SDK_INT >= 23) {
                        setPermission();
                    } else {
                        startSetUpActivity();
                    }
                }
            }
        });

    }

    private void initFirebase() {
        //Get Firebase auth instance
        auth = FirebaseAuth.getInstance();
    }


    private void setPermission() {
        Utils.setRunTimePermission(ForgotPasswordActivity.this);

        if (ActivityCompat.checkSelfPermission(ForgotPasswordActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(ForgotPasswordActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startSetUpActivity();
        }
    }

    private void startSetUpActivity() {
        if (Utils.isOnline(this)) {
            //show progress bar
            progressDialog = Utils.showProgressDialog(this, getString(R.string.msg_loading), false);

            String email = edtEmailAddress.getText().toString().trim();
            auth.sendPasswordResetEmail(email)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Log.d(TAG, "Email sent.");
                                //dismiss progressbar
                                Utils.dismissProgressDialog(progressDialog);
                                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Password reset link sent on your mail address.", true, ForgotPasswordActivity.this);
                                onBackPressed();
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            //dismiss progressbar
                            Utils.dismissProgressDialog(progressDialog);
                            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), e.getMessage(), true, ForgotPasswordActivity.this);
                        }
                    });

        } else {
            Toast.makeText(this, getResources().getString(R.string.No_internet_available), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        // If request is cancelled, the result arrays are empty.
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startSetUpActivity();
        }
    }

    private boolean isValidData() {
        String msg = "";
        boolean error = false;
        if (edtEmailAddress.getText().toString().isEmpty()) {
            error = true;
            msg = getString(R.string.please_enter) + " " + getString(R.string.email_address).toLowerCase();
            edtEmailAddress.requestFocus();
        } else if (!Utils.validateEmail(edtEmailAddress.getText().toString().trim())) {
            error = true;
            msg = getString(R.string.please_enter) + " " + getString(R.string.valid_email_address).toLowerCase();
            edtEmailAddress.requestFocus();
        }

        if (msg.isEmpty()) {
            error = false;
            //Toast.makeText(this, ""+msg, Toast.LENGTH_SHORT).show();
        } else {
            error = true;
            Toast.makeText(this, "" + msg, Toast.LENGTH_SHORT).show();
        }
        return error;
    }
}
