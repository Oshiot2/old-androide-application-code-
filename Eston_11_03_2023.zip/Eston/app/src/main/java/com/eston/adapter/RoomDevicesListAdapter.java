package com.eston.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.eston.R;
import com.eston.dataBase.model.Device;
import com.eston.interfaces.ClickListener;
import com.eston.interfaces.DeviceItemClickListener;
import com.eston.utils.Utils;

import java.util.ArrayList;

public class RoomDevicesListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;

    // Context
    private Context mContext;

    // List of Home Items
    private ArrayList<Device> integers;

    // OnClick Listener
    private DeviceItemClickListener clickListener;

    /**
     * Conductor
     *
     * @param mContext
     * @param integers
     */
    public RoomDevicesListAdapter(Context mContext, ArrayList<Device> integers, DeviceItemClickListener clickListener) {
        this.mContext = mContext;
        this.integers = integers;
        this.clickListener = clickListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if (viewType == TYPE_ITEM) {
            //inflate your layout and pass it to view holder
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_devices_list_item, parent, false);
            return new VHItem(itemView);
        } else if (viewType == TYPE_HEADER) {
            //inflate your layout and pass it to view holder
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_devices_list_header_item, parent, false);
            return new VHHeader(itemView);
        }
        throw new RuntimeException("there is no type that matches the type " + viewType + " + make sure your using types correctly");
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
//        Log.e("onBindViewHolder", position + " " + getItem(position).toString());
        if (holder instanceof VHItem) {
            Device dataItem = getItem(position);
            //cast holder to VHItem and set data
            ((VHItem) holder).txt_DeviceTitle.setText(dataItem.deviceName);
            ((VHItem) holder).iv_DeviceIcon.setImageDrawable(Utils.getSelectedDrawableById(mContext, dataItem.deviceImage));

//            if (position == 0){
//                ((VHItem) holder).ivSchedule.setVisibility(View.VISIBLE);
//            }else if (position == 2){
//                ((VHItem) holder).ivChildLock.setVisibility(View.VISIBLE);
//            }

            if (dataItem.deviceOnOffState == 1) {
//                ((VHItem) holder).card_item.setCardBackgroundColor(ContextCompat.getColor(mContext, Utils.getPrimaryThemeColor(mContext)));
                ((VHItem) holder).card_item.setCardBackgroundColor(Utils.getPrimaryThemeColor(mContext));
            } else {
                ((VHItem) holder).card_item.setCardBackgroundColor(ContextCompat.getColor(mContext, R.color.cardBGColor));
            }
            ((VHItem) holder).card_item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    clickListener.onItemClick(dataItem, position);
                }
            });
        } else if (holder instanceof VHHeader) {
            Device dataItem = getItem(position);
            ((VHHeader) holder).txt_DeviceTitle.setText(dataItem.deviceName);
            ((VHHeader) holder).txt_FanSpeed.setText("" + dataItem.deviceFanCurrentValue);
            ((VHHeader) holder).iv_DeviceIcon.setImageDrawable(Utils.getSelectedDrawableById(mContext, dataItem.deviceImage));

            if (dataItem.deviceOnOffState == 1) {
                ((VHHeader) holder).card_item.setCardBackgroundColor(Utils.getPrimaryThemeColor(mContext));
            } else {
                ((VHHeader) holder).card_item.setCardBackgroundColor(ContextCompat.getColor(mContext, R.color.cardBGColor));
            }

            if (dataItem.deviceFanCurrentValue > 4) {
                ((VHHeader) holder).iv_Plus.setEnabled(false);
                ((VHHeader) holder).iv_Plus.setColorFilter(ContextCompat.getColor(mContext, R.color.divider), android.graphics.PorterDuff.Mode.SRC_IN);
            } else {
                ((VHHeader) holder).iv_Plus.setEnabled(true);
                ((VHHeader) holder).iv_Plus.setColorFilter(ContextCompat.getColor(mContext, R.color.blackColor), android.graphics.PorterDuff.Mode.SRC_IN);
            }

            if (dataItem.deviceFanCurrentValue < 1) {
                ((VHHeader) holder).iv_Minus.setEnabled(false);
                ((VHHeader) holder).iv_Minus.setColorFilter(ContextCompat.getColor(mContext, R.color.divider), android.graphics.PorterDuff.Mode.SRC_IN);
            } else {
                ((VHHeader) holder).iv_Minus.setEnabled(true);
                ((VHHeader) holder).iv_Minus.setColorFilter(ContextCompat.getColor(mContext, R.color.blackColor), android.graphics.PorterDuff.Mode.SRC_IN);
            }


            ((VHHeader) holder).iv_Plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (dataItem.deviceFanCurrentValue < 5) {
                        clickListener.onFanFunctionClick(dataItem, 1, position);
                    }
                }
            });
            ((VHHeader) holder).iv_Minus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (dataItem.deviceFanCurrentValue > 0) {
                        clickListener.onFanFunctionClick(dataItem, 0, position);
                    }
                }
            });
            ((VHHeader) holder).card_item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    clickListener.onItemClick(dataItem, position);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return integers.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (isPositionHeader(position))
            return TYPE_HEADER;
        return TYPE_ITEM;
    }

    private boolean isPositionHeader(int position) {
        return getItem(position).deviceType == 1;
    }

    private Device getItem(int position) {
        return integers.get(position);
    }


    static class VHItem extends RecyclerView.ViewHolder {
        CardView card_item;
        private TextView txt_DeviceTitle;
        private ImageView iv_DeviceIcon,ivChildLock,ivSchedule;

        public VHItem(View itemView) {
            super(itemView);
            itemView.setTag(getAdapterPosition());
            card_item = itemView.findViewById(R.id.card_item);
            txt_DeviceTitle = itemView.findViewById(R.id.txt_DeviceTitle);
            iv_DeviceIcon = itemView.findViewById(R.id.iv_DeviceIcon);
            ivChildLock = itemView.findViewById(R.id.ivChildLock);
            ivSchedule = itemView.findViewById(R.id.ivSchedule);
//            lightOnOff.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    clickListener.onItemClick(itemView, getAdapterPosition());
//                }
//            });
        }
    }

    static class VHHeader extends RecyclerView.ViewHolder {
        CardView card_item;
        TextView txt_DeviceTitle, txt_FanSpeed;
        ImageView iv_DeviceIcon, iv_Minus, iv_Plus;

        public VHHeader(View itemView) {
            super(itemView);

            card_item = itemView.findViewById(R.id.card_item);
            txt_DeviceTitle = itemView.findViewById(R.id.txt_DeviceTitle);
            txt_FanSpeed = itemView.findViewById(R.id.txt_FanSpeed);
            iv_DeviceIcon = itemView.findViewById(R.id.iv_DeviceIcon);
            iv_Minus = itemView.findViewById(R.id.iv_Minus);
            iv_Plus = itemView.findViewById(R.id.iv_Plus);
        }
    }

}