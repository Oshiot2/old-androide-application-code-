package com.eston.adapter;

import android.content.Context;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.eston.R;
import com.eston.dataBase.model.Room;
import com.eston.interfaces.ClickListener;
import com.eston.interfaces.HomeAdapterItemClickListener;
import com.eston.models.HomeItems;

import java.io.File;
import java.util.ArrayList;

public class HomeItemsListAdapter extends RecyclerView.Adapter<HomeItemsListAdapter.MyViewHolder> {

    // Context
    private Context mContext;

    // List of Home Items
    private ArrayList<Room> homeItemsArrayList;

    // OnClick Listener
    private HomeAdapterItemClickListener clickListener;

    private Integer size;

    /**
     * Conductor
     *
     * @param mContext
     * @param homeItemsArrayList
     */
    public HomeItemsListAdapter(Context mContext, ArrayList<Room> homeItemsArrayList, HomeAdapterItemClickListener clickListener) {
        this.mContext = mContext;
        this.homeItemsArrayList = homeItemsArrayList;
        this.clickListener = clickListener;
        this.size = size;
    }

    @Override
    public HomeItemsListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_home_items_list_item, parent, false);

        return new HomeItemsListAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final HomeItemsListAdapter.MyViewHolder holder, int position) {

        Room homeItems = homeItemsArrayList.get(position);
        holder.txt_RoomName.setText(homeItems.roomName);
        Log.e("TAG ", "homeItems.getActiveDevicesCount() " + homeItems.getActiveDevicesCount());
        holder.noOfDevices.setText((homeItems.getActiveDevicesCount() == 0 ? "No" : homeItems.getActiveDevicesCount()) + " active device");

        holder.iv_DeleteRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickListener.onDeleteClick(homeItems, holder.getAdapterPosition());
            }
        });
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickListener.onItemClick(homeItems, holder.getAdapterPosition());
            }
        });
        if (homeItems.roomImage != null && !homeItems.roomImage.equals("")) {
            try {
                Glide.with(mContext)
                        .load(Uri.fromFile(new File(homeItems.roomImage)))
                        .centerCrop()
                        .placeholder(R.drawable.bed_room_new)
                        .into(holder.imageView);
            } catch (Exception e) {
                holder.imageView.setImageResource(R.drawable.bed_room_new);
            }
        } else {
            holder.imageView.setImageResource(R.drawable.bed_room_new);
        }
    }

    @Override
    public int getItemCount() {
        return homeItemsArrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        private CardView cardView;
        private ImageView imageView, iv_DeleteRoom;
        private TextView txt_RoomName, noOfDevices;

        private MyViewHolder(final View view) {
            super(view);
            cardView = (CardView) view.findViewById(R.id.home_items_cardview);
            imageView = (ImageView) view.findViewById(R.id.imageView);
            iv_DeleteRoom = (ImageView) view.findViewById(R.id.iv_DeleteRoom);
            txt_RoomName = (TextView) view.findViewById(R.id.txt_RoomName);
            noOfDevices = (TextView) view.findViewById(R.id.no_of_devices);


        }
    }
}
