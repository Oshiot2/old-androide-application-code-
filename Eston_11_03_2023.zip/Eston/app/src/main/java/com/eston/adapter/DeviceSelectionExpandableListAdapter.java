package com.eston.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.eston.R;
import com.eston.dataBase.model.Device;
import com.eston.dataBase.model.Room;

import java.util.ArrayList;

public class DeviceSelectionExpandableListAdapter extends BaseExpandableListAdapter {

    private Context _context;
    private ArrayList<Room> rooms;

    public DeviceSelectionExpandableListAdapter(Context context, ArrayList<Room> rooms) {
        this._context = context;
        this.rooms = rooms;
    }

    @Override
    public Object getChild(int groupPosition, int childPosititon) {
        return this.rooms.get(groupPosition).devices.get(childPosititon);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(int groupPosition, final int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        final Device childText = (Device) getChild(groupPosition, childPosition);

        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this._context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.list_item, null);
        }
        TextView txtListChild = (TextView) convertView.findViewById(R.id.lblListItem);
        txtListChild.setText((childText.devicePOS+1) + " " + childText.deviceName);
        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return this.rooms.get(groupPosition).devices.size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return this.rooms.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return this.rooms.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        Room headerTitle = (Room) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this._context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.list_group, null);
        }

        TextView lblListHeader = (TextView) convertView.findViewById(R.id.lblListHeader);
        lblListHeader.setTypeface(null, Typeface.BOLD);
        lblListHeader.setText(headerTitle.roomName);
        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}