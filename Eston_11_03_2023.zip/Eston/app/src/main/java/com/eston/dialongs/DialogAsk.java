package com.eston.dialongs;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;


public class DialogAsk {
    private String msg;
    private AskForDelete askForDelete;
    private Context context;

    public DialogAsk(Context context, String msg, AskForDelete askForDelete) {
        this.context = context;
        this.msg = msg;
        this.askForDelete = askForDelete;
    }

    public void show(boolean cancelable) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        alertDialogBuilder.setMessage(msg);
        alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int arg1) {
                dialog.dismiss();
                askForDelete.onOkClick();
            }
        });
        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                askForDelete.onCancelClick();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.setCancelable(cancelable);
        alertDialog.setCanceledOnTouchOutside(cancelable);
        alertDialog.show();

    }
}
