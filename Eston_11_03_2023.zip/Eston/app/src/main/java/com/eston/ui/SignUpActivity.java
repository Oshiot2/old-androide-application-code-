package com.eston.ui;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.text.method.SingleLineTransformationMethod;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.eston.EstonApp;
import com.eston.R;
import com.eston.utils.Constants;
import com.eston.utils.Utils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

public class SignUpActivity extends AppCompatActivity {
    public static final String TAG = SignUpActivity.class.getName();

    private ProgressDialog progressDialog;
    TextInputEditText edtEmailAddress, edtPassword, edtRePassword, edtPin, edtRePin;
    Button SignUp;
    TextView SignIn;
    CheckBox cbPassword,cbRePassword,cbPin,cbRePin;

    private FirebaseAuth auth;

    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;

    @Override
    public void onBackPressed() {
        // super.onBackPressed();
        overridePendingTransition(R.anim.anim_trans_right_in, R.anim.anim_trans_right_out);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_signup2);

        edtEmailAddress = findViewById(R.id.edtEmailid);
        edtPassword = findViewById(R.id.edtPassword);
        edtRePassword = findViewById(R.id.edtRePassword);
        edtPin = findViewById(R.id.edtPin);
        edtRePin = findViewById(R.id.edtRePin);
        SignUp = findViewById(R.id.btn_SignUp);
        SignIn = findViewById(R.id.txt_SignIn);
        cbPassword = findViewById(R.id.cbPassword);
        cbRePassword = findViewById(R.id.cbRePassword);
        cbPin = findViewById(R.id.cbPin);
        cbRePin = findViewById(R.id.cbRePin);

        //initialise firebase
        initFirebase();

        cbPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtPassword.getTransformationMethod().getClass().getSimpleName().equals("PasswordTransformationMethod")) {
                    edtPassword.setTransformationMethod(new SingleLineTransformationMethod());
                } else {
                    edtPassword.setTransformationMethod(new PasswordTransformationMethod());
                }
                edtPassword.setSelection(edtPassword.getText().length());
            }
        });

        cbRePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtRePassword.getTransformationMethod().getClass().getSimpleName().equals("PasswordTransformationMethod")) {
                    edtRePassword.setTransformationMethod(new SingleLineTransformationMethod());
                } else {
                    edtRePassword.setTransformationMethod(new PasswordTransformationMethod());
                }
                edtRePassword.setSelection(edtRePassword.getText().length());
            }
        });

        cbPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtPin.getTransformationMethod().getClass().getSimpleName().equals("PasswordTransformationMethod")) {
                    edtPin.setTransformationMethod(new SingleLineTransformationMethod());
                } else {
                    edtPin.setTransformationMethod(new PasswordTransformationMethod());
                }
                edtPin.setSelection(edtPin.getText().length());
            }
        });

        cbRePin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtRePin.getTransformationMethod().getClass().getSimpleName().equals("PasswordTransformationMethod")) {
                    edtRePin.setTransformationMethod(new SingleLineTransformationMethod());
                } else {
                    edtRePin.setTransformationMethod(new PasswordTransformationMethod());
                }
                edtRePin.setSelection(edtRePin.getText().length());
            }
        });



        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isValidData()) {
                    if (Build.VERSION.SDK_INT >= 23) {
                        setPermission();
                    } else {
                        startSetUpActivity();
                    }
                }
            }
        });
        SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }


    private void setPermission() {
        Utils.setRunTimePermission(SignUpActivity.this);

        if (ActivityCompat.checkSelfPermission(SignUpActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(SignUpActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startSetUpActivity();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        // If request is cancelled, the result arrays are empty.
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startSetUpActivity();
        }
    }

    private boolean isValidData() {
        String msg = "";
        boolean error = false;
        if (edtEmailAddress.getText().toString().isEmpty()) {
            error = true;
            msg = getString(R.string.please_enter) + " " + getString(R.string.email_address).toLowerCase();
            edtEmailAddress.requestFocus();
        } else if (!Utils.validateEmail(edtEmailAddress.getText().toString().trim())) {
            error = true;
            msg = getString(R.string.please_enter) + " " + getString(R.string.valid_email_address).toLowerCase();
            edtEmailAddress.requestFocus();
        } else if (edtPassword.getText().toString().isEmpty()) {
            error = true;
            msg = getString(R.string.please_enter) + " " + getString(R.string.password).toLowerCase();
            edtPassword.requestFocus();
        } else if (edtPassword.getText().toString().length() < 5) {
            //System.out.println("Not Valid");
            error = true;
            msg = getString(R.string.password_should_be_eight_character_including_upper_case_lower_case_number_and_special_character);
        } else if (edtRePassword.getText().toString().isEmpty()) {
            error = true;
            msg = getString(R.string.please_enter) + " " + getString(R.string.confirm_password).toLowerCase();
            edtRePassword.requestFocus();
        } else if (!edtPassword.getText().toString().trim().equals(edtRePassword.getText().toString().trim())) {
            error = true;
            msg = getString(R.string.both_password_does_not_match);
            edtRePassword.requestFocus();
        } else if (edtPin.getText().toString().isEmpty()) {
            error = true;
            msg = getString(R.string.enter_pin);
            edtPin.requestFocus();
        } else if (edtPin.getText().toString().length() != 4) {
            error = true;
            msg = getString(R.string.wrong_pin);
            edtPin.requestFocus();
        } else if (edtRePin.getText().toString().isEmpty()) {
            error = true;
            msg = "Please enter Re-pin";
            edtRePin.requestFocus();
        } else if (!edtPin.getText().toString().trim().equals(edtRePin.getText().toString().trim())) {
            error = true;
            msg = getString(R.string.both_pin_does_not_match);
            edtRePin.requestFocus();
        }

        if (msg.isEmpty()) {
            error = false;
            //Toast.makeText(this, ""+msg, Toast.LENGTH_SHORT).show();
        } else {
            error = true;
            Toast.makeText(this, "" + msg, Toast.LENGTH_SHORT).show();
        }
        return error;
    }

    public void initFirebase() {
//Get Firebase auth instance
        auth = FirebaseAuth.getInstance();
        mFirebaseInstance = FirebaseDatabase.getInstance();
//        mFirebaseInstance.setPersistenceEnabled(true);

        mFirebaseDatabase = mFirebaseInstance.getReference("users");
        mFirebaseDatabase.keepSynced(true);
    }


    private void startSetUpActivity() {

        if (Utils.isOnline(this)) {
            //show progress bar
            progressDialog = Utils.showProgressDialog(this, getString(R.string.msg_loading), false);

            String emailAddress = edtEmailAddress.getText().toString().trim();
            String password = edtPassword.getText().toString().trim();
            String pin = edtPin.getText().toString().trim();

            auth.createUserWithEmailAndPassword(emailAddress, password)
                    .addOnCompleteListener(SignUpActivity.this,
                            new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    //dismiss progressbar
                                    Utils.dismissProgressDialog(progressDialog);

                                    if (!task.isSuccessful()) {
                                        //display message like user is already register
                                        // or your account disable from firebase
                                        Toast.makeText(SignUpActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    } else {

                                        Log.e(TAG, "RESULT UID :::: " + task.getResult().getUser().getUid());
                                        EstonApp.preferencePutString(PREF_USER_UID, task.getResult().getUser().getUid());
                                        Toast.makeText(SignUpActivity.this, "Registrations done successfully.\nPlease try to login with same credentials!!", Toast.LENGTH_SHORT).show();

                                        //insert setting parameter in firebase.
                                        HashMap<String, Object> result = new HashMap<>();
                                        result.put(Constants.SETTINGS.PIN, pin);
                                        result.put(Constants.SETTINGS.SERVERTYPE, 1);

                                        mFirebaseDatabase
                                                .child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                                                .child(Constants.SETTINGS.SETTINGS)
                                                .updateChildren(result, new DatabaseReference.CompletionListener() {
                                                    @Override
                                                    public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                                        onBackPressed();
                                                    }
                                                });
                                    }
                                }
                            });
        }
    }

}
