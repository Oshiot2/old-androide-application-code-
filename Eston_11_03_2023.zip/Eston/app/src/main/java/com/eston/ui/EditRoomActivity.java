package com.eston.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bartoszlipinski.recyclerviewheader2.RecyclerViewHeader;
import com.bumptech.glide.Glide;
import com.eston.EstonApp;
import com.eston.R;
import com.eston.adapter.EditRoomDevicesListAdapter;
import com.eston.dataBase.model.Device;
import com.eston.dataBase.model.Room;
import com.eston.dialongs.AskFroPin;
import com.eston.dialongs.PhotoSelectionAsk;
import com.eston.dialongs.PhotoSelectionListeners;
import com.eston.utils.Constants;
import com.eston.utils.Utils;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yalantis.ucrop.UCrop;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.eston.utils.Constants.ICON_SELECTION_ACTIVITY_REQUEST_CODE;
import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

public class EditRoomActivity extends AppCompatActivity implements EditRoomDevicesListAdapter.ClickListener {

    private String TAG = EditRoomActivity.class.getName();

    private Context mContext;
    private Toolbar toolbar;
//    private TextView toolbar_Title, txt_Save;
    private ImageView addRoomImage, iv_room_image;
    private RecyclerView recyclerView;
    EditRoomDevicesListAdapter roomDevicesListAdapter;
    private File destination;
    private Uri imageToUploadUri;
    private String filePath = "";
    private String pin = "";
    private String MACID = "";
    private ProgressDialog progressDialog;
    private Button btnUpdate;

    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;
    private MqttHelper mqttHelper;
    private Room topicsHelper;
    ArrayList<Room> roomArrayList = new ArrayList<>();

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        overridePendingTransition(R.anim.anim_trans_right_in, R.anim.anim_trans_right_out);
        if (mqttHelper != null)
            mqttHelper.unSubscribeTopic(topicsHelper.getSubscribeAddress(MACID));
        Intent returnIntent = new Intent();
        Bundle args = new Bundle();
        args.putSerializable(Constants.ROOMS, (Serializable) roomArrayList);
        args.putSerializable(Constants.TOPICS, topicsHelper);
        returnIntent.putExtra("BUNDLE", args);
        setResult(Constants.ROOM_ACTIVITY_RESULT_CODE, returnIntent);
        finish();
    }

    private void getIntentData() {
        if (getIntent() != null) {
            Bundle args = getIntent().getBundleExtra("BUNDLE");
            assert args != null;
            topicsHelper = (Room) args.getSerializable(Constants.TOPICS);
            roomArrayList = (ArrayList<Room>) args.getSerializable(Constants.ROOMS);

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_edit_room2);

        mContext = this;

        /*
         * Get Intent Data
         * */
        getIntentData();

        /*
         * Init Toolbar
         * */
        initToolbar();

        /*
         * Init View
         * */
        initView();

        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference("users");
        mFirebaseDatabase.keepSynced(true);

        checkHubAdded();

    }

    private void initToolbar() {
//        toolbar = findViewById(R.id.toolbar);
        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void initView() {
        recyclerView = findViewById(R.id.devices_recyclerview);
        iv_room_image = findViewById(R.id.iv_room_image_editRoom);
        addRoomImage = findViewById(R.id.iv_add_room_image);
        btnUpdate = findViewById(R.id.btnUpdate);

        recyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        roomDevicesListAdapter = new EditRoomDevicesListAdapter(mContext, topicsHelper.devices, EditRoomActivity.this);
        recyclerView.setAdapter(roomDevicesListAdapter);

//        RecyclerViewHeader recyclerHeader = (RecyclerViewHeader) findViewById(R.id.header);
//        recyclerHeader.attachTo(recyclerView);

        try {
            roomDevicesListAdapter.roomName = topicsHelper.roomName;
            roomDevicesListAdapter.notifyItemChanged(0);
            try {
                Glide.with(mContext)
                        .load(Uri.fromFile(new File(topicsHelper.roomImage)))
                        .centerCrop()
                        .placeholder(R.drawable.bed_room)
                        .into(iv_room_image);
            } catch (Exception e) {
                iv_room_image.setImageResource(R.drawable.bed_room);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        addRoomImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Utils.checkPermission(EditRoomActivity.this)) {
                    PhotoSelectionAsk photoSelectionAsk = new PhotoSelectionAsk(mContext, "Header Photo", new PhotoSelectionListeners() {
                        @Override
                        public void onCameraClick() {
                            captureImageFromCamera();
                        }

                        @Override
                        public void onGalleryClick() {
                            selectImageFromGallery();
                        }

                        @Override
                        public void onRemoveClick() {
                            filePath = "";
                            destination = null;
                            imageToUploadUri = null;
                            iv_room_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_my_room));
                        }
                    });
                    photoSelectionAsk.show();

                }
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("CheckResult")
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(roomDevicesListAdapter.roomName)) {
                    Toast.makeText(mContext, "Please enter room name", Toast.LENGTH_SHORT).show();
                    return;
                }

                for (int i = 0; i < topicsHelper.devices.size(); i++) {
                    if (TextUtils.isEmpty(topicsHelper.devices.get(i).deviceName)) {
                        Toast.makeText(mContext, "Please enter device name at position " + (i + 1), Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                progressDialog = Utils.showProgressDialog(mContext, getString(R.string.msg_loading), false);
                topicsHelper.roomName = roomDevicesListAdapter.roomName;

                DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.ROOMS_TABLE.ROOMS).child(topicsHelper.roomUUID);

                Map<String, Object> map = new HashMap<>();
                map.put(Constants.ROOMS_TABLE.NAME, roomDevicesListAdapter.roomName);
                if (filePath != null && !filePath.isEmpty()) {
                    map.put(Constants.ROOMS_TABLE.IMAGE, filePath);
                    topicsHelper.roomImage = filePath;
                }
                Log.e(TAG, "map " + map);
                namesRef.updateChildren(map);
                for (int i = 0; i < topicsHelper.devices.size(); i++) {
                    Utils.getInstance().hideSoftKeyboard(EditRoomActivity.this);
                    namesRef.child(Constants.ROOMS_TABLE.DEVICES)
                            .child(String.valueOf(topicsHelper.devices.get(i).did))
                            .updateChildren(topicsHelper.devices.get(i).toMap());
                }
                Utils.dismissProgressDialog(progressDialog);
                onBackPressed();

//                namesRef.updateChildren(map).addOnSuccessListener(new OnSuccessListener<Void>() {
//                    @Override
//                    public void onSuccess(Void runnable) {
//                        for (int i = 0; i < topicsHelper.devices.size(); i++) {
//                            Utils.getInstance().hideSoftKeyboard(EditRoomActivity.this);
//                            namesRef.child(Constants.ROOMS_TABLE.DEVICES)
//                                    .child(String.valueOf(topicsHelper.devices.get(i).did))
//                                    .updateChildren(topicsHelper.devices.get(i).toMap());
//                        }
//                        Utils.dismissProgressDialog(progressDialog);
//                        onBackPressed();
//                    }
//                }).addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception runnable) {
//                        Utils.dismissProgressDialog(progressDialog);
//                        Toast.makeText(mContext, "Error " + runnable.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                });
            }
        });
    }

    private void checkHubAdded() {
        String firebaseUserId = EstonApp.preferenceGetString(PREF_USER_UID, "");
        DatabaseReference userRef = mFirebaseDatabase.child(firebaseUserId).child(Constants.SETTINGS.SETTINGS);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    Object td = dataSnapshot.getValue();
                    HashMap<String, String> settings = (HashMap<String, String>) td;
                    Log.e(TAG, "settings " + settings);
                    if (settings != null && settings.get(Constants.SETTINGS.PIN) != null && !Objects.requireNonNull(settings.get(Constants.SETTINGS.PIN)).isEmpty()) {
                        pin = settings.get(Constants.SETTINGS.PIN);
                    }
                    if (settings != null && !Objects.requireNonNull(settings.get(Constants.SETTINGS.MACID)).isEmpty()) {
                        MACID = settings.get(Constants.SETTINGS.MACID);
                        initMqtt();
                    } else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        builder.setTitle("Error");
                        builder.setCancelable(false);
                        builder.setMessage("Can't fetch hub from server.\nPlease setup hub from settings!!");
                        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                onBackPressed();
                            }
                        });
                        builder.show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "error " + error.getMessage());
            }
        });
    }

    private void initMqtt() {
        try {
            mqttHelper = EstonApp.getMqttHelper();
            mqttHelper.subscribeTopic(topicsHelper.getSubscribeAddress(MACID));
            mqttHelper.setCallback(new MqttCallbackExtended() {
                @Override
                public void connectComplete(boolean reconnect, String serverURI) {
                    Log.e(TAG, "=======connectComplete==========");
                }

                @Override
                public void connectionLost(Throwable cause) {
                    Log.e(TAG, "=======connectionLost==========");
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    Log.e(TAG, "=======topic==========" + topic);
                    Log.e(TAG, "=======messageArrived==========" + message);

                    if (topicsHelper.getSubscribeAddress(MACID).equals(topic)) {
                        if (message != null && message.toString().length() == 31) {
                            String data = "", macId = "";
                            macId = message.toString().substring((message.toString().indexOf("M") + 1), message.toString().indexOf("R"));
                            data = message.toString().substring((message.toString().indexOf("R") + 1), message.toString().indexOf("@"));
                            Log.e(TAG, "macId " + macId);
                            Log.e(TAG, "topicsHelper.roomUUID " + topicsHelper.roomUUID);
                            Log.e(TAG, "data " + data);

                            if (macId.equalsIgnoreCase(topicsHelper.roomUUID)) {

                                for (int i = 0; i < topicsHelper.devices.size(); i++) {
                                    if (topicsHelper.devices.get(i).devicePOS <= 5) {
                                        topicsHelper.devices.get(i).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(i)));
                                    } else if (topicsHelper.devices.get(i).devicePOS == 6) {
                                        topicsHelper.devices.get(i).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
                                        topicsHelper.devices.get(i).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
                                    } else if (topicsHelper.devices.get(i).devicePOS > 6 && topicsHelper.devices.get(i).devicePOS <= 12) {
                                        topicsHelper.devices.get(i).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(i + 1)));
                                    } else if (topicsHelper.devices.get(i).devicePOS == 13) {
                                        topicsHelper.devices.get(i).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(14)));
                                        topicsHelper.devices.get(i).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(15)));
                                    }
                                }
                                roomDevicesListAdapter.notifyDataSetChanged();
                            }
                        }
                    }

                    for (int i = 0; i < roomArrayList.size(); i++) {
                        if (topic.toString().equals(roomArrayList.get(i).getSubscribeAddress(MACID))) {
                            if (message != null && message.toString().length() == 31) {
                                String data = "", macId = "";
                                macId = message.toString().substring((message.toString().indexOf("M") + 1), message.toString().indexOf("R"));
                                data = message.toString().substring((message.toString().indexOf("R") + 1), message.toString().indexOf("@"));
                                Log.e(TAG, "macId " + macId);
                                Log.e(TAG, "roomArrayList.get(i).roomUUID " + roomArrayList.get(i).roomUUID);
                                Log.e(TAG, "data " + data);

                                if (macId.equalsIgnoreCase(roomArrayList.get(i).roomUUID)) {

                                    for (int j = 0; j < roomArrayList.get(i).devices.size(); j++) {
                                        if (roomArrayList.get(i).devices.get(j).devicePOS <= 5) {
                                            roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(j)));
                                        } else if (roomArrayList.get(i).devices.get(j).devicePOS == 6) {
                                            roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
                                            roomArrayList.get(i).devices.get(j).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
                                        } else if (roomArrayList.get(i).devices.get(j).devicePOS > 6 && topicsHelper.devices.get(i).devicePOS <= 12) {
                                            roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(j + 1)));
                                        } else if (roomArrayList.get(i).devices.get(j).devicePOS == 13) {
                                            roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(14)));
                                            roomArrayList.get(i).devices.get(j).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(15)));
                                        }
                                    }
                                    updateOnDatabase(roomArrayList.get(i), roomArrayList.get(i).devices);
                                    break;
                                }
                            }
                        }
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    Log.e(TAG, "=======deliveryComplete==========");
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Capture Image from Camera
    private void captureImageFromCamera() {

        Intent chooserIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File directory = Utils.getRootDir(Constants.DIRECTORY.PROFILE_DIR, Constants.DIRECTORY.IMAGE_DIR);
        destination = new File(directory, setImageName());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
            imageToUploadUri = FileProvider.getUriForFile(mContext, getApplicationContext().getPackageName() + ".provider", destination);
        else {
            imageToUploadUri = Uri.fromFile(destination);
        }
        chooserIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageToUploadUri);
        chooserIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        chooserIntent.putExtra("return-data", true);
        startActivityForResult(chooserIntent, Constants.PHOTO_CONST.TYPE_PHOTO_PICK_FROM_CAMERA);
        overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);

    }

    // Select Image from Gallery
    private void selectImageFromGallery() {

        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Complete action using"), Constants.PHOTO_CONST.TYPE_PHOTO_PICK_FROM_FILE);
        overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);

    }

    private String setImageName() {
        String name = "";
        String imgExt = ".jpg";
        name = Utils.getDateString() + imgExt;
        return name;
    }

    @Override
    public void onItemClick(View view, int position) {
        Intent i = new Intent(this, IconSelectionActivity.class);
        i.putExtra("position", position);
        startActivityForResult(i, ICON_SELECTION_ACTIVITY_REQUEST_CODE);
        overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
    }

    @Override
    public void onItemDeleteClick(View view, int position) {
        Device device = topicsHelper.devices.get(position);
        device.isDeleted = 1;
        AskFroPin askFroPin = new AskFroPin(this, "Verify Pin for delete device!", new AskFroPin.AskForPinListener() {
            @Override
            public void onDone() {
                progressDialog = Utils.showProgressDialog(EditRoomActivity.this, "Deleting...", false);
                Utils.getInstance().hideSoftKeyboard(EditRoomActivity.this);
                DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.ROOMS_TABLE.ROOMS)
                        .child(topicsHelper.roomUUID)
                        .child(Constants.ROOMS_TABLE.DEVICES)
                        .child(String.valueOf(device.did));
                namesRef.updateChildren(device.toMap());
                Utils.dismissProgressDialog(progressDialog);
                topicsHelper.devices.remove(position);
                roomDevicesListAdapter.notifyItemRemoved(position + 1);

//                namesRef.updateChildren(device.toMap()).addOnSuccessListener(new OnSuccessListener<Void>() {
//                    @Override
//                    public void onSuccess(Void runnable) {
//                        Utils.dismissProgressDialog(progressDialog);
//                        topicsHelper.devices.remove(position);
//                        roomDevicesListAdapter.notifyItemRemoved(position + 1);
//                    }
//                }).addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(Exception runnable) {
//                        Utils.dismissProgressDialog(progressDialog);
//                        if (runnable != null)
//                            Toast.makeText(EditRoomActivity.this, "Error " + runnable.getMessage(), Toast.LENGTH_SHORT).show();
//                        else
//                            Toast.makeText(EditRoomActivity.this, "Something was wrong, please try again later.", Toast.LENGTH_SHORT).show();
//                    }
//                });
            }
        });
        askFroPin.show(pin);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "onActivityResult requestCode " + requestCode + " resultCode " + resultCode);
        if (requestCode == ICON_SELECTION_ACTIVITY_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                Integer position = data.getIntExtra("position", 0);
                Integer result = data.getIntExtra("result", 0);
                topicsHelper.devices.get(position).deviceImage = result;
                roomDevicesListAdapter.notifyItemChanged(position + 1);
            }
        } else if (requestCode == Constants.PHOTO_CONST.TYPE_PHOTO_PICK_FROM_CAMERA && resultCode == RESULT_OK) {
            if (imageToUploadUri != null) {
                String mFilePath = destination.getPath();
                imageToUploadUri = Uri.fromFile(new File(mFilePath));
                doCrop();
            }
        } else if (requestCode == Constants.PHOTO_CONST.TYPE_PHOTO_PICK_FROM_FILE && resultCode == RESULT_OK) {

            String mFilePath = Utils.getRealPathFromURI(mContext, data.getData());
            if (!TextUtils.isEmpty(mFilePath)) {
                imageToUploadUri = Uri.fromFile(new File(mFilePath));
                doCrop();
            } else {
                Toast.makeText(mContext, "Can't find file", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == UCrop.REQUEST_CROP && resultCode == RESULT_OK) {
            try {
                String imgProfilePath = imageToUploadUri.getPath();
                if (imgProfilePath != null) {
                    Log.e(TAG, "imgProfilePath " + Uri.fromFile(new File(imgProfilePath)).toString());
                    filePath = imgProfilePath;
                    try {
                        Glide.with(mContext)
                                .load(Uri.fromFile(new File(filePath)))
                                .centerCrop()
                                .placeholder(R.drawable.ic_my_room)
                                .into(iv_room_image);
                    } catch (Exception e) {
                        e.printStackTrace();
                        iv_room_image.setImageResource(R.drawable.ic_my_room);
                    }
                } else {
                    Toast.makeText(mContext, "Can't find file", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Crop Image
     */
    private void doCrop() {
        UCrop.of(imageToUploadUri, imageToUploadUri)
                .withAspectRatio(3, 2)
                .start(EditRoomActivity.this);

    }


    private void updateOnDatabase(Room room, ArrayList<Device> devices) {
        try {
            for (int i = 0; i < devices.size(); i++) {
                Utils.getInstance().hideSoftKeyboard(this);
                DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.ROOMS_TABLE.ROOMS)
                        .child(room.roomUUID)
                        .child(Constants.ROOMS_TABLE.DEVICES)
                        .child(String.valueOf(devices.get(i).did));
                namesRef.updateChildren(devices.get(i).toMap());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
