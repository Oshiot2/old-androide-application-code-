package com.eston.webservice;

/**
 * Created by techno-30 on 24/1/18.
 */

import android.content.Context;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;

import com.eston.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Class which has the common method of webservices
 */

public class WSUtils {

    private String TAG = WSUtils.class.getName();

    String callServiceHttpGet(final Context context, final String url) {
        String responseString;
        try {

            final OkHttpClient okHttpClient = new OkHttpClient();
            final OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient().newBuilder();
            okHttpClientBuilder.connectTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);
            okHttpClientBuilder.readTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);


            final Request.Builder requestBuilder = new Request.Builder();
            requestBuilder.addHeader("Content-Type", "application/json");
            requestBuilder.url(url);

            final Request request = requestBuilder.build();
            final Response response = okHttpClient.newCall(request).execute();
            responseString = response.body().string();
            Log.e(TAG, "responseString==>  " + responseString);
            if (TextUtils.isEmpty(responseString) || !isJSONValid(responseString)) {
                responseString = getNetWorkError(context);
            }
        } catch (IOException e) {
            e.printStackTrace();
            responseString = getNetWorkError(context);
        }
        return responseString;
    }

    String callServiceHttpGet(final Context context, final String url, RequestBody requestBody) {
        String responseString;
        try {

            final OkHttpClient okHttpClient = new OkHttpClient();
            final OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient().newBuilder();
            okHttpClientBuilder.connectTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);
            okHttpClientBuilder.readTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);

            final Request.Builder requestBuilder = new Request.Builder();
            //requestBuilder.addHeader("Content-Type", "application/x-www-form-urlencoded");
            requestBuilder.url(url);
            requestBuilder.post(requestBody);
            Log.e(TAG, "requestBody==>  " + requestBody);
            final Request request = requestBuilder.build();
            final Response response = okHttpClient.newCall(request).execute();
            responseString = response.body().string();
            Log.e(TAG, "responseString==>  " + responseString);
            if (TextUtils.isEmpty(responseString) || !isJSONValid(responseString)) {
                responseString = getNetWorkError(context);
            }
        } catch (IOException e) {
            e.printStackTrace();
            responseString = getNetWorkError(context);
        }
        return responseString;
    }

    String callServiceHttpGetAuth(final Context context, final String url, RequestBody requestBody) {
        String responseString;
        try {

            final OkHttpClient okHttpClient = new OkHttpClient();
            final OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient().newBuilder();
            okHttpClientBuilder.connectTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);
            okHttpClientBuilder.readTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);
            okHttpClientBuilder.writeTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);

            //final PreferenceUtils preferenceUtils = new PreferenceUtils(context);
            //final String basic = preferenceUtils.getString(preferenceUtils.KEY_AUTH);
            //Log.e(TAG, "basic==>  " + basic);
            final Request.Builder requestBuilder = new Request.Builder();
            //requestBuilder.header("Authorization", basic);
            requestBuilder.url(url);
            requestBuilder.post(requestBody);
            Log.e(TAG, "requestBody==>  " + requestBody);
            final Request request = requestBuilder.build();
            final Response response = okHttpClient.newCall(request).execute();
            responseString = response.body().string();
            Log.e(TAG, "responseString==>  " + responseString);
            if (TextUtils.isEmpty(responseString) || !isJSONValid(responseString)) {
                responseString = getNetWorkError(context);
            }
        } catch (IOException e) {
            e.printStackTrace();
            responseString = getNetWorkError(context);
        }
        return responseString;
    }

    String callServiceHttpPutAuth(final Context context, final String url, RequestBody requestBody) {
        String responseString;
        try {

            final OkHttpClient okHttpClient = new OkHttpClient();
            final OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient().newBuilder();
            okHttpClientBuilder.connectTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);
            okHttpClientBuilder.readTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);

            //final PreferenceUtils preferenceUtils = new PreferenceUtils(context);
            //final String basic = preferenceUtils.getString(preferenceUtils.KEY_AUTH);
            final Request.Builder requestBuilder = new Request.Builder();
            //requestBuilder.header("Authorization", basic);
            requestBuilder.url(url);
            requestBuilder.put(requestBody);
            final Request request = requestBuilder.build();
            final Response response = okHttpClient.newCall(request).execute();
            responseString = response.body().string();
            Log.e(TAG, "responseString==>  " + responseString);
            if (TextUtils.isEmpty(responseString) || !isJSONValid(responseString)) {
                responseString = getNetWorkError(context);
            }
        } catch (IOException e) {
            e.printStackTrace();
            responseString = getNetWorkError(context);
        }
        return responseString;
    }

    String callServiceHttpPost(final Context context, final String url, RequestBody requestBody) {
        String responseString;
        try {

            final OkHttpClient okHttpClient = new OkHttpClient();
            final OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient().newBuilder();
            okHttpClientBuilder.connectTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);
            okHttpClientBuilder.readTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);

            //final PreferenceUtils preferenceUtils = new PreferenceUtils(context);
            //final String basic = preferenceUtils.getString(preferenceUtils.KEY_AUTH);
            //Log.e(TAG, "basic==>  " + basic);
            final Request.Builder requestBuilder = new Request.Builder();
            //requestBuilder.header("Authorization", basic);
            requestBuilder.url(url);
            requestBuilder.post(requestBody);
            Log.e(TAG, "requestBody==>  " + requestBody);
            final Request request = requestBuilder.build();
            final Response response = okHttpClient.newCall(request).execute();
            responseString = response.body().string();
            Log.e(TAG, "responseString==>  " + responseString);
            if (TextUtils.isEmpty(responseString) || !isJSONValid(responseString)) {
                responseString = getNetWorkError(context);
            }
        } catch (IOException e) {
            e.printStackTrace();
            responseString = getNetWorkError(context);
        }
        return responseString;
    }

    Response callServiceHttpPostAuth(final Context context, final String url, RequestBody requestBody) {
        Response finalResponse = null;
        try {

            final OkHttpClient okHttpClient = new OkHttpClient();
            final OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient().newBuilder();
            okHttpClientBuilder.connectTimeout(WSConstants.OTA_TIMEOUT, TimeUnit.SECONDS);
            okHttpClientBuilder.readTimeout(WSConstants.OTA_TIMEOUT, TimeUnit.SECONDS);

            final byte[] content = requestBody.toString().getBytes();

            final Request.Builder requestBuilder = new Request.Builder();
            Log.e(TAG, "=======getAuth======" + getAuth(WSConstants.LOCAL_USERNAME, WSConstants.LOCAL_PASSWORD));
            requestBuilder.addHeader("Authorization", getAuth(WSConstants.LOCAL_USERNAME, WSConstants.LOCAL_PASSWORD));
            requestBuilder.addHeader("Content-Type", "application/octet-stream");
            requestBuilder.addHeader("Content-Length", String.valueOf(requestBody.contentLength()));


            requestBuilder.url(url);
            requestBuilder.post(requestBody);
            Log.e(TAG, "requestBody==>  " + requestBody.contentType());
            Log.e(TAG, "requestBody==>  " + requestBody.contentLength());


            final Request request = requestBuilder.build();
            final Response response = okHttpClient.newCall(request).execute();
            Log.e(TAG, "response==>  " + response);
            if (response != null) {
                finalResponse = response;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return finalResponse;
    }

    Response callServiceHttpGetAuth(final Context context, final String url) {
        Response finalResponse = null;
        try {

            final OkHttpClient okHttpClient = new OkHttpClient();
            final OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient().newBuilder();
            okHttpClientBuilder.connectTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);
            okHttpClientBuilder.readTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);

            //final PreferenceUtils preferenceUtils = new PreferenceUtils(context);
            //final String basic = preferenceUtils.getString(preferenceUtils.KEY_AUTH);
            //Log.e(TAG, "basic==>  " + basic);
            final Request.Builder requestBuilder = new Request.Builder();
            //requestBuilder.header("Authorization", basic);
            requestBuilder.url(url);

            final Request request = requestBuilder.build();
            final Response response = okHttpClient.newCall(request).execute();
            Log.e(TAG, "responseString==>  " + response);
            finalResponse = response;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return finalResponse;
    }


    String calAuthServiceHttpPost(final Context context, final String url, final RequestBody requestBody) {
        Log.e(WSUtils.class.getSimpleName(), String.format("Request String : %s", requestBody));
        String responseString;
        try {
            final OkHttpClient okHttpClient = new OkHttpClient();
            final OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient().newBuilder();
            okHttpClientBuilder.connectTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);
            okHttpClientBuilder.readTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);

            final Request.Builder requestBuilder = new Request.Builder();
//            requestBuilder.addHeader("Content-Type", "application/x-www-form-urlencoded");
//            requestBuilder.addHeader("authKey", "");
            requestBuilder.url(url);
            requestBuilder.post(requestBody);
            final Request request = requestBuilder.build();
            final Response response = okHttpClient.newCall(request).execute();
            responseString = response.body().string();
            Log.e(TAG, "Response = " + response);
            Log.e(TAG, "responseString = " + responseString);
            if (TextUtils.isEmpty(responseString) || !isJSONValid(responseString)) {
                responseString = getNetWorkError(context);
            }
            //Log.e(WSUtils.class.getSimpleName(), String.format("Response String : %s", responseString));
        } catch (IOException e) {
            e.printStackTrace();
            responseString = getNetWorkError(context);
        }
        return responseString;
    }


    String calAuthServiceHttpPostAuth(final Context context, final String url, final RequestBody requestBody) {
        Log.e(WSUtils.class.getSimpleName(), String.format("Request String : %s", requestBody));
        String responseString;
        try {
            final OkHttpClient okHttpClient = new OkHttpClient();
            final OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient().newBuilder();
            okHttpClientBuilder.connectTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);
            okHttpClientBuilder.readTimeout(WSConstants.CONNECTION_TIMEOUT, TimeUnit.SECONDS);

            //final PreferenceUtils preferenceUtils = new PreferenceUtils(context);
            //final String basic = preferenceUtils.getString(preferenceUtils.KEY_AUTH);
            //Log.e(TAG, "basic==>  " + basic);
            final Request.Builder requestBuilder = new Request.Builder();
            //requestBuilder.header("Authorization", basic);
            requestBuilder.url(url);
            requestBuilder.post(requestBody);
            final Request request = requestBuilder.build();
            final Response response = okHttpClient.newCall(request).execute();
            responseString = response.body().string();
            Log.e(TAG, "responseString = " + responseString);
            if (TextUtils.isEmpty(responseString) || !isJSONValid(responseString)) {
                responseString = getNetWorkError(context);
            }
            //Log.e(WSUtils.class.getSimpleName(), String.format("Response String : %s", responseString));
        } catch (IOException e) {
            e.printStackTrace();
            responseString = getNetWorkError(context);
        }
        return responseString;
    }


    /**
     * Generate network error message
     *
     * @param context
     * @return
     */
    private String getNetWorkError(final Context context) {
        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(WSConstants.PARAMS_CODE, 400);
            jsonObject.put(WSConstants.PARAMS_MESSAGE, context.getString(R.string.msg_network_error));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject.toString();
    }

    /**
     * Checks the json is valid or not
     *
     * @param test
     * @return
     */
    private boolean isJSONValid(String test) {
        try {
            new JSONObject(test);
        } catch (JSONException ex) {
            // edited, to include @Arthur's comment
            // e.g. in case JSONArray is valid as well...
            try {
                new JSONArray(test);
            } catch (JSONException ex1) {
                return false;
            }
        }
        return true;
    }

    private String getAuth(String username, String password) {
        // concatenate username and password with colon for authentication
        String credentials = username + ":" + password;
        // create Base64 encodet string
        final String basic =
                "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
        return basic;
    }
}
