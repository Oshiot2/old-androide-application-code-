package com.eston.ui;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.eston.R;
import com.github.furkankaplan.fkblurview.FKBlurView;


public class DummyActivity extends AppCompatActivity {


    RelativeLayout root;
    CardView cv1, cv2, cv3, cv4, cv5, cv6;
    boolean flag1 = true;
    boolean flag2 = true;
    boolean flag3 = true;
    boolean flag4 = true;
    boolean flag5 = true;
    boolean flag6 = true;
    SwitchCompat swc;
    ImageView ivRefresh, ivEdit, ivDelete,iv1,iv2,iv3,iv4,iv5,iv6;
    LinearLayout llContent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dummy);

        initViews();

        cardClicks();

        ivRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Refresh", Toast.LENGTH_SHORT).show();
            }
        });

        ivEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Edit", Toast.LENGTH_SHORT).show();
            }
        });

        ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Delete", Toast.LENGTH_SHORT).show();
            }
        });

        swc.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    llContent.setVisibility(View.VISIBLE);
                } else {
                    llContent.setVisibility(View.GONE);
                }
            }
        });

    }

    private void cardClicks() {
        cv1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                if (flag1) {
//                    cv1.setCardBackgroundColor(getColor(R.color.selectedColor));
                    iv1.setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.selectedColor), android.graphics.PorterDuff.Mode.SRC_IN);
                    flag1 = false;
                } else {
                    flag1 = true;
//                    cv1.setCardBackgroundColor(getColor(R.color.whiteColor));
                    iv1.setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.blackColor), android.graphics.PorterDuff.Mode.SRC_IN);
                }
            }
        });

        cv2.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                if (flag2) {
                    cv2.setCardBackgroundColor(getColor(R.color.selectedColor));
                    flag2 = false;
                } else {
                    flag2 = true;
                    cv2.setCardBackgroundColor(getColor(R.color.whiteColor));
                }
            }
        });

        cv3.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                if (flag3) {
                    cv3.setCardBackgroundColor(getColor(R.color.selectedColor));
                    flag3 = false;
                } else {
                    flag3 = true;
                    cv3.setCardBackgroundColor(getColor(R.color.whiteColor));
                }
            }
        });

        cv4.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                if (flag4) {
                    cv4.setCardBackgroundColor(getColor(R.color.selectedColor));
                    flag4 = false;
                } else {
                    flag4 = true;
                    cv4.setCardBackgroundColor(getColor(R.color.whiteColor));
                }
            }
        });

        cv5.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                if (flag5) {
                    cv5.setCardBackgroundColor(getColor(R.color.selectedColor));
                    flag5 = false;
                } else {
                    flag5 = true;
                    cv5.setCardBackgroundColor(getColor(R.color.whiteColor));
                }
            }
        });

        cv6.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                if (flag6) {
                    cv6.setCardBackgroundColor(getColor(R.color.selectedColor));
                    flag6 = false;
                } else {
                    flag6 = true;
                    cv6.setCardBackgroundColor(getColor(R.color.whiteColor));
                }
            }
        });
    }

    private void initViews() {
        root = findViewById(R.id.root);

        cv1 = findViewById(R.id.cv1);
        cv2 = findViewById(R.id.cv2);
        cv3 = findViewById(R.id.cv3);
        cv4 = findViewById(R.id.cv4);
        cv5 = findViewById(R.id.cv5);
        cv6 = findViewById(R.id.cv6);

        iv1 = findViewById(R.id.iv1);
        iv2 = findViewById(R.id.iv2);
        iv3 = findViewById(R.id.iv3);
        iv4 = findViewById(R.id.iv4);
        iv5 = findViewById(R.id.iv5);
        iv6 = findViewById(R.id.iv6);

        swc = findViewById(R.id.swc);
        ivRefresh = findViewById(R.id.ivRefresh);
        ivEdit = findViewById(R.id.ivEdit);
        ivDelete = findViewById(R.id.ivDelete);
        llContent = findViewById(R.id.llContent);
    }
}