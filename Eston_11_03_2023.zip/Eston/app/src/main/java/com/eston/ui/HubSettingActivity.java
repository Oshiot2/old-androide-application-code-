package com.eston.ui;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.res.ResourcesCompat;

import com.eston.EstonApp;
import com.eston.R;
import com.eston.adapter.CreateRoomDevicesListAdapter;
import com.eston.dataBase.model.Device;
import com.eston.dialongs.AskForDelete;
import com.eston.dialongs.DialogAsk;
import com.eston.utils.Constants;
import com.eston.utils.Utils;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.thanosfisherman.wifiutils.WifiUtils;
import com.thanosfisherman.wifiutils.wifiConnect.ConnectionErrorCode;
import com.thanosfisherman.wifiutils.wifiConnect.ConnectionSuccessListener;
import com.yalantis.ucrop.UCrop;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import static com.eston.utils.Constants.ICON_SELECTION_ACTIVITY_REQUEST_CODE;
import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

public class HubSettingActivity extends AppCompatActivity {

    private String TAG = HubSettingActivity.class.getName();
    private static final int SECOND_ACTIVITY_REQUEST_CODE = 101;

    private Context mContext;
    private Toolbar toolbar;
    private TextView tv_deleteHub;
    private TextView toolbar_Title, txt_MAC, txt_wifiName, txt_wifiPassword;
    private TextInputEditText wifi_name_id, password_id;
    private LinearLayout ll_Add_hub, ll_Hub_data;
    Button connect_button_id, btn_Save;
    private int SERVERTYPE = 0;
    private String HUBID = "", SSID = "", PASSWORD = "";
    private ProgressDialog progressDialog;

    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;
    private MqttHelper mqttHelper;

    @Override
    public void onBackPressed() {
        mqttHelper.unSubscribeTopic(Constants.MQTT.SCAN_NEW_HUB_RESPONSE);
        mqttHelper = EstonApp.getMqttHelperWithReconnect(this.getApplicationContext(), SERVERTYPE);
        Intent returnIntent = new Intent();
        setResult(Constants.ROOM_ACTIVITY_RESULT_CODE, returnIntent);
        finish();
        overridePendingTransition(R.anim.anim_trans_right_in, R.anim.anim_trans_right_out);
    }

    private void getIntentData() {
        if (getIntent() != null) {

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_hub_setting);

        mContext = this;

        /*
         * Get Intent Data
         * */
        getIntentData();

        /*
         * Init Toolbar
         * */
        initToolbar();

        /*
         * Init View
         * */
        initView();

//        mqttHelper = EstonApp.getMqttHelperWithReconnect(this.getApplicationContext(), 0);
        mqttHelper = EstonApp.getMqttHelper();
        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference("users");
        mFirebaseDatabase.keepSynced(true);

        checkHubAdded();

        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.e(TAG, "=======connectComplete========== reconnect " + reconnect + " serverURI " + serverURI);
            }

            @Override
            public void connectionLost(Throwable cause) {
                Log.e(TAG, "=======connectionLost==========" + cause);
            }

            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                try {
                    Log.e(TAG, "=======topic==========" + topic);
                    Log.e(TAG, "=======messageArrived==========" + mqttMessage);
                    String data = "";
                    String mode = ""; //RB827EB538CC0@ //DCA632C96699
                    if (mqttMessage.toString().length() == 14 && topic.equals(Constants.MQTT.SCAN_NEW_HUB_RESPONSE)) {
                        data = mqttMessage.toString().substring((mqttMessage.toString().indexOf("R") + 1), mqttMessage.toString().indexOf("@"));
                        HUBID = data;
                        ll_Hub_data.setVisibility(View.VISIBLE);
                        ll_Add_hub.setVisibility(View.GONE);
                        txt_MAC.setText(HUBID);
                        txt_MAC.setCompoundDrawables(ResourcesCompat.getDrawable(getResources(), R.drawable.ic_round_check_circle_green_24, getTheme()), null, null, null);
                        txt_MAC.setTextColor(ResourcesCompat.getColor(getResources(), R.color.green, getTheme()));
                    } else if (mqttMessage.toString().length() == 3 && topic.equals(Constants.MQTT.WIFI_SUBMIT_RESPONSE)) {
                        if (mqttMessage.toString().equals("R1@")) {
                            Utils.dismissProgressDialog(progressDialog);
                            txt_wifiName.setCompoundDrawables(ResourcesCompat.getDrawable(getResources(), R.drawable.ic_round_check_circle_green_24, getTheme()), null, null, null);
                            txt_wifiPassword.setCompoundDrawables(ResourcesCompat.getDrawable(getResources(), R.drawable.ic_round_check_circle_green_24, getTheme()), null, null, null);
                            txt_wifiName.setText(wifi_name_id.getText().toString().trim());
                            txt_wifiPassword.setText(password_id.getText().toString().trim());
                            txt_wifiName.setTextColor(ResourcesCompat.getColor(getResources(), R.color.green, getTheme()));
                            txt_wifiPassword.setTextColor(ResourcesCompat.getColor(getResources(), R.color.green, getTheme()));
                        } else {
                            Utils.dismissProgressDialog(progressDialog);
                            txt_wifiName.setCompoundDrawables(null, null, null, null);
                            txt_wifiPassword.setCompoundDrawables(null, null, null, null);
                            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Did not find to given wifi.\nPlease try again later", true, HubSettingActivity.this);
                            txt_wifiName.setText("No WIFI Credentials");
                            txt_wifiPassword.setText("");
                            txt_wifiName.setTextColor(ResourcesCompat.getColor(getResources(), R.color.textColorPrimary, getTheme()));
                            txt_wifiPassword.setTextColor(ResourcesCompat.getColor(getResources(), R.color.textColorPrimary, getTheme()));
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "ERROR " + e.getMessage());
                    e.printStackTrace();
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.e(TAG, "=======deliveryComplete==========" + token.getClient().getServerURI());
            }
        });
    }


    private void initToolbar() {
        toolbar = findViewById(R.id.toolbar);
        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        ImageView iv_wifi = findViewById(R.id.iv_wifi);
        iv_wifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
            }
        });

        toolbar_Title = toolbar.findViewById(R.id.txt_title);
        toolbar_Title.setText("Hub Setup");

    }

    private void initView() {
        ll_Add_hub = findViewById(R.id.ll_Add_hub);
        ll_Hub_data = findViewById(R.id.ll_Hub_data);
        txt_MAC = findViewById(R.id.txt_MAC);
        txt_wifiName = findViewById(R.id.txt_wifiName);
        txt_wifiPassword = findViewById(R.id.txt_wifiPassword);
        connect_button_id = findViewById(R.id.connect_button_id);
        wifi_name_id = findViewById(R.id.wifi_name_id);
        password_id = findViewById(R.id.password_id);
        btn_Save = findViewById(R.id.btn_Save);
        tv_deleteHub = findViewById(R.id.tv_deleteHub);
      LinearLayout  ll_wifiSetting = findViewById(R.id.ll_wifiSetting);
        ll_wifiSetting.setVisibility(View.INVISIBLE);
        ll_Add_hub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                initMqtt();

                Intent intent = new Intent(HubSettingActivity.this, ScanBarcodeActivity.class);
                startActivityForResult(intent, SECOND_ACTIVITY_REQUEST_CODE);

//                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
//                boolean gps_enabled = false;
//                boolean network_enabled = false;
//
//                try {
//                    gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
//                } catch (Exception ex) {
//                }
//
//                try {
//                    network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
//                } catch (Exception ex) {
//                }
//
//                if (!gps_enabled && !network_enabled) {
//                    // notify user
//                    new AlertDialog.Builder(HubSettingActivity.this)
//                            .setMessage("GPS Location is not enabled, Please do it from setting")
//                            .setPositiveButton("Setting", new DialogInterface.OnClickListener() {
//                                @Override
//                                public void onClick(DialogInterface paramDialogInterface, int paramInt) {
//                                    startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
//                                }
//                            })
//                            .setNegativeButton("Cancel", null)
//                            .show();
//                } else {
//
//                }
            }
        });

        connect_button_id.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verifyWifi();
//                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
//                boolean gps_enabled = false;
//                boolean network_enabled = false;
//
//                try {
//                    gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
//                } catch (Exception ex) {
//                }
//
//                try {
//                    network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
//                } catch (Exception ex) {
//                }
//
//                if (!gps_enabled && !network_enabled) {
//                    // notify user
//                    new AlertDialog.Builder(HubSettingActivity.this)
//                            .setMessage("GPS Location is not enabled, Please do it from setting")
//                            .setPositiveButton("Setting", new DialogInterface.OnClickListener() {
//                                @Override
//                                public void onClick(DialogInterface paramDialogInterface, int paramInt) {
//                                    startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
//                                }
//                            })
//                            .setNegativeButton("Cancel", null)
//                            .show();
//                } else {
//
//
//                }
            }
        });

        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveHubId();
            }
        });

        tv_deleteHub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogAsk asd = new DialogAsk(HubSettingActivity.this, "Are you sure you want to delete hub?", new AskForDelete() {
                    @Override
                    public void onCancelClick() {

                    }

                    @Override
                    public void onOkClick() {
                        deleteHubId();
                    }
                });
                asd.show(true);

            }
        });
    }

    private void checkHubAdded() {
        String firebaseUserId = EstonApp.preferenceGetString(PREF_USER_UID, "");
        DatabaseReference userRef = mFirebaseDatabase.child(firebaseUserId).child(Constants.SETTINGS.SETTINGS);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    Object td = dataSnapshot.getValue();
                    HashMap<String, Objects> settings = (HashMap<String, Objects>) td;
                    Log.e(TAG, "settings " + settings);
                    if (settings != null) {

                        if (settings.containsKey(Constants.SETTINGS.SERVERTYPE) && settings.get(Constants.SETTINGS.SERVERTYPE) != null
                                && Integer.parseInt(String.valueOf(settings.get(Constants.SETTINGS.SERVERTYPE))) == 1) {
                            SERVERTYPE = 1;
                        } else {
                            SERVERTYPE = 0;
                        }

                        if (settings.containsKey(Constants.SETTINGS.HUBID) && settings.get(Constants.SETTINGS.HUBID) != null) {
                            HUBID = String.valueOf(settings.get(Constants.SETTINGS.HUBID));
                            if (!HUBID.isEmpty()) {
                                ll_Hub_data.setVisibility(View.VISIBLE);
                                ll_Add_hub.setVisibility(View.GONE);
                                tv_deleteHub.setVisibility(View.VISIBLE);
                                txt_MAC.setText(HUBID);
                            } else {
                                HUBID = "";
                                ll_Hub_data.setVisibility(View.GONE);
                                ll_Add_hub.setVisibility(View.VISIBLE);
                            }
                        } else {
                            ll_Hub_data.setVisibility(View.GONE);
                            ll_Add_hub.setVisibility(View.VISIBLE);
                        }
                        if (settings.containsKey(Constants.SETTINGS.SSID) && settings.get(Constants.SETTINGS.SSID) != null) {
                            SSID = String.valueOf(settings.get(Constants.SETTINGS.SSID));
                            PASSWORD = String.valueOf(settings.get(Constants.SETTINGS.PASSWORD));
                            txt_wifiName.setText(SSID);
                            txt_wifiPassword.setText(PASSWORD);
                        } else {
                            txt_wifiName.setText("No WIFI Credentials");
                            txt_wifiPassword.setText("");
                        }

                    } else {
                        ll_Hub_data.setVisibility(View.GONE);
                        ll_Add_hub.setVisibility(View.VISIBLE);
                        tv_deleteHub.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    ll_Hub_data.setVisibility(View.GONE);
                    ll_Add_hub.setVisibility(View.VISIBLE);
                    tv_deleteHub.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "error " + error.getMessage());
            }
        });
    }

    private void setWiFitoRelaycard(int pos) {

//        String networkSSID = "realme C3";
//        String networkPass = "987654321";
        String networkSSID = "Eston_HUB";
        String networkPass = "eston@4321";
        progressDialog = Utils.showProgressDialog(this, "Connecting...", false);
        boolean result = WifiUtils.withContext(this.getApplicationContext()).isWifiConnected(networkSSID);
        if (result) {
            Thread t = new Thread() {
                public void run() {
                    try {
                        sleep(6000);
                        Utils.dismissProgressDialog(progressDialog);
                        if (pos == 1)
                            initMqtt();
                        else
                            verifyWifi();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            };
            t.start();
        } else {
            WifiUtils.withContext(this.getApplicationContext())
                    .connectWith(networkSSID, networkPass)
                    .setTimeout(40000)
                    .onConnectionResult(new ConnectionSuccessListener() {
                        @Override
                        public void success() {
                            Thread t = new Thread() {
                                public void run() {
                                    try {
                                        sleep(6000);
                                        Utils.dismissProgressDialog(progressDialog);
                                        if (pos == 1)
                                            initMqtt();
                                        else
                                            verifyWifi();
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                }
                            };
                            t.start();
                        }

                        @Override
                        public void failed(@NonNull ConnectionErrorCode errorCode) {
                            Utils.dismissProgressDialog(progressDialog);
                            Log.e(TAG, "connectToWifi: Missing network configuration. " + errorCode.toString());
                            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Connection Fail!" + errorCode.toString(), true, HubSettingActivity.this);
                        }
                    })
                    .start();
        }

    }

    private void initMqtt() {

        try {
            mqttHelper.subscribeTopic(Constants.MQTT.SCAN_NEW_HUB_RESPONSE);
            mqttHelper.publishTopicWithListener(Constants.MQTT.SCAN_NEW_HUB, "1", new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Publish topic Fail!" + Constants.MQTT.SCAN_NEW_HUB, false, HubSettingActivity.this);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    if (exception != null)
                        Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Publish topic fail! " + Constants.MQTT.SCAN_NEW_HUB + " to " + asyncActionToken.getClient().getServerURI() + " Error " + exception.toString(), true, HubSettingActivity.this);
                    else
                        Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Publish topic fail! " + Constants.MQTT.SCAN_NEW_HUB + " to " + asyncActionToken.getClient().getServerURI(), true, HubSettingActivity.this);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void verifyWifi() {

//        Utils.getInstance().hideSoftKeyboard(this);
//        String wifiNameValue = wifi_name_id.getText().toString().trim();
//        String passwordValue = password_id.getText().toString().trim();
//
//        if (HUBID.isEmpty())
//            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Please add hub first", true, HubSettingActivity.this);
//        else if (TextUtils.isEmpty(wifiNameValue))
//            wifi_name_id.setError("Enter wifi name");
//        else if (TextUtils.isEmpty(passwordValue))
//            password_id.setError("Enter password");
//        else {
//            progressDialog = Utils.showProgressDialog(this, "Set up wifi...", false);
//            submitWifi(wifiNameValue, passwordValue);
//        }
    }

    private void submitWifi(String wifiName, String passwordValue) {
        mqttHelper.subscribeTopic(Constants.MQTT.WIFI_SUBMIT_RESPONSE);
        String wifiLength = "", passLength = "";
        if (wifiName.length() <= 9) {
            wifiLength = "0" + wifiName.length();
        } else {
            wifiLength = "" + wifiName.length();
        }
        if (passwordValue.length() <= 9) {
            passLength = "0" + passwordValue.length();
        } else {
            passLength = "" + passwordValue.length();
        }
        mqttHelper.publishTopicWithListener(Constants.MQTT.WIFI_SUBMIT, "R" + wifiLength + passLength + wifiName + passwordValue + "@", new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Utils.dismissProgressDialog(progressDialog);
                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Publish Fail!" + Constants.MQTT.WIFI_SUBMIT, false, HubSettingActivity.this);
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Utils.dismissProgressDialog(progressDialog);
                if (exception != null)
                    Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Publish fail! " + Constants.MQTT.WIFI_SUBMIT + " to " + asyncActionToken.getClient().getServerURI() + " Error " + exception.toString(), true, HubSettingActivity.this);
                else
                    Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Publish fail! " + Constants.MQTT.WIFI_SUBMIT + " to " + asyncActionToken.getClient().getServerURI(), true, HubSettingActivity.this);
            }
        });
    }

    private void saveHubId() {

        boolean isWifiVerify = false;
        Utils.getInstance().hideSoftKeyboard(this);
//        String wifiNameValue = wifi_name_id.getText().toString().trim();
//        String passwordValue = password_id.getText().toString().trim();
//        if (txt_wifiName.getText().toString().endsWith(wifiNameValue) && txt_wifiPassword.getText().toString().endsWith(passwordValue)) {
//            isWifiVerify = true;
//        }
        if (HUBID.isEmpty())
            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Please add hub", true, HubSettingActivity.this);
//        else if (!isWifiVerify)
//            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Please verify wifi!!", true, HubSettingActivity.this);
//        else if (TextUtils.isEmpty(wifiNameValue))
//            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Enter wifi name and verify it!!", true, HubSettingActivity.this);
//        else if (TextUtils.isEmpty(passwordValue))
//            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Enter wifi password and verify it!!", true, HubSettingActivity.this);
        else {
            if (Utils.isNetworkAvailable(this)) {
                progressDialog = Utils.showProgressDialog(this, "Saving data...", false);
                HashMap<String, Object> result = new HashMap<>();
                result.put(Constants.SETTINGS.HUBID, HUBID);
//                result.put(Constants.SETTINGS.SSID, wifiNameValue);
//                result.put(Constants.SETTINGS.PASSWORD, passwordValue);
                mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.SETTINGS.SETTINGS)
                        .updateChildren(result, new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                Utils.dismissProgressDialog(progressDialog);
                                if (databaseError != null) {
                                    Utils.showSnackbarNonSticky(findViewById(android.R.id.content), databaseError.getMessage(), true, HubSettingActivity.this);
                                } else {
                                    Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Saved successfully", false, HubSettingActivity.this);
                                    onBackPressed();
                                }
                            }
                        });
            } else {
                Utils.showNoInternetDialog(this);
            }
        }
    }

    private void deleteHubId() {

        if (HUBID.isEmpty())
            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Did not find hub for delete", true, HubSettingActivity.this);
        else {
            if (Utils.isNetworkAvailable(this)) {
                progressDialog = Utils.showProgressDialog(this, "Deleting...", false);
                HashMap<String, Object> result = new HashMap<>();
                result.put(Constants.SETTINGS.HUBID, "");
                result.put(Constants.SETTINGS.SSID, "");
                result.put(Constants.SETTINGS.PASSWORD, "");
                mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.SETTINGS.SETTINGS)
                        .updateChildren(result, new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                Utils.dismissProgressDialog(progressDialog);
                                if (databaseError != null) {
                                    Utils.showSnackbarNonSticky(findViewById(android.R.id.content), databaseError.getMessage(), true, HubSettingActivity.this);
                                } else {
                                    checkHubAdded();
                                }
                            }
                        });
            } else {
                Utils.showNoInternetDialog(this);
            }
        }
    }

    private void setHub(String data) {

        if (data.length() == 12) {
            Log.e(TAG, "data " + data);
            HUBID = data;
            ll_Hub_data.setVisibility(View.VISIBLE);
            ll_Add_hub.setVisibility(View.GONE);
            txt_MAC.setText(HUBID);
            txt_MAC.setCompoundDrawables(ResourcesCompat.getDrawable(getResources(), R.drawable.ic_round_check_circle_green_24, getTheme()), null, null, null);
            txt_MAC.setTextColor(ResourcesCompat.getColor(getResources(), R.color.green, getTheme()));
        } else {
            new AlertDialog.Builder(HubSettingActivity.this)
                    .setMessage("Please scan proper Hub!")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                        }
                    })
                    .show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "onActivityResult requestCode " + requestCode + " resultCode " + resultCode);
        if (requestCode == SECOND_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                // Get String data from Intent
                String returnString = data.getStringExtra("BARCODE");
                Log.e(TAG, "returnString " + returnString);
                setHub(returnString);
            }
        }
    }
}