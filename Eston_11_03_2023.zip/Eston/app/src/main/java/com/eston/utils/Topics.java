package com.eston.utils;

public interface Topics {

    // Relay Card 1
    // Subscribe Topics
    String R1_START_TOPIC = "technostacks/relaycard1/toapp/start";

    String R1_SUB_TOPIC_DEVICE_1 = "technostacks/relaycard1/toapp/relay1";
    String R1_SUB_TOPIC_DEVICE_2 = "technostacks/relaycard1/toapp/relay2";
    String R1_SUB_TOPIC_DEVICE_3 = "technostacks/relaycard1/toapp/relay3";
    String R1_SUB_TOPIC_DEVICE_4 = "technostacks/relaycard1/toapp/relay4";

    String R1_SUB_SSID_TOPIC_ACK = "technostacks/relaycard1/ssid/ack";
    String R1_SUB_PASS_TOIC_ACK = "technostacks/relaycard1/password/ack";

    String R1_SUB_WIFI_SWITCH_TOPIC_ACK = "technostacks/relaycard1/switchwifi/ack";
    String R1_SUB_LOCAL_IP = "technostacks/relaycard1/toapp/localip";


    // Publish Topics
    String R1_ALL_DEVICE_TOPIC = "technostacks/relaycard1/fromapp/allrelay";

    String R1_PUB_TOPIC_DEVICE_1 = "technostacks/relaycard1/fromapp/relay1";
    String R1_PUB_TOPIC_DEVICE_2 = "technostacks/relaycard1/fromapp/relay2";
    String R1_PUB_TOPIC_DEVICE_3 = "technostacks/relaycard1/fromapp/relay3";
    String R1_PUB_TOPIC_DEVICE_4 = "technostacks/relaycard1/fromapp/relay4";

    String R1_PUB_SSID_TOPIC = "technostacks/relaycard1/ssid";
    String R1_PUB_PASS_TOPIC = "technostacks/relaycard1/password";
    String R1_PUB_WIFI_SWITCH_TOPIC = "technostacks/relaycard1/switchwifi";

    String R1_PUB_RESTART_TOPIC = "technostacks/relaycard1/fromapp/restart";


    // Relay Card 2
    // Subscribe Topics
    String R2_START_TOPIC = "technostacks/relaycard2/toapp/start";

    String R2_SUB_TOPIC_DEVICE_1 = "technostacks/relaycard2/toapp/relay1";
    String R2_SUB_TOPIC_DEVICE_2 = "technostacks/relaycard2/toapp/relay2";
    String R2_SUB_TOPIC_DEVICE_3 = "technostacks/relaycard2/toapp/relay3";
    String R2_SUB_TOPIC_DEVICE_4 = "technostacks/relaycard2/toapp/relay4";

    String R2_SUB_SSID_TOPIC_ACK = "technostacks/relaycard2/ssid/ack";
    String R2_SUB_PASS_TOIC_ACK = "technostacks/relaycard2/password/ack";

    String R2_SUB_WIFI_SWITCH_TOPIC_ACK = "technostacks/relaycard2/switchwifi/ack";
    String R2_SUB_LOCAL_IP = "technostacks/relaycard2/toapp/localip";


    // Publish Topics
    String R2_ALL_DEVICE_TOPIC = "technostacks/relaycard2/fromapp/allrelay";

    String R2_PUB_TOPIC_DEVICE_1 = "technostacks/relaycard2/fromapp/relay1";
    String R2_PUB_TOPIC_DEVICE_2 = "technostacks/relaycard2/fromapp/relay2";
    String R2_PUB_TOPIC_DEVICE_3 = "technostacks/relaycard2/fromapp/relay3";
    String R2_PUB_TOPIC_DEVICE_4 = "technostacks/relaycard2/fromapp/relay4";

    String R2_PUB_SSID_TOPIC = "technostacks/relaycard2/ssid";
    String R2_PUB_PASS_TOPIC = "technostacks/relaycard2/password";
    String R2_PUB_WIFI_SWITCH_TOPIC = "technostacks/relaycard2/switchwifi";

    String R2_PUB_RESTART_TOPIC = "technostacks/relaycard2/fromapp/restart";
}
