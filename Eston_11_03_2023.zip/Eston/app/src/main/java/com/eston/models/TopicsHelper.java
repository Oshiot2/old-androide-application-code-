package com.eston.models;

import java.io.Serializable;

public class TopicsHelper implements Serializable {

    private String roomName;

    private String subStartTopic;
    private String subTopicDevice1;
    private String subTopicDevice2;
    private String subTopicDevice3;
    private String subTopicDevice4;

    private String pubTopicAllDevice;
    private String pubTopicDevice1;
    private String pubTopicDevice2;
    private String pubTopicDevice3;
    private String pubTopicDevice4;

    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public String getSubStartTopic() {
        return subStartTopic;
    }

    public void setSubStartTopic(String subStartTopic) {
        this.subStartTopic = subStartTopic;
    }

    public String getSubTopicDevice1() {
        return subTopicDevice1;
    }

    public void setSubTopicDevice1(String subTopicDevice1) {
        this.subTopicDevice1 = subTopicDevice1;
    }

    public String getSubTopicDevice2() {
        return subTopicDevice2;
    }

    public void setSubTopicDevice2(String subTopicDevice2) {
        this.subTopicDevice2 = subTopicDevice2;
    }

    public String getSubTopicDevice3() {
        return subTopicDevice3;
    }

    public void setSubTopicDevice3(String subTopicDevice3) {
        this.subTopicDevice3 = subTopicDevice3;
    }

    public String getSubTopicDevice4() {
        return subTopicDevice4;
    }

    public void setSubTopicDevice4(String subTopicDevice4) {
        this.subTopicDevice4 = subTopicDevice4;
    }

    public String getPubTopicAllDevice() {
        return pubTopicAllDevice;
    }

    public void setPubTopicAllDevice(String pubTopicAllDevice) {
        this.pubTopicAllDevice = pubTopicAllDevice;
    }

    public String getPubTopicDevice1() {
        return pubTopicDevice1;
    }

    public void setPubTopicDevice1(String pubTopicDevice1) {
        this.pubTopicDevice1 = pubTopicDevice1;
    }

    public String getPubTopicDevice2() {
        return pubTopicDevice2;
    }

    public void setPubTopicDevice2(String pubTopicDevice2) {
        this.pubTopicDevice2 = pubTopicDevice2;
    }

    public String getPubTopicDevice3() {
        return pubTopicDevice3;
    }

    public void setPubTopicDevice3(String pubTopicDevice3) {
        this.pubTopicDevice3 = pubTopicDevice3;
    }

    public String getPubTopicDevice4() {
        return pubTopicDevice4;
    }

    public void setPubTopicDevice4(String pubTopicDevice4) {
        this.pubTopicDevice4 = pubTopicDevice4;
    }
}
