package com.eston.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.appcompat.widget.AppCompatTextView;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.eston.R;
import com.eston.dataBase.model.Room;
import com.eston.dataBase.model.Schedule;
import com.eston.interfaces.HomeAdapterItemClickListener;

import java.util.ArrayList;

public class ScheduleListAdapter extends RecyclerView.Adapter<ScheduleListAdapter.MyViewHolder> {

    // Context
    private Context mContext;

    // List of Home Items
    private ArrayList<Schedule> homeItemsArrayList;

    // OnClick Listener
    private ItemClickListener clickListener;

    public ScheduleListAdapter(Context mContext, ArrayList<Schedule> homeItemsArrayList, ItemClickListener clickListener) {
        this.mContext = mContext;
        this.homeItemsArrayList = homeItemsArrayList;
        this.clickListener = clickListener;
    }

    @Override
    public ScheduleListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_schedule_list_item, parent, false);
//        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_icon_selection_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ScheduleListAdapter.MyViewHolder holder, int position) {

        holder.txt_RoomName.setText(homeItemsArrayList.get(position).roomName + " " + homeItemsArrayList.get(position).deviceName);
        holder.txt_devices_onoff.setText(homeItemsArrayList.get(position).State == 1 ? "Turn: On" : "Turn: Off");
        holder.txt_Time.setText(homeItemsArrayList.get(position).Time);

        holder.btnMon.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_off));
        holder.btnTue.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_off));
        holder.btnWed.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_off));
        holder.btnThu.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_off));
        holder.btnFri.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_off));
        holder.btnSat.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_off));
        holder.btnSun.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_off));

        if (homeItemsArrayList.get(position).DaysNumber.contains(0)) {
            holder.btnMon.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_on));
        }
        if (homeItemsArrayList.get(position).DaysNumber.contains(1)) {
            holder.btnTue.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_on));
        }
        if (homeItemsArrayList.get(position).DaysNumber.contains(2)) {
            holder.btnWed.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_on));
        }
        if (homeItemsArrayList.get(position).DaysNumber.contains(3)) {
            holder.btnThu.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_on));
        }
        if (homeItemsArrayList.get(position).DaysNumber.contains(4)) {
            holder.btnFri.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_on));
        }
        if (homeItemsArrayList.get(position).DaysNumber.contains(5)) {
            holder.btnSat.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_on));
        }
        if (homeItemsArrayList.get(position).DaysNumber.contains(6)) {
            holder.btnSun.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_button_on));
        }

        holder.iv_DeleteScheduler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickListener.onDeleteClick(homeItemsArrayList.get(holder.getAdapterPosition()), holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return homeItemsArrayList.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {

        private CardView cardView;
        private ImageView iv_DeleteScheduler;
        private AppCompatTextView txt_RoomName, txt_devices_onoff, txt_Time;
        AppCompatTextView btnSun, btnMon, btnTue, btnWed, btnThu, btnFri, btnSat;

        private MyViewHolder(final View view) {
            super(view);
            cardView = view.findViewById(R.id.home_items_cardview);
            iv_DeleteScheduler = view.findViewById(R.id.iv_DeleteScheduler);
            txt_RoomName = view.findViewById(R.id.txt_RoomName);
            txt_devices_onoff = view.findViewById(R.id.txt_devices_onoff);
            txt_Time = view.findViewById(R.id.txt_Time);
            btnSun = view.findViewById(R.id.btnSun);
            btnMon = view.findViewById(R.id.btnMon);
            btnTue = view.findViewById(R.id.btnTue);
            btnWed = view.findViewById(R.id.btnWed);
            btnThu = view.findViewById(R.id.btnThu);
            btnFri = view.findViewById(R.id.btnFri);
            btnSat = view.findViewById(R.id.btnSat);

        }
    }


    public interface ItemClickListener {

        void onItemClick(Schedule item, int position);
        void onDeleteClick(Schedule item, int position);
    }

}
