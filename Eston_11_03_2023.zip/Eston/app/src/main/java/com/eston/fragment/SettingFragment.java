package com.eston.fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.eston.EstonApp;
import com.eston.R;
import com.eston.dialongs.AskFroPin;
import com.eston.ui.CreateNewRoomActivity;
import com.eston.ui.HubSettingActivity;
import com.eston.ui.MainActivity;
import com.eston.ui.MqttHelper;
import com.eston.ui.ScanBarcodeActivity;
import com.eston.ui.SchedulersActivity;
import com.eston.utils.Constants;
import com.eston.utils.Utils;
import com.eston.webservice.WSGetWiFiConfigure;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.thanosfisherman.wifiutils.WifiUtils;
import com.thanosfisherman.wifiutils.wifiConnect.ConnectionErrorCode;
import com.thanosfisherman.wifiutils.wifiConnect.ConnectionSuccessListener;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import static android.content.Context.WIFI_SERVICE;
import static com.eston.utils.Constants.USERDATA.PREF_THEME;
import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

public class SettingFragment extends Fragment implements View.OnClickListener {

    private static final String TAG = SettingFragment.class.getName();
    private static final String EXTRA_TEXT = "text";
    private RelativeLayout rl_main, rl_createHub, rl_createRoom;
    private ImageView iv_checked;
    private ToggleButton chkState;
    private String HubId = "", pin = "";
    private int SERVERTYPE = 0;
    private SetupWiFiAsync setupWiFiAsync;
    private MqttHelper mqttHelper;
    private Dialog wifiDialog;
    private ProgressDialog progressDialog;
    private Context mContext;

    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;

    public static SettingFragment createFor(String text) {
        SettingFragment fragment = new SettingFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mqttHelper != null) {
            mqttHelper.unSubscribeTopic(Constants.MQTT.SCAN_NEW_HUB_RESPONSE);
            mqttHelper.unSubscribeTopic(Constants.MQTT.WIFI_SUBMIT_RESPONSE);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_setting, container, false);
        Bundle args = getArguments();
        final String text = args != null ? args.getString(EXTRA_TEXT) : "";
        mContext = getActivity();
        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        TextView txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setVisibility(View.VISIBLE);
//        ImageView iv_Logo = toolbar.findViewById(R.id.iv_Logo);
//        iv_Logo.setVisibility(View.GONE);
//        ImageView iv_wifi = toolbar.findViewById(R.id.iv_wifi);
//        iv_wifi.setVisibility(View.VISIBLE);
        txt_title.setText(text);

        rl_main = (RelativeLayout) view.findViewById(R.id.rl_main);
        RelativeLayout   select_mode = (RelativeLayout) view.findViewById(R.id.select_mode);
        select_mode.setVisibility(View.GONE);

        rl_createHub = (RelativeLayout) view.findViewById(R.id.rl_createHub);
        iv_checked = view.findViewById(R.id.iv_checked);
        chkState = view.findViewById(R.id.chkState);
        rl_createRoom = (RelativeLayout) view.findViewById(R.id.rl_createRoom);

        rl_createHub.setOnClickListener(this);
        rl_createRoom.setOnClickListener(this);

        chkState.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Log.e(TAG, "onCheckedChanged " + b);
                HashMap<String, Object> result = new HashMap<>();
                result.put(Constants.SETTINGS.SERVERTYPE, b ? 1 : 0);

                mFirebaseDatabase
                        .child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.SETTINGS.SETTINGS)
                        .updateChildren(result);

                if (getActivity() != null)
                    mqttHelper = EstonApp.getMqttHelperWithReconnect(getActivity().getApplicationContext(), b ? 1 : 0);

                if (!b) {
                    startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                    getActivity().overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
                }
            }
        });
        mqttHelper = EstonApp.getMqttHelper();
        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference("users");
        mFirebaseDatabase.keepSynced(true);

        checkHubAdded();

        //setupTheme(view);


        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_createHub:
                VerifyPin(0);
                break;
            case R.id.rl_createRoom:
                Log.e(TAG, "HubId " + HubId);
                VerifyPin(1);
//                if (HubId != null && !HubId.equals("")) {
//                    VerifyPin(1);
//                } else {
//                    Utils.showSnackbarNonSticky(rl_main, "Please set up hub first.", true, getActivity());
//                }
                break;
        }
    }

    private void VerifyPin(int pos) {
        // pos == 0 means hub, 1 means room, 2 means scheduler

        AskFroPin askFroPin = new AskFroPin(mContext, "Verify Pin", new AskFroPin.AskForPinListener() {
            @Override
            public void onDone() {
                Utils.getInstance().hideSoftKeyboard(getActivity());
                if (pos == 0) {
                    Intent intent = new Intent(getActivity(), HubSettingActivity.class);
                    startActivityForResult(intent, Constants.ROOM_ACTIVITY_REQUEST_CODE);
                    getActivity().overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
                } else if (pos == 1) {

                    final Dialog mDialog = new Dialog(requireActivity());

                    mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    mDialog.setContentView(R.layout.choose_qr_manual_dialog);
                    mDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    mDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

                    LinearLayout llScanQR = mDialog.findViewById(R.id.llScanQR);
                    EditText etEnterManually = mDialog.findViewById(R.id.etEnterManually);
                    AppCompatButton btnSubmit = mDialog.findViewById(R.id.btnSubmit);

                    llScanQR.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            mDialog.dismiss();
                            Intent intent = new Intent(getActivity(), ScanBarcodeActivity.class);
                            startActivity(intent);
                        }
                    });

                    btnSubmit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (etEnterManually.getText().toString().length() != 14){
                                etEnterManually.setError("Please enter valid value");
                            }else {
                                mDialog.dismiss();
                                Intent intent = new Intent(getActivity(),CreateNewRoomActivity.class);
                                intent.putExtra("BARCODE", etEnterManually.getText().toString());
                                startActivity(intent);
                            }
                        }
                    });

                    mDialog.show();


//                    Intent intent = new Intent(getActivity(), CreateNewRoomActivity.class);
//                    startActivityForResult(intent, Constants.ROOM_ACTIVITY_REQUEST_CODE);
//                    getActivity().overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
                }
            }
        });
        askFroPin.show(pin);
    }

    private void checkHubAdded() {
        progressDialog = Utils.showProgressDialog(getActivity(), "Checking...", false);
        String firebaseUserId = EstonApp.preferenceGetString(PREF_USER_UID, "");
        DatabaseReference userRef = mFirebaseDatabase.child(firebaseUserId).child(Constants.SETTINGS.SETTINGS);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    Utils.dismissProgressDialog(progressDialog);
                    Object td = dataSnapshot.getValue();
                    HashMap<String, Objects> settings = (HashMap<String, Objects>) td;
                    Log.e(TAG, "settings " + settings);
                    if (settings != null) {
                        if (settings.containsKey(Constants.SETTINGS.PIN) && settings.get(Constants.SETTINGS.PIN) != null) {
                            pin = String.valueOf(settings.get(Constants.SETTINGS.PIN));
                        }
                        if (settings.containsKey(Constants.SETTINGS.HUBID) && settings.get(Constants.SETTINGS.HUBID) != null) {
                            HubId = String.valueOf(settings.get(Constants.SETTINGS.HUBID));
                            if (!HubId.isEmpty()) {
                                iv_checked.setVisibility(View.VISIBLE);
                            } else {
                                HubId = "";
                                iv_checked.setVisibility(View.GONE);
                            }
                        } else {
                            HubId = "";
                            iv_checked.setVisibility(View.GONE);
                        }

                        if (settings.containsKey(Constants.SETTINGS.SERVERTYPE) && settings.get(Constants.SETTINGS.SERVERTYPE) != null
                                && Integer.parseInt(String.valueOf(settings.get(Constants.SETTINGS.SERVERTYPE))) == 0) {
                            SERVERTYPE = 0;
                            chkState.setChecked(false);
                        } else {
                            SERVERTYPE = 1;
                            chkState.setChecked(true);
                        }
                    } else {
                        pin = "";
                        iv_checked.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Utils.dismissProgressDialog(progressDialog);
                Log.e(TAG, "error " + error.getMessage());
                pin = "";
                iv_checked.setVisibility(View.GONE);
                rl_createHub.setEnabled(true);
            }
        });
    }

    //This Async Task is to Setup WiFi
    @SuppressLint("StaticFieldLeak")
    private class SetupWiFiAsync extends AsyncTask<String, String, Integer> {

        private ProgressDialog progressDialog;
        private WSGetWiFiConfigure wsGetWiFiConfigure;
        private String wifiName, password;

        private SetupWiFiAsync(String wifiName, String password) {
            this.wifiName = wifiName;
            this.password = password;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = Utils.showProgressDialog(getActivity(), getString(R.string.msg_loading), false);
        }

        @Override
        protected Integer doInBackground(String... params) {
            wsGetWiFiConfigure = new WSGetWiFiConfigure(getActivity());
            return wsGetWiFiConfigure.executeService(wifiName, password);
        }

        @Override
        protected void onPostExecute(Integer statusCode) {
            super.onPostExecute(statusCode);

            Utils.dismissProgressDialog(progressDialog);
            wifiDialog.dismiss();

            assert wsGetWiFiConfigure != null;
            if (wsGetWiFiConfigure.isSuccess()) {
                Utils.showSnackbarNonSticky(rl_main, wsGetWiFiConfigure.getMessage(), false, getActivity());
            } else if (!wsGetWiFiConfigure.isSuccess()) {
                //Error
                Utils.showSnackbarNonSticky(rl_main, wsGetWiFiConfigure.getMessage(), true, getActivity());
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "onActivityResult requestCode " + requestCode + " resultCode " + resultCode);
//        if (requestCode == Constants.ROOM_ACTIVITY_REQUEST_CODE && resultCode == Constants.ROOM_ACTIVITY_RESULT_CODE) {
//            checkHubAdded();
//        }
    }

    private void setupTheme(View view) {
//        ImageView iv_one = view.findViewById(R.id.iv_one);
//        ImageView iv_two = view.findViewById(R.id.iv_two);
//        ImageView iv_three = view.findViewById(R.id.iv_three);
//        ImageView iv_four = view.findViewById(R.id.iv_four);
//        ImageView iv_five = view.findViewById(R.id.iv_five);
//        ImageView iv_six = view.findViewById(R.id.iv_six);
//
//        int current = EstonApp.preferenceGetInteger(PREF_THEME, 1);
//
//        iv_one.setColorFilter(ContextCompat.getColor(mContext, current == 1 ? R.color.While : R.color.colorPrimary), android.graphics.PorterDuff.Mode.SRC_IN);
//        iv_two.setColorFilter(ContextCompat.getColor(mContext, current == 2 ? R.color.While : R.color.theme2), android.graphics.PorterDuff.Mode.SRC_IN);
//        iv_three.setColorFilter(ContextCompat.getColor(mContext, current == 3 ? R.color.While : R.color.theme3), android.graphics.PorterDuff.Mode.SRC_IN);
//        iv_four.setColorFilter(ContextCompat.getColor(mContext, current == 4 ? R.color.While : R.color.theme4), android.graphics.PorterDuff.Mode.SRC_IN);
//        iv_five.setColorFilter(ContextCompat.getColor(mContext, current == 5 ? R.color.While : R.color.theme5), android.graphics.PorterDuff.Mode.SRC_IN);
//        iv_six.setColorFilter(ContextCompat.getColor(mContext, current == 6 ? R.color.While : R.color.theme6), android.graphics.PorterDuff.Mode.SRC_IN);
//
//        iv_one.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                EstonApp.preferencePutInteger(PREF_THEME, 1);
//                getActivity().recreate();
//            }
//        });
//        iv_two.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                EstonApp.preferencePutInteger(PREF_THEME, 2);
//                getActivity().recreate();
//            }
//        });
//        iv_three.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                EstonApp.preferencePutInteger(PREF_THEME, 3);
//                getActivity().recreate();
//            }
//        });
//        iv_four.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                EstonApp.preferencePutInteger(PREF_THEME, 4);
//                getActivity().recreate();
//            }
//        });
//        iv_five.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                EstonApp.preferencePutInteger(PREF_THEME, 5);
//                getActivity().recreate();
//            }
//        });
//        iv_six.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                EstonApp.preferencePutInteger(PREF_THEME, 6);
//                getActivity().recreate();
//            }
//        });
    }
}
