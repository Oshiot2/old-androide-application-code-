package com.eston.interfaces;

import android.view.View;

import com.eston.dataBase.model.Room;

/**
 * Created by techno on 19/1/18.
 */

public interface HomeAdapterItemClickListener {

    void onItemClick(Room item, int position);
    void onDeleteClick(Room item, int position);
}
