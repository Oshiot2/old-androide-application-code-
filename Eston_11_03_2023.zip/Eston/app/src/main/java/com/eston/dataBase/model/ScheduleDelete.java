package com.eston.dataBase.model;

import androidx.room.Entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Entity
public class ScheduleDelete implements Serializable {

    public Integer Action = 1; // add/ delete
    public String Mac; //room mac
    public Integer Switch = 1;//device pos
    public String Sch_No = "0"; // ?

}