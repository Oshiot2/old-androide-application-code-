package com.eston.interfaces;

/**
 * Created by techno on 19/1/18.
 */

public interface DeviceItemClickListener {

    void onItemClick(Object item, int position);

    void onFanFunctionClick(Object item, Integer IsPlus, int position);
}
