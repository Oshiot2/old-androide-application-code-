package com.eston.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import com.eston.EstonApp;
import com.eston.R;
import com.eston.utils.Utils;

import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class SplashActivity extends AppCompatActivity {

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_trans_right_in, R.anim.anim_trans_right_out);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_splash);

        Thread t = new Thread() {
            public void run() {
                try {
                    sleep(1500);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (EstonApp.preferenceGetString(PREF_USER_UID, "").isEmpty()) {
                                startActivity(new Intent(SplashActivity.this, SignInActivity.class));
                            } else {
                                Log.e("TAG"," User "+EstonApp.preferenceGetString(PREF_USER_UID, ""));
                                startActivity(new Intent(SplashActivity.this, MainActivity.class));
                            }
                            overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
                            finish();
                        }
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        t.start();
    }
}