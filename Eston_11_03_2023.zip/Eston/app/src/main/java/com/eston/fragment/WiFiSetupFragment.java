package com.eston.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.text.method.SingleLineTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.eston.R;
import com.eston.ui.MainActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class WiFiSetupFragment extends Fragment {

    private static final String TAG = WiFiSetupFragment.class.getName();
    private static final String EXTRA_TEXT = "text";
    private EditText edtWifiSSID,edtWiFiPassword,edtAlx01,edtAlx02,edtAlx03,edtAlx04,edtAlx05,edtAlx06,edtAlx07,edtAlx08,
            edtAlx09,edtAlx10,edtAlx11,edtAlx12,edtAlx13,edtAlx14,edtAlx15,edtAlx16,edtAlx17,edtAlx18,edtAlx19,edtAlx20,
            edtAlx21,edtAlx22,edtAlx23,edtAlx24;

    private Button btnSumbit;
    private CheckBox cbWiFiPassword;
    private SwitchCompat swcAlexa;
    private String alexaStatus = "N";
    private Spinner spDeviceType;


    String start = "*,";
    Thread Thread1 = null;
    public static final String SERVER_IP = "192.168.4.1";
    public static final int SERVER_PORT = 80;


    public static WiFiSetupFragment createFor(String text) {
        WiFiSetupFragment fragment = new WiFiSetupFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_wifi_setup, container, false);

        initViews(view);

        cbWiFiPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtWiFiPassword.getTransformationMethod().getClass().getSimpleName().equals("PasswordTransformationMethod")) {
                    edtWiFiPassword.setTransformationMethod(new SingleLineTransformationMethod());
                } else {
                    edtWiFiPassword.setTransformationMethod(new PasswordTransformationMethod());
                }
                edtWiFiPassword.setSelection(edtWiFiPassword.getText().length());
            }
        });

        swcAlexa.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                   alexaStatus = "Y";
                }else {
                    alexaStatus = "N";
                }
            }
        });

        spDeviceType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Log.e(TAG,"Position: " + i);
                Log.e(TAG,"Value: " + adapterView.getItemAtPosition(i));


                if (i == 1){
                    //1 switch
                    edtAlx01.setVisibility(View.VISIBLE);
                    edtAlx02.setVisibility(View.GONE);
                    edtAlx03.setVisibility(View.GONE);
                    edtAlx04.setVisibility(View.GONE);
                    edtAlx05.setVisibility(View.GONE);
                    edtAlx06.setVisibility(View.GONE);
                    edtAlx07.setVisibility(View.GONE);
                    edtAlx08.setVisibility(View.GONE);
                    edtAlx09.setVisibility(View.GONE);
                    edtAlx10.setVisibility(View.GONE);
                    edtAlx11.setVisibility(View.GONE);
                    edtAlx12.setVisibility(View.GONE);
                    edtAlx13.setVisibility(View.GONE);
                    edtAlx14.setVisibility(View.GONE);
                    edtAlx15.setVisibility(View.GONE);
                    edtAlx16.setVisibility(View.GONE);
                    edtAlx17.setVisibility(View.GONE);
                    edtAlx18.setVisibility(View.GONE);
                    edtAlx19.setVisibility(View.GONE);
                    edtAlx20.setVisibility(View.GONE);
                    edtAlx21.setVisibility(View.GONE);
                    edtAlx22.setVisibility(View.GONE);
                    edtAlx23.setVisibility(View.GONE);
                    edtAlx24.setVisibility(View.GONE);
                }else if (i == 2){
                    //2 switch
                    edtAlx01.setVisibility(View.VISIBLE);
                    edtAlx02.setVisibility(View.VISIBLE);
                    edtAlx03.setVisibility(View.GONE);
                    edtAlx04.setVisibility(View.GONE);
                    edtAlx05.setVisibility(View.GONE);
                    edtAlx06.setVisibility(View.GONE);
                    edtAlx07.setVisibility(View.GONE);
                    edtAlx08.setVisibility(View.GONE);
                    edtAlx09.setVisibility(View.GONE);
                    edtAlx10.setVisibility(View.GONE);
                    edtAlx11.setVisibility(View.GONE);
                    edtAlx12.setVisibility(View.GONE);
                    edtAlx13.setVisibility(View.GONE);
                    edtAlx14.setVisibility(View.GONE);
                    edtAlx15.setVisibility(View.GONE);
                    edtAlx16.setVisibility(View.GONE);
                    edtAlx17.setVisibility(View.GONE);
                    edtAlx18.setVisibility(View.GONE);
                    edtAlx19.setVisibility(View.GONE);
                    edtAlx20.setVisibility(View.GONE);
                    edtAlx21.setVisibility(View.GONE);
                    edtAlx22.setVisibility(View.GONE);
                    edtAlx23.setVisibility(View.GONE);
                    edtAlx24.setVisibility(View.GONE);
                }else if (i == 3){
                    //4 switch
                    edtAlx01.setVisibility(View.VISIBLE);
                    edtAlx02.setVisibility(View.VISIBLE);
                    edtAlx03.setVisibility(View.VISIBLE);
                    edtAlx04.setVisibility(View.VISIBLE);
                    edtAlx05.setVisibility(View.GONE);
                    edtAlx06.setVisibility(View.GONE);
                    edtAlx07.setVisibility(View.GONE);
                    edtAlx08.setVisibility(View.GONE);
                    edtAlx09.setVisibility(View.GONE);
                    edtAlx10.setVisibility(View.GONE);
                    edtAlx11.setVisibility(View.GONE);
                    edtAlx12.setVisibility(View.GONE);
                    edtAlx13.setVisibility(View.GONE);
                    edtAlx14.setVisibility(View.GONE);
                    edtAlx15.setVisibility(View.GONE);
                    edtAlx16.setVisibility(View.GONE);
                    edtAlx17.setVisibility(View.GONE);
                    edtAlx18.setVisibility(View.GONE);
                    edtAlx19.setVisibility(View.GONE);
                    edtAlx20.setVisibility(View.GONE);
                    edtAlx21.setVisibility(View.GONE);
                    edtAlx22.setVisibility(View.GONE);
                    edtAlx23.setVisibility(View.GONE);
                    edtAlx24.setVisibility(View.GONE);
                }else if (i == 4){
                    //4 switch 1 fan
                    edtAlx01.setVisibility(View.VISIBLE);
                    edtAlx02.setVisibility(View.VISIBLE);
                    edtAlx03.setVisibility(View.VISIBLE);
                    edtAlx04.setVisibility(View.VISIBLE);
                    edtAlx05.setVisibility(View.VISIBLE);
                    edtAlx06.setVisibility(View.VISIBLE);
                    edtAlx07.setVisibility(View.VISIBLE);
                    edtAlx08.setVisibility(View.VISIBLE);
                    edtAlx09.setVisibility(View.VISIBLE);
                    edtAlx10.setVisibility(View.VISIBLE);
                    edtAlx11.setVisibility(View.GONE);
                    edtAlx12.setVisibility(View.GONE);
                    edtAlx13.setVisibility(View.GONE);
                    edtAlx14.setVisibility(View.GONE);
                    edtAlx15.setVisibility(View.GONE);
                    edtAlx16.setVisibility(View.GONE);
                    edtAlx17.setVisibility(View.GONE);
                    edtAlx18.setVisibility(View.GONE);
                    edtAlx19.setVisibility(View.GONE);
                    edtAlx20.setVisibility(View.GONE);
                    edtAlx21.setVisibility(View.GONE);
                    edtAlx22.setVisibility(View.GONE);
                    edtAlx23.setVisibility(View.GONE);
                    edtAlx24.setVisibility(View.GONE);
                }else if (i == 5){
                    //6 switch 1 fan
                    edtAlx01.setVisibility(View.VISIBLE);
                    edtAlx02.setVisibility(View.VISIBLE);
                    edtAlx03.setVisibility(View.VISIBLE);
                    edtAlx04.setVisibility(View.VISIBLE);
                    edtAlx05.setVisibility(View.VISIBLE);
                    edtAlx06.setVisibility(View.VISIBLE);
                    edtAlx07.setVisibility(View.VISIBLE);
                    edtAlx08.setVisibility(View.VISIBLE);
                    edtAlx09.setVisibility(View.VISIBLE);
                    edtAlx10.setVisibility(View.VISIBLE);
                    edtAlx11.setVisibility(View.VISIBLE);
                    edtAlx12.setVisibility(View.VISIBLE);
                    edtAlx13.setVisibility(View.GONE);
                    edtAlx14.setVisibility(View.GONE);
                    edtAlx15.setVisibility(View.GONE);
                    edtAlx16.setVisibility(View.GONE);
                    edtAlx17.setVisibility(View.GONE);
                    edtAlx18.setVisibility(View.GONE);
                    edtAlx19.setVisibility(View.GONE);
                    edtAlx20.setVisibility(View.GONE);
                    edtAlx21.setVisibility(View.GONE);
                    edtAlx22.setVisibility(View.GONE);
                    edtAlx23.setVisibility(View.GONE);
                    edtAlx24.setVisibility(View.GONE);
                }else if (i == 6){
                    //10 switch
                    edtAlx01.setVisibility(View.VISIBLE);
                    edtAlx02.setVisibility(View.VISIBLE);
                    edtAlx03.setVisibility(View.VISIBLE);
                    edtAlx04.setVisibility(View.VISIBLE);
                    edtAlx05.setVisibility(View.VISIBLE);
                    edtAlx06.setVisibility(View.VISIBLE);
                    edtAlx07.setVisibility(View.VISIBLE);
                    edtAlx08.setVisibility(View.VISIBLE);
                    edtAlx09.setVisibility(View.VISIBLE);
                    edtAlx10.setVisibility(View.VISIBLE);
                    edtAlx11.setVisibility(View.GONE);
                    edtAlx12.setVisibility(View.GONE);
                    edtAlx13.setVisibility(View.GONE);
                    edtAlx14.setVisibility(View.GONE);
                    edtAlx15.setVisibility(View.GONE);
                    edtAlx16.setVisibility(View.GONE);
                    edtAlx17.setVisibility(View.GONE);
                    edtAlx18.setVisibility(View.GONE);
                    edtAlx19.setVisibility(View.GONE);
                    edtAlx20.setVisibility(View.GONE);
                    edtAlx21.setVisibility(View.GONE);
                    edtAlx22.setVisibility(View.GONE);
                    edtAlx23.setVisibility(View.GONE);
                    edtAlx24.setVisibility(View.GONE);
                }else if (i == 7){
                    //8 switch 2 fan
                    edtAlx01.setVisibility(View.VISIBLE);
                    edtAlx02.setVisibility(View.VISIBLE);
                    edtAlx03.setVisibility(View.VISIBLE);
                    edtAlx04.setVisibility(View.VISIBLE);
                    edtAlx05.setVisibility(View.VISIBLE);
                    edtAlx06.setVisibility(View.VISIBLE);
                    edtAlx07.setVisibility(View.VISIBLE);
                    edtAlx08.setVisibility(View.VISIBLE);
                    edtAlx09.setVisibility(View.VISIBLE);
                    edtAlx10.setVisibility(View.VISIBLE);
                    edtAlx11.setVisibility(View.VISIBLE);
                    edtAlx12.setVisibility(View.VISIBLE);
                    edtAlx13.setVisibility(View.VISIBLE);
                    edtAlx14.setVisibility(View.VISIBLE);
                    edtAlx15.setVisibility(View.VISIBLE);
                    edtAlx16.setVisibility(View.VISIBLE);
                    edtAlx17.setVisibility(View.VISIBLE);
                    edtAlx18.setVisibility(View.VISIBLE);
                    edtAlx19.setVisibility(View.VISIBLE);
                    edtAlx20.setVisibility(View.VISIBLE);
                    edtAlx21.setVisibility(View.GONE);
                    edtAlx22.setVisibility(View.GONE);
                    edtAlx23.setVisibility(View.GONE);
                    edtAlx24.setVisibility(View.GONE);
                }else if (i == 8){
                    //12 switch 2 fan
                    edtAlx01.setVisibility(View.VISIBLE);
                    edtAlx02.setVisibility(View.VISIBLE);
                    edtAlx03.setVisibility(View.VISIBLE);
                    edtAlx04.setVisibility(View.VISIBLE);
                    edtAlx05.setVisibility(View.VISIBLE);
                    edtAlx06.setVisibility(View.VISIBLE);
                    edtAlx07.setVisibility(View.VISIBLE);
                    edtAlx08.setVisibility(View.VISIBLE);
                    edtAlx09.setVisibility(View.VISIBLE);
                    edtAlx10.setVisibility(View.VISIBLE);
                    edtAlx11.setVisibility(View.VISIBLE);
                    edtAlx12.setVisibility(View.VISIBLE);
                    edtAlx13.setVisibility(View.VISIBLE);
                    edtAlx14.setVisibility(View.VISIBLE);
                    edtAlx15.setVisibility(View.VISIBLE);
                    edtAlx16.setVisibility(View.VISIBLE);
                    edtAlx17.setVisibility(View.VISIBLE);
                    edtAlx18.setVisibility(View.VISIBLE);
                    edtAlx19.setVisibility(View.VISIBLE);
                    edtAlx20.setVisibility(View.VISIBLE);
                    edtAlx21.setVisibility(View.VISIBLE);
                    edtAlx22.setVisibility(View.VISIBLE);
                    edtAlx23.setVisibility(View.VISIBLE);
                    edtAlx24.setVisibility(View.VISIBLE);
                }else if (i == 9){
                    //16 switch 1 fan
                    edtAlx01.setVisibility(View.VISIBLE);
                    edtAlx02.setVisibility(View.VISIBLE);
                    edtAlx03.setVisibility(View.VISIBLE);
                    edtAlx04.setVisibility(View.VISIBLE);
                    edtAlx05.setVisibility(View.VISIBLE);
                    edtAlx06.setVisibility(View.VISIBLE);
                    edtAlx07.setVisibility(View.VISIBLE);
                    edtAlx08.setVisibility(View.VISIBLE);
                    edtAlx09.setVisibility(View.VISIBLE);
                    edtAlx10.setVisibility(View.VISIBLE);
                    edtAlx11.setVisibility(View.VISIBLE);
                    edtAlx12.setVisibility(View.VISIBLE);
                    edtAlx13.setVisibility(View.VISIBLE);
                    edtAlx14.setVisibility(View.VISIBLE);
                    edtAlx15.setVisibility(View.VISIBLE);
                    edtAlx16.setVisibility(View.VISIBLE);
                    edtAlx17.setVisibility(View.VISIBLE);
                    edtAlx18.setVisibility(View.VISIBLE);
                    edtAlx19.setVisibility(View.VISIBLE);
                    edtAlx20.setVisibility(View.VISIBLE);
                    edtAlx21.setVisibility(View.VISIBLE);
                    edtAlx22.setVisibility(View.VISIBLE);
                    edtAlx23.setVisibility(View.GONE);
                    edtAlx24.setVisibility(View.GONE);
                }else {
                    edtAlx01.setVisibility(View.GONE);
                    edtAlx02.setVisibility(View.GONE);
                    edtAlx03.setVisibility(View.GONE);
                    edtAlx04.setVisibility(View.GONE);
                    edtAlx05.setVisibility(View.GONE);
                    edtAlx06.setVisibility(View.GONE);
                    edtAlx07.setVisibility(View.GONE);
                    edtAlx08.setVisibility(View.GONE);
                    edtAlx09.setVisibility(View.GONE);
                    edtAlx10.setVisibility(View.GONE);
                    edtAlx11.setVisibility(View.GONE);
                    edtAlx12.setVisibility(View.GONE);
                    edtAlx13.setVisibility(View.GONE);
                    edtAlx14.setVisibility(View.GONE);
                    edtAlx15.setVisibility(View.GONE);
                    edtAlx16.setVisibility(View.GONE);
                    edtAlx17.setVisibility(View.GONE);
                    edtAlx18.setVisibility(View.GONE);
                    edtAlx19.setVisibility(View.GONE);
                    edtAlx20.setVisibility(View.GONE);
                    edtAlx21.setVisibility(View.GONE);
                    edtAlx22.setVisibility(View.GONE);
                    edtAlx23.setVisibility(View.GONE);
                    edtAlx24.setVisibility(View.GONE);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        btnSumbit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (TextUtils.isEmpty(edtWifiSSID.getText().toString().trim())){
                    edtWifiSSID.setError(getString(R.string.please_enter_wifissid));
                }
                else if (TextUtils.isEmpty(edtWiFiPassword.getText().toString().trim())){
                    edtWiFiPassword.setError(getString(R.string.please_enter_wifipassword));
                }
                else {
                    StringBuilder strBuilder_all_config = new StringBuilder(start);

                    strBuilder_all_config.append("WIFISSID=" + edtWifiSSID.getText().toString().trim());
                    strBuilder_all_config.append(",WIFIPWD=" + edtWiFiPassword.getText().toString().trim());

                    if (!TextUtils.isEmpty(edtAlx01.getText().toString().trim()) && edtAlx01.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX01=" + edtAlx01.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx02.getText().toString().trim()) && edtAlx02.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX02=" + edtAlx02.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx03.getText().toString().trim()) && edtAlx03.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX03=" + edtAlx03.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx04.getText().toString().trim()) && edtAlx04.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX04=" + edtAlx04.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx05.getText().toString().trim()) && edtAlx05.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX05=" + edtAlx05.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx06.getText().toString().trim()) && edtAlx06.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX06=" + edtAlx06.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx07.getText().toString().trim()) && edtAlx07.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX07=" + edtAlx07.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx08.getText().toString().trim()) && edtAlx08.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX08=" + edtAlx08.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx09.getText().toString().trim()) && edtAlx09.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX09=" + edtAlx09.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx10.getText().toString().trim()) && edtAlx10.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX10=" + edtAlx10.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx11.getText().toString().trim()) && edtAlx11.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX11=" + edtAlx11.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx12.getText().toString().trim()) && edtAlx12.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX12=" + edtAlx12.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx13.getText().toString().trim()) && edtAlx13.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX13=" + edtAlx13.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx14.getText().toString().trim()) && edtAlx14.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX14=" + edtAlx14.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx15.getText().toString().trim()) && edtAlx15.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX08=" + edtAlx15.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx16.getText().toString().trim()) && edtAlx16.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX16=" + edtAlx16.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx17.getText().toString().trim()) && edtAlx17.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX17=" + edtAlx17.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx18.getText().toString().trim()) && edtAlx18.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX18=" + edtAlx18.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx19.getText().toString().trim()) && edtAlx19.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX19=" + edtAlx19.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx20.getText().toString().trim()) && edtAlx20.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX20=" + edtAlx20.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx21.getText().toString().trim()) && edtAlx21.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX21=" + edtAlx21.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx22.getText().toString().trim()) && edtAlx22.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX22=" + edtAlx22.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx23.getText().toString().trim()) && edtAlx23.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX12=" + edtAlx23.getText().toString().trim());
                    }
                    if (!TextUtils.isEmpty(edtAlx24.getText().toString().trim()) && edtAlx24.getVisibility() == View.VISIBLE){
                        strBuilder_all_config.append(",ALX24=" + edtAlx24.getText().toString().trim());
                    }


                    strBuilder_all_config.append(",ALEXAEN=" + alexaStatus + ",#");

//                    Toast.makeText(getActivity(),strBuilder_all_config.toString(),Toast.LENGTH_LONG).show();
                    Log.e("WifiFragment",strBuilder_all_config.toString());

//                    connect();
//                    try {
//                        Thread.sleep(2000);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//                    send(strBuilder_all_config.toString());
                }

            }
        });

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        Bundle args = getArguments();
        final String text = args != null ? args.getString(EXTRA_TEXT) : "";

        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        TextView txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setText(text);
    }

    private void initViews(View view) {
        edtWifiSSID = view.findViewById(R.id.edtWifiSSID);
        edtWiFiPassword = view.findViewById(R.id.edtWiFiPassword);
        edtAlx01 = view.findViewById(R.id.edtAlx01);
        edtAlx02 = view.findViewById(R.id.edtAlx02);
        edtAlx03 = view.findViewById(R.id.edtAlx03);
        edtAlx04 = view.findViewById(R.id.edtAlx04);
        edtAlx05 = view.findViewById(R.id.edtAlx05);
        edtAlx06 = view.findViewById(R.id.edtAlx06);
        edtAlx07 = view.findViewById(R.id.edtAlx07);
        edtAlx08 = view.findViewById(R.id.edtAlx08);
        edtAlx09 = view.findViewById(R.id.edtAlx09);
        edtAlx10 = view.findViewById(R.id.edtAlx10);
        edtAlx11 = view.findViewById(R.id.edtAlx11);
        edtAlx12 = view.findViewById(R.id.edtAlx12);
        edtAlx13 = view.findViewById(R.id.edtAlx13);
        edtAlx14 = view.findViewById(R.id.edtAlx14);
        edtAlx15 = view.findViewById(R.id.edtAlx15);
        edtAlx16 = view.findViewById(R.id.edtAlx16);
        edtAlx17 = view.findViewById(R.id.edtAlx17);
        edtAlx18 = view.findViewById(R.id.edtAlx18);
        edtAlx19 = view.findViewById(R.id.edtAlx19);
        edtAlx20 = view.findViewById(R.id.edtAlx20);
        edtAlx21 = view.findViewById(R.id.edtAlx21);
        edtAlx22 = view.findViewById(R.id.edtAlx22);
        edtAlx23 = view.findViewById(R.id.edtAlx23);
        edtAlx24 = view.findViewById(R.id.edtAlx24);


        cbWiFiPassword = view.findViewById(R.id.cbWiFiPassword);
        swcAlexa = view.findViewById(R.id.swcAlexa);
        spDeviceType = view.findViewById(R.id.spDeviceType);
        btnSumbit = view.findViewById(R.id.btnSubmit);
    }

    private volatile boolean exit = false;

    private void connect(){
        Thread1 = new Thread(new Thread1());
        Thread1.start();
    }

    private void send(String fullString){
        new Thread(new Thread3(fullString)).start();
    }

    private PrintWriter output;
    private BufferedReader input;
    class Thread1 implements Runnable {
        @Override
        public void run() {
                Socket socket;
                try {
                    socket = new Socket(SERVER_IP, SERVER_PORT);
                    output = new PrintWriter(socket.getOutputStream());
                    input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Log.e("WifiFragment", "Connected");
//                        activityResultBinding.tvURL.setText("Connected\n");
//                        activityResultBinding.btnSend.setEnabled(true);
//                        activityResultBinding.btnSend.setAlpha(1f);
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Log.e(TAG, "Thread1" + e.getMessage());
//                        activityResultBinding.tvURL.setText("Not Connected\n");
                            Toast.makeText(requireActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
//                        activityResultBinding.btnSend.setEnabled(false);
//                        activityResultBinding.btnSend.setAlpha(0.5f);
                        }
                    });

                }
        }
        public void stop() {
            exit = true;
        }
    }

//    class Thread2 implements Runnable {
//        @Override
//        public void run() {
//            while (!exit) {
//                try {
//                    final String message = input.readLine();
//                    if (message != null) {
//                        new Handler(Looper.getMainLooper()).post(new Runnable() {
//                            @Override
//                            public void run() {
//                                Log.e("WifiFragment","server: " + message);
////                                activityResultBinding.tvURL.append("server: " + message + "\n");
//                            }
//                        });
//                    } else {
//                        Thread1 = new Thread(new Thread1());
//                        Thread1.start();
//                        return;
//                    }
//                } catch (IOException e) {
//                    e.printStackTrace();
//                    Log.e(TAG,"Thread2" + e.getMessage());
//                    new Handler(Looper.getMainLooper()).post(new Runnable() {
//                        @Override
//                        public void run() {
//                            Log.e(TAG,"Thread2" + e.getMessage());
//                            Toast.makeText(requireActivity(),e.getMessage(),Toast.LENGTH_SHORT).show();
//                        }
//                    });
//                }
//            }
//        }
//        public void stop() {
//            exit = true;
//        }
//    }

    class Thread3 implements Runnable {
        private String message;
        Thread3(String message) {
            this.message = message;
        }
        @Override
        public void run() {
                output.write(message);
                output.flush();
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Log.e("WifiFragment", "client: " + message);
//                    activityResultBinding.tvURL.append("client: " + message + "\n");
                        startActivity(new Intent(requireActivity(), MainActivity.class));
                        requireActivity().finish();
                    }
                });
        }
        public void stop() {
            exit = true;
        }
    }
}

