package com.eston;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {

}
