package com.eston;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.eston.ui.MqttHelper;
import com.google.firebase.database.FirebaseDatabase;

import org.eclipse.paho.android.service.MqttAndroidClient;

public class EstonApp extends Application {

    public static EstonApp mInstance;
    public static MqttHelper mqttHelper;


    private static SharedPreferences sharedPreferences;
    private static SharedPreferences.Editor sharedPreferencesEditor;


    @Override
    public void onCreate() {
        super.onCreate();

        FirebaseDatabase.getInstance();
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        if (mqttHelper == null) {
            mqttHelper = new MqttHelper(this, 1);
            mqttHelper.connect();
        }

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        sharedPreferencesEditor = sharedPreferences.edit();

    }

    public static MqttHelper getMqttHelper() {
        return mqttHelper;
    }

    public static MqttHelper getMqttHelperWithReconnect(Context mContext, int serverType) {
        Log.e("TAG", "serverType " + serverType);
//        if (mqttHelper != null && mqttHelper.getMqttAndroidClient().isConnected()) {
//            if (serverType == 0 && mqttHelper.getMqttAndroidClient().getServerURI().equalsIgnoreCase(MqttHelper.serverUriLocal)) {
//                Log.e("TAG", "serverType00 ");
//                return mqttHelper;
//            } else if (serverType == 1 && mqttHelper.getMqttAndroidClient().getServerURI().equalsIgnoreCase(MqttHelper.serverUriGlobel)) {
//                Log.e("TAG", "serverType11 ");
//                return mqttHelper;
//            }
//        }
        if (mqttHelper != null && mqttHelper.getMqttAndroidClient().isConnected()) {
            return mqttHelper;
        }

        mqttHelper = null;
        mqttHelper = new MqttHelper(mContext, serverType);
        mqttHelper.connect();
        Log.e("TAG", "serverType22 ");
        return mqttHelper;
    }

    public static synchronized EstonApp getmInstance() {
        return mInstance;
    }

    public static MqttAndroidClient getMqttAndroidClient() {
        return mqttHelper.getMqttAndroidClient();
    }

    public static void preferencePutInteger(String key, int value) {
        sharedPreferencesEditor.putInt(key, value);
        sharedPreferencesEditor.commit();
    }

    public static int preferenceGetInteger(String key, int defaultValue) {
        return sharedPreferences.getInt(key, defaultValue);
    }

    public static void preferencePutBoolean(String key, boolean value) {
        sharedPreferencesEditor.putBoolean(key, value);
        sharedPreferencesEditor.commit();
    }

    public static boolean preferenceGetBoolean(String key, boolean defaultValue) {
        return sharedPreferences.getBoolean(key, defaultValue);
    }

    public static void preferencePutString(String key, String value) {
        sharedPreferencesEditor.putString(key, value);
        sharedPreferencesEditor.commit();
    }

    public static String preferenceGetString(String key, String defaultValue) {
        return sharedPreferences.getString(key, defaultValue);
    }

    public static void preferencePutLong(String key, long value) {
        sharedPreferencesEditor.putLong(key, value);
        sharedPreferencesEditor.commit();
    }

    public static long preferenceGetLong(String key, long defaultValue) {
        return sharedPreferences.getLong(key, defaultValue);
    }

    public static void preferenceRemoveKey(String key) {
        sharedPreferencesEditor.remove(key);
        sharedPreferencesEditor.commit();
    }

    public static void clearPreference() {

        sharedPreferencesEditor.clear();
        sharedPreferencesEditor.commit();
    }

}
