package com.eston.webservice;

import android.content.Context;
import android.util.Log;

import com.eston.utils.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.Response;

public class WSPostLocalUpdate {

    private String TAG = WSPostLocalUpdate.class.getName();
    private Context context;
    private String message = "";
    private int status = 0;
    private boolean success;

    public WSPostLocalUpdate(Context context) {
        this.context = context;
    }

    public int getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public boolean isSuccess() {
        return success;
    }

    public Integer executeService(String filePath, String localIP) {

        final String url = WSConstants.HTTP + localIP + WSConstants.PARAM_SLASH + WSConstants.UPDATE;
        Log.e(TAG, "URL ==>  " + url);
        final Response response = new WSUtils().callServiceHttpPostAuth(context, url, generateJsonBody(filePath));
        Log.e(TAG, "Response ==>  " + response);
        return parseResponse(response);
    }

    /*
    This method is used to generate the json body for Add Video
   */
    private RequestBody generateJsonBody(String filePath) {

        File file = new File(filePath);
        //init array with file length
        byte[] bytesArray = new byte[(int) file.length()];

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);

            fis.read(bytesArray); //read file into bytes[]
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.e(TAG, "=======BytesArray======" + bytesToHex(bytesArray));

        return new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(WSConstants.UPDATE,
                        Utils.getInstance().getFileName(filePath),
                        RequestBody.create(MediaType.parse("application/octet-stream"), new File(filePath)))
                .build();

    }

    private final static char[] hexArray = "0123456789ABCDEF".toCharArray();

    private String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    private Integer parseResponse(final Response response) {

        if (response != null) {

            message = response.message();
            status = response.code();

            if (status == (WSConstants.PARAMS_SUCCESS)) {
                success = true;
            }
        }
        return status;
    }
}