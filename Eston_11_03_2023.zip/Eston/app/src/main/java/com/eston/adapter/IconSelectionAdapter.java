package com.eston.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.eston.R;
import com.eston.dataBase.model.Device;
import com.eston.interfaces.ClickListener;
import com.eston.utils.Utils;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class IconSelectionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    // Context
    private Context mContext;

    // List of Home Items
    private ArrayList<Drawable> deviceArrayList;

    // OnClick Listener
    private ClickListener clickListener;


    public IconSelectionAdapter(Context mContext, ArrayList<Drawable> deviceArrayList, ClickListener clickListener) {
        this.mContext = mContext;
        this.deviceArrayList = deviceArrayList;
        this.clickListener = clickListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflate your layout and pass it to view holder
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_icon_selection_item, parent, false);
        return new IconSelectionAdapter.VHItem(itemView);

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        Drawable dataItem = getItem(position);
        ((VHItem) holder).iv_DeviceIcon.setImageDrawable(dataItem);
    }

    @Override
    public int getItemCount() {
        return deviceArrayList.size();
    }

    private Drawable getItem(int position) {
        return deviceArrayList.get(position);
    }


    class VHItem extends RecyclerView.ViewHolder {
        private ImageView iv_DeviceIcon;

        public VHItem(View itemView) {
            super(itemView);
            itemView.setTag(getAdapterPosition());
            iv_DeviceIcon = itemView.findViewById(R.id.iv_DeviceIcon);
            iv_DeviceIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickListener.onItemClick(itemView, getAdapterPosition());
                }
            });
        }
    }
}