package com.eston.adapter;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.eston.R;
import com.eston.dataBase.model.Device;
import com.eston.interfaces.ClickListener;
import com.eston.utils.Utils;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class CreateRoomDevicesListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;

    // Context
    private Context mContext;
    public ArrayList<Device> deviceArrayList;
    private ClickListener clickListener;
    public String roomName = "";

    public CreateRoomDevicesListAdapter(Context mContext, ArrayList<Device> deviceArrayList, ClickListener clickListener) {
        this.mContext = mContext;
        this.deviceArrayList = deviceArrayList;
        this.clickListener = clickListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if (viewType == TYPE_ITEM) {
            //inflate your layout and pass it to view holder
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_create_room_list_item, parent, false);
            return new CreateRoomDevicesListAdapter.VHItem(itemView);
        } else if (viewType == TYPE_HEADER) {
            //inflate your layout and pass it to view holder
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_create_room_name_item, parent, false);
            return new VHHeader(itemView);
        }
        throw new RuntimeException("there is no type that matches the type " + viewType + " + make sure your using types correctly");
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        if (holder instanceof VHItem) {
            Device dataItem = getItem(position);
            //cast holder to VHItem and set data
            ((VHItem) holder).edt_DeviceName.setText(dataItem.deviceName);
            ((VHItem) holder).iv_DeviceIcon.setImageDrawable(Utils.getSelectedDrawableById(mContext, dataItem.deviceImage));
            ((VHItem) holder).iv_DeviceIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickListener.onItemClick(v, position - 1);
                }
            });
        } else if (holder instanceof VHHeader) {
            ((VHHeader) holder).edt_RoomName.setText(roomName);
        }
    }

    public boolean isHeader(int position) {
        return position == 0;
    }

    @Override
    public int getItemCount() {
        return deviceArrayList.size() + 1;
    }

    @Override
    public int getItemViewType(int position) {
        if (isPositionHeader(position))
            return TYPE_HEADER;
        return TYPE_ITEM;
    }

    private boolean isPositionHeader(int position) {
        return position == 0;
    }

    private Device getItem(int position) {
        return deviceArrayList.get(position - 1);
    }


    class VHItem extends RecyclerView.ViewHolder {

        private TextInputEditText edt_DeviceName;
        private ImageView iv_DeviceIcon;

        public VHItem(View itemView) {
            super(itemView);
            itemView.setTag(getAdapterPosition());
            edt_DeviceName = itemView.findViewById(R.id.edt_DeviceName);
            iv_DeviceIcon = itemView.findViewById(R.id.iv_DeviceIcon);
            edt_DeviceName.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    deviceArrayList.get(getAdapterPosition() - 1).deviceName=s.toString();
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });
        }
    }

    class VHHeader extends RecyclerView.ViewHolder {
        TextInputEditText edt_RoomName;

        public VHHeader(View itemView) {
            super(itemView);
            edt_RoomName = itemView.findViewById(R.id.edt_RoomName);
            edt_RoomName.addTextChangedListener(new TextWatcher() {

                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    roomName = s.toString();
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });
        }
    }



}