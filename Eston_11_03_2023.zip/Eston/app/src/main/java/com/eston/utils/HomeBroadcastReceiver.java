package com.eston.utils;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class HomeBroadcastReceiver extends BroadcastReceiver {

    private String TAG = HomeBroadcastReceiver.class.getName();

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.e(TAG, "onComplete" + intent.getAction());
        if (intent.getAction() != null) {
            if (intent.getAction().equals(DownloadManager.ACTION_DOWNLOAD_COMPLETE)) {
               //// RoomOneActivity.downloadComplete = true;
            }
        }
    }
}
