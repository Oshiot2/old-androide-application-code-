package com.eston.ui;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.eston.utils.Utils;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.util.UUID;

public class MqttHelper {

    private String TAG = MqttHelper.class.getName();

    private Context mContext;

    private MqttAndroidClient mqttAndroidClient;

    //    private String serverUriLocal = "tcp://broker.emqx.io:1883";
//    public static String serverUriLocal = "tcp://192.168.10.1:1883";
//    public static String serverUriLocal = "tcp://192.168.0.107:1883";
    public static String serverUriLocal = "tcp://192.162.42.1:1883";
    public static String serverUriGlobel = "tcp://3.214.185.96:1883";
//    public static String serverUriGlobel = "tcp://50.18.230.127:1883";

    private String clientId;

    private String username = "technostacks";
    private String password = "technoiot";

    public MqttHelper(Context context, int serverType) {

        this.mContext = context;
        createMqttAndroidClient(serverType);

    }

    @SuppressLint("HardwareIds")
    public void createMqttAndroidClient(int serverType) {
        clientId = UUID.randomUUID().toString();
        String url = "";
//        if (serverType == 0) {
//            url = serverUriLocal;
//        } else {
            url = serverUriGlobel;
//        }
        mqttAndroidClient = new MqttAndroidClient(mContext, url, clientId,
                new MemoryPersistence(), MqttAndroidClient.Ack.AUTO_ACK);
    }

    public MqttAndroidClient getMqttAndroidClient() {
        return mqttAndroidClient;
    }

    public void setCallback(MqttCallbackExtended callback) {
        mqttAndroidClient.setCallback(callback);
    }

    public void connect() {
        MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
        mqttConnectOptions.setAutomaticReconnect(true);
        mqttConnectOptions.setCleanSession(false);
        mqttConnectOptions.setUserName("");
        mqttConnectOptions.setPassword("".toCharArray());

        try {
            mqttAndroidClient.connect(mqttConnectOptions, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.e(TAG, "Successfully Connect : " + asyncActionToken.getClient().getServerURI());
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Failed to Connect : " + asyncActionToken);
                    Log.e(TAG, "Failed to Connect : " + exception);
//                    Toast.makeText(mContext, "Failed to Connect : " + exception.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void disconnect(@NonNull MqttAndroidClient client) throws MqttException {
        IMqttToken mqttToken = client.disconnect();
        mqttToken.setActionCallback(new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken iMqttToken) {
                Log.e(TAG, "Successfully Disconnected");
            }

            @Override
            public void onFailure(IMqttToken iMqttToken, Throwable throwable) {
                Log.e(TAG, "Failed to Disconnected : " + throwable);
            }
        });
    }

    public void subscribeTopic(String topic) {
        try {
            Log.e(TAG, "SubscribeTopic " + topic);
            IMqttToken iMqttToken = mqttAndroidClient.subscribe(topic, 0);
            iMqttToken.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.e(TAG, "Subscribed Success");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Subscribed Fail : " + exception);
                }
            });
        } catch (MqttException exception) {
            Log.e(TAG, "Subscribed Fail : " + exception);
        }
    }

    public void unSubscribeTopic(String topic) {
        try {
            IMqttToken iMqttToken = mqttAndroidClient.unsubscribe(topic);
            iMqttToken.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.e(TAG, "UnSubscribed Success");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "UnSubscribed Fail : " + exception);
                }
            });
        } catch (MqttException exception) {
            Log.e(TAG, "Subscribed Fail : " + exception);
        }
    }

//    public void publishTopic(String topic, String message) {
//        try {
//            Log.e(TAG, "publishTopic " + topic + " message " + message);
//            MqttMessage mqttMessage = new MqttMessage();
//            mqttMessage.setPayload(message.getBytes());
//            mqttMessage.setQos(2);
//            mqttMessage.setRetained(true);
//            mqttAndroidClient.publish(topic, mqttMessage, null, new IMqttActionListener() {
//                @Override
//                public void onSuccess(IMqttToken asyncActionToken) {
//                    Log.e(TAG, "Publish Success");
//                }
//
//                @Override
//                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
//                    Log.e(TAG, "Publish Fail : " + exception);
//                }
//            });
//        } catch (MqttException exception) {
//            Log.e(TAG, "Publish Fail : " + exception);
//        }
//    }

    public void publishTopic(String topic, String message) {
        try {
            Log.e(TAG, "publishTopic " + topic + " message " + message);
            MqttMessage mqttMessage = new MqttMessage();
            mqttMessage.setPayload(message.getBytes());
            mqttMessage.setQos(0);
            mqttMessage.setRetained(false);
            mqttAndroidClient.publish(topic, mqttMessage, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.e(TAG, "Publish Success");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Publish Fail : " + exception);
                }
            });
        } catch (MqttException exception) {
            Log.e(TAG, "Publish Fail : " + exception);
        }
    }

//    public void publishTopicWithListener(String topic, String message, IMqttActionListener iMqttActionListener) {
//        try {
//            Log.e(TAG, "publishTopic " + topic + " message " + message);
//            MqttMessage mqttMessage = new MqttMessage();
//            mqttMessage.setPayload(message.getBytes());
//            mqttMessage.setQos(2);
//            mqttMessage.setRetained(true);
//            mqttAndroidClient.publish(topic, mqttMessage, null, iMqttActionListener);
//        } catch (MqttException exception) {
//            Log.e(TAG, "Publish Fail : " + exception);
//        }
//    }

    public void publishTopicWithListener(String topic, String message, IMqttActionListener iMqttActionListener) {
        try {
            Log.e(TAG, "publishTopic " + topic + " message " + message);
            MqttMessage mqttMessage = new MqttMessage();
            mqttMessage.setPayload(message.getBytes());
            mqttMessage.setQos(0);
            mqttMessage.setRetained(false);
            mqttAndroidClient.publish(topic, mqttMessage, null, iMqttActionListener);
        } catch (MqttException exception) {
            Log.e(TAG, "Publish Fail : " + exception);
        }
    }
}
