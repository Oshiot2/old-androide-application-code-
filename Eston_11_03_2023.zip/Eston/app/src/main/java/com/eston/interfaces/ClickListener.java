package com.eston.interfaces;

import android.view.View;

public interface ClickListener {

    void onItemClick(View view, int position);
}
