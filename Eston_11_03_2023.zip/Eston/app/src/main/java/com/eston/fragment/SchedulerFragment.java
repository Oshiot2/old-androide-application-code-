package com.eston.fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.eston.EstonApp;
import com.eston.R;
import com.eston.adapter.HomeItemsListAdapter;
import com.eston.adapter.ScheduleListAdapter;
import com.eston.dataBase.model.Device;
import com.eston.dataBase.model.Room;
import com.eston.dataBase.model.Schedule;
import com.eston.dataBase.model.ScheduleDelete;
import com.eston.dialongs.AskFroPin;
import com.eston.interfaces.HomeAdapterItemClickListener;
import com.eston.ui.MqttHelper;
import com.eston.ui.RoomNewActivity;
import com.eston.ui.RoomSelectionForSchedulerActivity;
import com.eston.utils.Constants;
import com.eston.utils.Utils;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import static com.eston.utils.Constants.ROOM_ACTIVITY_REQUEST_CODE;
import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

public class SchedulerFragment extends Fragment implements ScheduleListAdapter.ItemClickListener {

    private static final String TAG = SchedulerFragment.class.getName();
    private static final String EXTRA_TEXT = "text";
    private Button btnCreate_NewScheduler;
    private String pin = "";
    private String MacId = "";
    private ProgressDialog progressDialog;
    private ProgressBar progressSchedule;
    private TextView txt_NoSCHEDULE;
    ArrayList<Schedule> schedulerArrayList = new ArrayList<>();
    private RecyclerView recyclerView;
    ScheduleListAdapter adapter;
    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;
    private MqttHelper mqttHelper;

    public static SchedulerFragment createFor(String text) {
        SchedulerFragment fragment = new SchedulerFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_scanduler, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        Bundle args = getArguments();
        final String text = args != null ? args.getString(EXTRA_TEXT) : "";

        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        TextView txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setVisibility(View.VISIBLE);
//        ImageView iv_Logo = toolbar.findViewById(R.id.iv_Logo);
//        iv_Logo.setVisibility(View.GONE);
//        ImageView iv_wifi = toolbar.findViewById(R.id.iv_wifi);
//        iv_wifi.setVisibility(View.GONE);
        txt_title.setText(text);

        btnCreate_NewScheduler = view.findViewById(R.id.btnCreate_NewScheduler);
        btnCreate_NewScheduler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), RoomSelectionForSchedulerActivity.class);
                startActivityForResult(i, ROOM_ACTIVITY_REQUEST_CODE);
                getActivity().overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
            }
        });

        progressSchedule = view.findViewById(R.id.progressSchedule);
        txt_NoSCHEDULE = view.findViewById(R.id.txt_NoSCHEDULE);
        recyclerView = view.findViewById(R.id.scheduler_recyclerview);

        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference("users");
        mFirebaseDatabase.keepSynced(true);
        mqttHelper = EstonApp.getMqttHelper();

        checkHubAdded();

    }

    private void checkHubAdded() {

        String firebaseUserId = EstonApp.preferenceGetString(PREF_USER_UID, "");
        DatabaseReference userRef = mFirebaseDatabase.child(firebaseUserId).child(Constants.SETTINGS.SETTINGS);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    Object td = dataSnapshot.getValue();

                    HashMap<String, Objects> settings = (HashMap<String, Objects>) td;
                    Log.e(TAG, "settings " + settings);
                    if (settings != null) {
                        if (settings.containsKey(Constants.SETTINGS.PIN) && settings.get(Constants.SETTINGS.PIN) != null) {
                            pin = String.valueOf(settings.get(Constants.SETTINGS.PIN));
                        }
                        if (settings.containsKey(Constants.SETTINGS.MACID) && settings.get(Constants.SETTINGS.MACID) != null) {
                            MacId = String.valueOf(settings.get(Constants.SETTINGS.MACID));
                            if (!MacId.isEmpty()) {
                                getScheduleList();
                            } else {
                                MacId = "";
                                txt_NoSCHEDULE.setText("Can't fetch hub from server.\nPlease setup hub first from setting!!");
                                txt_NoSCHEDULE.setVisibility(View.VISIBLE);
                                recyclerView.setVisibility(View.GONE);
                                progressSchedule.setVisibility(View.GONE);
                            }
                        } else {
                            MacId = "";
                            txt_NoSCHEDULE.setText("Can't fetch hub from server.\nPlease setup hub first from setting!!");
                            txt_NoSCHEDULE.setVisibility(View.VISIBLE);
                            recyclerView.setVisibility(View.GONE);
                            progressSchedule.setVisibility(View.GONE);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "error " + error.getMessage());
                txt_NoSCHEDULE.setText("Network error.\nPlease try again.");
                txt_NoSCHEDULE.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
                progressSchedule.setVisibility(View.GONE);
            }
        });
    }

    private void getScheduleList() {

        DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                .child(Constants.SCHEDULE.SCHEDULER);

        namesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.getValue() != null) {

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            schedulerArrayList = new ArrayList<Schedule>();
                            for (DataSnapshot child : snapshot.getChildren()) {
                                try {
                                    Schedule room = child.getValue(Schedule.class);
                                    schedulerArrayList.add(room);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                            if (getActivity() != null)
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        setupUI(schedulerArrayList);
                                    }
                                });
                        }
                    }).start();
                } else {
//                    txt_NoSCHEDULE.setText("Please create room from settings");
                    txt_NoSCHEDULE.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                    progressSchedule.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                txt_NoSCHEDULE.setText("Network error " + error.getMessage());
                txt_NoSCHEDULE.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
                progressSchedule.setVisibility(View.GONE);
            }
        });
    }

    private void setupUI(List<Schedule> schedules) {

        schedulerArrayList = (ArrayList<Schedule>) schedules;

        Log.e(TAG, "schedules " + schedulerArrayList.toString());

        txt_NoSCHEDULE.setVisibility(View.GONE);
        progressSchedule.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        adapter = new ScheduleListAdapter(getActivity(), schedulerArrayList, SchedulerFragment.this);
        long startTime = System.nanoTime();

        recyclerView.setAdapter(adapter);
        Log.e("Measure", "TASK took : " + ((System.nanoTime() - startTime) / 1000000));

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "onActivityResult requestCode " + requestCode + " resultCode " + resultCode);
        if (requestCode == Constants.ROOM_ACTIVITY_REQUEST_CODE && resultCode == Constants.ROOM_ACTIVITY_RESULT_CODE) {
            checkHubAdded();
        }
    }

    @Override
    public void onItemClick(Schedule item, int position) {

    }

    @Override
    public void onDeleteClick(Schedule item, int position) {

        ScheduleDelete scheduleDelete = new ScheduleDelete();
        scheduleDelete.Action = 2;
        scheduleDelete.Mac = item.Mac;
        scheduleDelete.Switch = item.Switch;
        scheduleDelete.Sch_No = item.Sch_No;
        Gson gson = new Gson();
        String json = gson.toJson(scheduleDelete);
        Log.e(TAG, "json " + json);
        progressDialog = Utils.showProgressDialog(getActivity(), "Deleting...", false);
        Utils.getInstance().hideSoftKeyboard(getActivity());
        mqttHelper.publishTopicWithListener("/eston/" + MacId + "/schedule", json, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {

                DatabaseReference namesRef = mFirebaseDatabase
                        .child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.SCHEDULE.SCHEDULER).child(item.sid);
                Utils.dismissProgressDialog(progressDialog);
                Utils.showSnackbarNonSticky(getActivity().findViewById(android.R.id.content), "Scheduler deleted.", false, getActivity());
                schedulerArrayList.remove(position);
                adapter.notifyItemRemoved(position);
                namesRef.removeValue();

//                namesRef.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
//                    @Override
//                    public void onSuccess(Void runnable) {
//                        Utils.dismissProgressDialog(progressDialog);
//                        Utils.showSnackbarNonSticky(getActivity().findViewById(android.R.id.content), "Scheduler deleted.", false, getActivity());
//                        schedulerArrayList.remove(position);
//                        adapter.notifyItemRemoved(position);
//                    }
//                }).addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(Exception runnable) {
//                        Utils.dismissProgressDialog(progressDialog);
//                        if (runnable != null)
//                            Utils.showSnackbarNonSticky(getActivity().findViewById(android.R.id.content), "Network error " + runnable.getMessage(), true, getActivity());
//                        else
//                            Utils.showSnackbarNonSticky(getActivity().findViewById(android.R.id.content), "Network error, Please try again later. ", true, getActivity());
//                    }
//                });
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Log.e(TAG, "Publish Fail : " + exception);
                Utils.dismissProgressDialog(progressDialog);
                if (exception != null)
                    Utils.showSnackbarNonSticky(getActivity().findViewById(android.R.id.content), "Network error " + exception.getMessage(), true, getActivity());
                else
                    Utils.showSnackbarNonSticky(getActivity().findViewById(android.R.id.content), "Network error, Please try again later. ", true, getActivity());
            }
        });
    }
}
