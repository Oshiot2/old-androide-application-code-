package com.eston.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.eston.EstonApp;
import com.eston.R;
import com.eston.adapter.EditRoomDevicesListAdapter;
import com.eston.dataBase.model.Device;
import com.eston.dataBase.model.Room;
import com.eston.dataBase.model.Schedule;
import com.eston.dialongs.AskFroPin;
import com.eston.utils.Constants;
import com.eston.utils.Utils;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.eston.utils.Constants.ICON_SELECTION_ACTIVITY_REQUEST_CODE;
import static com.eston.utils.Constants.ROOM_ACTIVITY_REQUEST_CODE;
import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

public class CreateSchedulerActivity extends AppCompatActivity {

    private String TAG = CreateSchedulerActivity.class.getName();

//    private Context mContext;
//    private Toolbar toolbar;
//    private TextView toolbar_Title;
//    private String pin = "";
//    private String MACID = "";
//    private ProgressDialog progressDialog;
//    private DatabaseReference mFirebaseDatabase;
//    private FirebaseDatabase mFirebaseInstance;
//    private MqttHelper mqttHelper;
//    private Integer group_POS, child_POS;
//    ArrayList<Room> roomArrayList = new ArrayList<>();

//    @Override
//    public void onBackPressed() {
//        overridePendingTransition(R.anim.anim_trans_right_in, R.anim.anim_trans_right_out);
//        Intent returnIntent = new Intent();
//        setResult(Constants.ROOM_ACTIVITY_RESULT_CODE, returnIntent);
//        finish();
//    }
//
//    private void getIntentData() {
//        if (getIntent() != null) {
//            Bundle args = getIntent().getBundleExtra("BUNDLE");
//            assert args != null;
//            roomArrayList = (ArrayList<Room>) args.getSerializable(Constants.ROOMS);
//            group_POS = (Integer) args.getSerializable(Constants.GROUP_POS);
//            child_POS = (Integer) args.getSerializable(Constants.CHILD_POS);
//        }
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_create_schedule2);

//        mContext = this;
//
//        /*
//         * Get Intent Data
//         * */
//        getIntentData();
//
//        /*
//         * Init Toolbar
//         * */
//        initToolbar();
//
//        /*
//         * Init View
//         * */
////        initView();
//
//        mFirebaseInstance = FirebaseDatabase.getInstance();
//        mFirebaseDatabase = mFirebaseInstance.getReference("users");
//        mFirebaseDatabase.keepSynced(true);
//        mqttHelper = EstonApp.getMqttHelper();

//        checkHubAdded();

    }

//    private void initToolbar() {
//        toolbar = findViewById(R.id.toolbar);
//        ImageView iv_back = findViewById(R.id.iv_back);
//        iv_back.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onBackPressed();
//            }
//        });
//
//        toolbar_Title = toolbar.findViewById(R.id.txt_title);
//        toolbar_Title.setText("Create Scheduler");
//
//    }
//
//    TimePicker tp;
//    RadioGroup rg_Repeat, rg_Turn;
//    String Repeat = "One";
//    Integer Turn = 1;
//    String Time = "";
//    MaterialButton btnCreate_Scheduler, btnSun, btnMon, btnTue, btnWed, btnThu, btnFri, btnSat;
//    Boolean isMon = true, isTue = false, isWed = false, isThu = false, isFri = false, isSat = false, isSun = false;

//    private void initView() {
//
//        btnCreate_Scheduler = findViewById(R.id.btnCreate_NewScheduler);
//        tp = findViewById(R.id.time_picker);
//        rg_Repeat = findViewById(R.id.rg_Repeat);
//        rg_Turn = findViewById(R.id.rg_Turn);
//        btnSun = findViewById(R.id.btnSun);
//        btnMon = findViewById(R.id.btnMon);
//        btnTue = findViewById(R.id.btnTue);
//        btnWed = findViewById(R.id.btnWed);
//        btnThu = findViewById(R.id.btnThu);
//        btnFri = findViewById(R.id.btnFri);
//        btnSat = findViewById(R.id.btnSat);
//
//        tp.setIs24HourView(true);
//        rg_Repeat.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
//
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId) {
//                if (checkedId == R.id.rbOnce) {
//                    Repeat = "One";
//                } else if (checkedId == R.id.rbRepeat) {
//                    Repeat = "Repeat";
//                }
//            }
//        });
//        rg_Turn.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
//
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId) {
//                if (checkedId == R.id.rbOn) {
//                    Turn = 1;
//                } else if (checkedId == R.id.rbOff) {
//                    Turn = 0;
//                }
//            }
//        });
//
//
//        btnMon.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (isMon) {
//                    isMon = false;
//                    btnMon.setBackgroundTintList(ContextCompat.getColorStateList(CreateSchedulerActivity.this, R.color.divider));
//                } else {
//                    isMon = true;
//                    ViewCompat.setBackgroundTintList(btnMon, ColorStateList.valueOf(Utils.getPrimaryThemeColor(CreateSchedulerActivity.this)));
//                }
//            }
//        });
//        btnTue.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (isTue) {
//                    isTue = false;
//                    btnTue.setBackgroundTintList(ContextCompat.getColorStateList(CreateSchedulerActivity.this, R.color.divider));
//                } else {
//                    isTue = true;
//                    ViewCompat.setBackgroundTintList(btnTue, ColorStateList.valueOf(Utils.getPrimaryThemeColor(CreateSchedulerActivity.this)));
//                }
//            }
//        });
//        btnWed.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (isWed) {
//                    isWed = false;
//                    btnWed.setBackgroundTintList(ContextCompat.getColorStateList(CreateSchedulerActivity.this, R.color.divider));
//                } else {
//                    isWed = true;
//                    ViewCompat.setBackgroundTintList(btnWed, ColorStateList.valueOf(Utils.getPrimaryThemeColor(CreateSchedulerActivity.this)));
//                }
//            }
//        });
//        btnThu.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (isThu) {
//                    isThu = false;
//                    btnThu.setBackgroundTintList(ContextCompat.getColorStateList(CreateSchedulerActivity.this, R.color.divider));
//                } else {
//                    isThu = true;
//                    ViewCompat.setBackgroundTintList(btnThu, ColorStateList.valueOf(Utils.getPrimaryThemeColor(CreateSchedulerActivity.this)));
//                }
//            }
//        });
//        btnFri.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (isFri) {
//                    isFri = false;
//                    btnFri.setBackgroundTintList(ContextCompat.getColorStateList(CreateSchedulerActivity.this, R.color.divider));
//                } else {
//                    isFri = true;
//                    ViewCompat.setBackgroundTintList(btnFri, ColorStateList.valueOf(Utils.getPrimaryThemeColor(CreateSchedulerActivity.this)));
//                }
//            }
//        });
//        btnSat.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (isSat) {
//                    isSat = false;
//                    btnSat.setBackgroundTintList(ContextCompat.getColorStateList(CreateSchedulerActivity.this, R.color.divider));
//                } else {
//                    isSat = true;
//                    ViewCompat.setBackgroundTintList(btnSat, ColorStateList.valueOf(Utils.getPrimaryThemeColor(CreateSchedulerActivity.this)));
//                }
//            }
//        });
//        btnSun.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (isSun) {
//                    isSun = false;
//                    btnSun.setBackgroundTintList(ContextCompat.getColorStateList(CreateSchedulerActivity.this, R.color.divider));
//                } else {
//                    isSun = true;
//                    ViewCompat.setBackgroundTintList(btnSun, ColorStateList.valueOf(Utils.getPrimaryThemeColor(CreateSchedulerActivity.this)));
//                }
//            }
//        });
//
//        btnCreate_Scheduler.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                try {
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                        String hr = tp.getHour() < 10 ? "0" + tp.getHour() : tp.getHour() + "";
//                        String mn = tp.getMinute() < 10 ? "0" + tp.getMinute() : tp.getMinute() + "";
//                        Time = hr + ":" + mn;
//                    } else {
//                        String hr = tp.getCurrentHour() < 10 ? "0" + tp.getCurrentHour() : tp.getCurrentHour() + "";
//                        String mn = tp.getCurrentMinute() < 10 ? "0" + tp.getCurrentMinute() : tp.getCurrentMinute() + "";
//                        Time = hr + ":" + mn;
//                    }
//
//                    Schedule schedule = new Schedule();
//                    schedule.Action = 1;
//                    schedule.Mac = roomArrayList.get(group_POS).roomUUID;
//                    schedule.Switch = (roomArrayList.get(group_POS).devices.get(child_POS).devicePOS + 1);
//                    schedule.State = Turn;
//                    schedule.DaysCount = getDaysCount();
//                    schedule.DaysNumber = getDaysNumber();
//                    schedule.Time = Time;
//                    schedule.Sch_No = Utils.getTimestamp();
//                    schedule.sid = Utils.getTimestamp();
//                    schedule.rid = roomArrayList.get(group_POS).rid;
//                    schedule.roomName = roomArrayList.get(group_POS).roomName;
//                    schedule.deviceName = roomArrayList.get(group_POS).devices.get(child_POS).deviceName;
//
//                    updateOnDatabase(schedule);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//    }
//
//    private Integer getDaysCount() {
//        int DaysCount = 0;
//        if (isMon) {
//            DaysCount = DaysCount + 1;
//        }
//        if (isTue) {
//            DaysCount = DaysCount + 1;
//        }
//        if (isWed) {
//            DaysCount = DaysCount + 1;
//        }
//        if (isThu) {
//            DaysCount = DaysCount + 1;
//        }
//        if (isFri) {
//            DaysCount = DaysCount + 1;
//        }
//        if (isSat) {
//            DaysCount = DaysCount + 1;
//        }
//        if (isSun) {
//            DaysCount = DaysCount + 1;
//        }
//
//        return DaysCount;
//    }
//
//    private ArrayList<Integer> getDaysNumber() {
//        ArrayList<Integer> DaysNumber = new ArrayList<>();
//        if (isMon) {
//            DaysNumber.add(0);
//        }
//        if (isTue) {
//            DaysNumber.add(1);
//        }
//        if (isWed) {
//            DaysNumber.add(2);
//        }
//        if (isThu) {
//            DaysNumber.add(3);
//        }
//        if (isFri) {
//            DaysNumber.add(4);
//        }
//        if (isSat) {
//            DaysNumber.add(5);
//        }
//        if (isSun) {
//            DaysNumber.add(6);
//        }
//
//        return DaysNumber;
//    }
//
//    private void checkHubAdded() {
//        String firebaseUserId = EstonApp.preferenceGetString(PREF_USER_UID, "");
//        DatabaseReference userRef = mFirebaseDatabase.child(firebaseUserId).child(Constants.SETTINGS.SETTINGS);
//        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                try {
//                    Object td = dataSnapshot.getValue();
//                    HashMap<String, String> settings = (HashMap<String, String>) td;
//                    Log.e(TAG, "settings " + settings);
//                    if (settings != null && settings.get(Constants.SETTINGS.PIN) != null && !Objects.requireNonNull(settings.get(Constants.SETTINGS.PIN)).isEmpty()) {
//                        pin = settings.get(Constants.SETTINGS.PIN);
//                    }
//                    if (settings != null && !Objects.requireNonNull(settings.get(Constants.SETTINGS.MACID)).isEmpty()) {
//                        MACID = settings.get(Constants.SETTINGS.MACID);
//                    } else {
//                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
//                        builder.setTitle("Error");
//                        builder.setCancelable(false);
//                        builder.setMessage("Can't fetch hub from server.\nPlease setup hub from settings!!");
//                        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                            public void onClick(DialogInterface dialog, int id) {
//                                onBackPressed();
//                            }
//                        });
//                        builder.show();
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Log.e(TAG, "error " + error.getMessage());
//            }
//        });
//    }
//
//    private void updateOnDatabase(Schedule schedule) {
//
//        progressDialog = Utils.showProgressDialog(mContext, getString(R.string.msg_loading), false);
//
//        DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
//                .child(Constants.SCHEDULE.SCHEDULER).child(schedule.Sch_No);
//
//        namesRef.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot snapshot) {
//                if (snapshot.getValue() == null) {
//                    Log.e(TAG, "schedule " + schedule.toMap());
//                    namesRef.updateChildren(schedule.toMap());
//                    Gson gson = new Gson();
//                    String json = gson.toJson(schedule);
//                    Log.e(TAG, "json " + json);
//                    mqttHelper.publishTopicWithListener("/eston/" + MACID + "/schedule", json, new IMqttActionListener() {
//                        @Override
//                        public void onSuccess(IMqttToken asyncActionToken) {
//                            Utils.dismissProgressDialog(progressDialog);
//                            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Schedule created", false, CreateSchedulerActivity.this);
//                            onBackPressed();
//                        }
//
//                        @Override
//                        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
//                            namesRef.removeValue();
//                            Utils.dismissProgressDialog(progressDialog);
//                            if (exception != null)
//                                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Network error " + exception.getMessage(), true, CreateSchedulerActivity.this);
//                            else
//                                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Network error, Please try again later. ", true, CreateSchedulerActivity.this);
//                        }
//                    });
//
////                    namesRef.updateChildren(schedule.toMap()).addOnSuccessListener(new OnSuccessListener<Void>() {
////                        @Override
////                        public void onSuccess(Void runnable) {
////                            Gson gson = new Gson();
////                            String json = gson.toJson(schedule);
////                            Log.e(TAG, "json " + json);
////                            mqttHelper.publishTopicWithListener("/eston/" + HUBID + "/schedule", json, new IMqttActionListener() {
////                                @Override
////                                public void onSuccess(IMqttToken asyncActionToken) {
////                                    Utils.dismissProgressDialog(progressDialog);
////                                    Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Schedule created", false, CreateSchedulerActivity.this);
////                                    onBackPressed();
////                                }
////
////                                @Override
////                                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
////                                    namesRef.removeValue();
////                                    Utils.dismissProgressDialog(progressDialog);
////                                    if (exception != null)
////                                        Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Network error " + exception.getMessage(), true, CreateSchedulerActivity.this);
////                                    else
////                                        Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Network error, Please try again later. ", true, CreateSchedulerActivity.this);
////                                }
////                            });
////
////                        }
////                    }).addOnFailureListener(new OnFailureListener() {
////                        @Override
////                        public void onFailure(@NonNull Exception runnable) {
////                            Utils.dismissProgressDialog(progressDialog);
////                            Toast.makeText(mContext, "Error " + runnable.getMessage(), Toast.LENGTH_SHORT).show();
////                        }
////                    });
//                } else {
//                    Utils.dismissProgressDialog(progressDialog);
//                    Toast.makeText(mContext, "This schedule is already exist in your account.", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Utils.dismissProgressDialog(progressDialog);
//                Toast.makeText(mContext, "Error " + error.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }

}
