package com.eston.dialongs;

import android.content.Context;

import com.eston.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PhotoSelectionAsk {
    private String msg;
    private PhotoSelectionListeners photoSelectionListeners;

    private Context mContext;

    public PhotoSelectionAsk(Context context, String msg, PhotoSelectionListeners photoSelectionListeners) {
        this.mContext = context;
        this.msg = msg;
        this.photoSelectionListeners = photoSelectionListeners;
    }

    public void show() {

        final BottomSheetDialog mBottomSheetDialog = new BottomSheetDialog(mContext,R.style.SheetDialog);
        View sheetView = mBottomSheetDialog.getLayoutInflater().inflate(R.layout.dialog_add_document, null);

        TextView tv_Title_PhotoSelection = (TextView) sheetView.findViewById(R.id.tv_Title_PhotoSelection);
        tv_Title_PhotoSelection.setText(msg);
        ImageView iv_Gallery_PhotoSelection = (ImageView) sheetView.findViewById(R.id.iv_Gallery_PhotoSelection);
        ImageView iv_Camera_PhotoSelection = (ImageView) sheetView.findViewById(R.id.iv_Camera_PhotoSelection);
        ImageView iv_Remove_PhotoSelection = (ImageView) sheetView.findViewById(R.id.iv_Remove_PhotoSelection);

        LinearLayout llCamera = sheetView.findViewById(R.id.llCamera);
        LinearLayout llGallery = sheetView.findViewById(R.id.llGallery);
        LinearLayout llRemovePhoto = sheetView.findViewById(R.id.llRemovePhoto);

        llGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                photoSelectionListeners.onGalleryClick();
                mBottomSheetDialog.dismiss();
            }
        });
        llCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                photoSelectionListeners.onCameraClick();
                mBottomSheetDialog.dismiss();
            }
        });
        llRemovePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                photoSelectionListeners.onRemoveClick();
                mBottomSheetDialog.dismiss();
            }
        });
        mBottomSheetDialog.setContentView(sheetView);
        mBottomSheetDialog.show();

    }
}