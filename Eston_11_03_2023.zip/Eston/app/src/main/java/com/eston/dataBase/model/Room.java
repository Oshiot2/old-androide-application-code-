package com.eston.dataBase.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Room implements Serializable {

    public String rid;
    public String uid;
    public String roomUUID;
    public String roomName;
    public String roomImage;
    public String macID;
    public ArrayList<Device> devices = new ArrayList<Device>();

    public int getActiveDevicesCount() {
        int count = 0;
        for (int i = 0; i < devices.size(); i++) {
            if (devices.get(i) != null && devices.get(i).deviceOnOffState == 1) {
                count = count + 1;
            }
        }
        return count;
    }


    public String getPublishAddress(String MacID) {
        return "/eston/" + MacID + "/query";
    }

    public String getSubscribeAddress(String MacID) {
        return "/" + MacID + "/RES";
    }

    public String getPublishControlAddress(String MacID) {
//        return "/eston/" + HubId + "/state/control";
        return "/" + MacID + "/CTL";
    }
    public String getPublishRemoveRoom(String HubId) {
        return "/eston/" + HubId + "/remove";
    }

    public boolean flagFanPresent = false;
    public String getControlString(String madId, ArrayList<Device> devices, int pos, boolean isFanPM, int currentCount) {
        ArrayList<Device> deviceArrayList = new ArrayList<>();
        for (Device p : devices) {
            deviceArrayList.add(p.clone());
        }
        if (isFanPM) {
            deviceArrayList.get(pos).deviceFanCurrentValue = currentCount;
        } else {
            deviceArrayList.get(pos).deviceOnOffState = deviceArrayList.get(pos).deviceOnOffState == 1 ? 0 : 1;
        }

        StringBuffer data = new StringBuffer("*,MAC=");
        data.append(madId);
        data.append(",LD=");
        for (int i = 0; i < deviceArrayList.size(); i++) {
            if (deviceArrayList.get(i).devicePOS < 12) {
                data.append(deviceArrayList.get(i).deviceOnOffState == 1 ? "1" : "0");
                flagFanPresent = false;
            } else {
                flagFanPresent = true;
            }
        }

        if (flagFanPresent) {
            data.append(",FN=");
            for (int i = 0; i < deviceArrayList.size(); i++) {
                if (deviceArrayList.get(i).devicePOS >= 12) {
                    data.append(deviceArrayList.get(i).deviceOnOffState == 1 ? "1" : "0");
                }
            }
            data.append(",SP=");
            for (int i = 0; i < deviceArrayList.size(); i++) {
                if (deviceArrayList.get(i).devicePOS >= 12) {
                    data.append(String.valueOf(deviceArrayList.get(i).deviceFanCurrentValue));
                }
            }
        }

//        for (int i = 0; i < deviceArrayList.size(); i++) {
//            if (deviceArrayList.get(i).devicePOS <= 5) {
////                data.replace(i, i + 1, deviceArrayList.get(i).deviceOnOffState == 1 ? "1" : "0");
//                data.append(deviceArrayList.get(i).deviceOnOffState == 1 ? "1" : "0");
//            } else if (deviceArrayList.get(i).devicePOS == 6) {
////                data.replace(6, 7, deviceArrayList.get(i).deviceOnOffState == 1 ? "1" : "0");
//                data.append(deviceArrayList.get(i).deviceOnOffState == 1 ? "1" : "0");
////                data.replace(7, 8, String.valueOf(deviceArrayList.get(i).deviceFanCurrentValue));
//                data.append(String.valueOf(deviceArrayList.get(i).deviceFanCurrentValue));
//            } else if (deviceArrayList.get(i).devicePOS > 6 && deviceArrayList.get(i).devicePOS <= 12) {
////                data.replace(i + 1, i + 2, deviceArrayList.get(i).deviceOnOffState == 1 ? "1" : "0");
//                data.append(deviceArrayList.get(i).deviceOnOffState == 1 ? "1" : "0");
//            } else if (deviceArrayList.get(i).devicePOS == 13) {
////                data.replace(14, 15, deviceArrayList.get(i).deviceOnOffState == 1 ? "1" : "0");
//                data.append(deviceArrayList.get(i).deviceOnOffState == 1 ? "1" : "0");
////                data.replace(15, 16, String.valueOf(deviceArrayList.get(i).deviceFanCurrentValue));
//                data.append(String.valueOf(deviceArrayList.get(i).deviceFanCurrentValue));
//            }
//        }
//        if (deviceArrayList.size() == 2) {
//            data.replace(0, 1, deviceArrayList.get(0).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(1, 2, deviceArrayList.get(1).deviceOnOffState == 1 ? "1" : "0");
//        } else if (deviceArrayList.size() == 4) {
//            data.replace(0, 1, deviceArrayList.get(0).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(1, 2, deviceArrayList.get(1).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(2, 3, deviceArrayList.get(2).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(3, 4, deviceArrayList.get(3).deviceOnOffState == 1 ? "1" : "0");
//        } else if (deviceArrayList.size() == 5) {
//            data.replace(0, 1, deviceArrayList.get(0).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(1, 2, deviceArrayList.get(1).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(2, 3, deviceArrayList.get(2).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(3, 4, deviceArrayList.get(3).deviceOnOffState == 1 ? "1" : "0");
//
//            data.replace(6, 7, deviceArrayList.get(4).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(7, 8, String.valueOf(deviceArrayList.get(4).deviceFanCurrentValue));
//
//        } else if (deviceArrayList.size() == 7) {
//
//            data.replace(0, 1, deviceArrayList.get(0).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(1, 2, deviceArrayList.get(1).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(2, 3, deviceArrayList.get(2).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(3, 4, deviceArrayList.get(3).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(4, 5, deviceArrayList.get(4).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(5, 6, deviceArrayList.get(5).deviceOnOffState == 1 ? "1" : "0");
//
//            data.replace(6, 7, deviceArrayList.get(6).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(7, 8, String.valueOf(deviceArrayList.get(6).deviceFanCurrentValue));
//
//        } else if (deviceArrayList.size() == 10) {
//
//            data.replace(0, 1, deviceArrayList.get(0).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(1, 2, deviceArrayList.get(1).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(2, 3, deviceArrayList.get(2).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(3, 4, deviceArrayList.get(3).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(4, 5, deviceArrayList.get(4).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(5, 6, deviceArrayList.get(5).deviceOnOffState == 1 ? "1" : "0");
//
//            data.replace(6, 7, deviceArrayList.get(deviceArrayList.size() - 2).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(7, 8, String.valueOf(deviceArrayList.get(deviceArrayList.size() - 2).deviceFanCurrentValue));
//
//            data.replace(8, 9, deviceArrayList.get(6).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(9, 10, deviceArrayList.get(7).deviceOnOffState == 1 ? "1" : "0");
//
//            data.replace(14, 15, deviceArrayList.get(deviceArrayList.size() - 1).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(15, 16, String.valueOf(deviceArrayList.get(deviceArrayList.size() - 1).deviceFanCurrentValue));
//
//        } else if (deviceArrayList.size() == 14) {
//
//            data.replace(0, 1, deviceArrayList.get(0).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(1, 2, deviceArrayList.get(1).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(2, 3, deviceArrayList.get(2).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(3, 4, deviceArrayList.get(3).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(4, 5, deviceArrayList.get(4).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(5, 6, deviceArrayList.get(5).deviceOnOffState == 1 ? "1" : "0");
//
//            data.replace(6, 7, deviceArrayList.get(deviceArrayList.size() - 2).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(7, 8, String.valueOf(deviceArrayList.get(deviceArrayList.size() - 2).deviceFanCurrentValue));
//
//            data.replace(8, 9, deviceArrayList.get(6).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(9, 10, deviceArrayList.get(7).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(10, 11, deviceArrayList.get(8).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(11, 12, deviceArrayList.get(9).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(12, 13, deviceArrayList.get(10).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(13, 14, deviceArrayList.get(11).deviceOnOffState == 1 ? "1" : "0");
//
//            data.replace(14, 15, deviceArrayList.get(deviceArrayList.size() - 1).deviceOnOffState == 1 ? "1" : "0");
//            data.replace(15, 16, String.valueOf(deviceArrayList.get(deviceArrayList.size() - 1).deviceFanCurrentValue));
//
//        }
//        data.insert(0, "*,MAC=" + madId +  ",#");
        data.append(",PWD=1234,#");
        return String.valueOf(data);
    }


    @Override
    public String toString() {
        return "Room{" +
                "rid=" + rid +
                ", uid='" + uid + '\'' +
                ", roomUUID='" + roomUUID + '\'' +
                ", roomName='" + roomName + '\'' +
                ", roomImage='" + roomImage + '\'' +
                ", devices='" + devices + '\'' +
                '}';
    }
}