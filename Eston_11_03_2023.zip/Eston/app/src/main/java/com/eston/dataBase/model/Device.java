package com.eston.dataBase.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.firebase.database.Exclude;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@Entity
public class Device implements Serializable {

    public int did;
    public String uid;
    public String rid;
    public String deviceUUID;
    public String deviceName;
    public Integer deviceImage = 0;
    public Integer devicePOS = 0;
    public Integer deviceOnOffState = 0;
    public Integer deviceType = 0; // 0 == Switch 1 == Fan
    public Integer deviceFanCurrentValue = 0;
    public Integer isDeleted = 0;

    public Device clone() {
        Device p = new Device();
        p.did = this.did;
        p.uid = this.uid;
        p.rid = this.rid;
        p.deviceUUID = this.deviceUUID;
        p.deviceName = this.deviceName;
        p.devicePOS = this.devicePOS;
        p.deviceImage = this.deviceImage;
        p.deviceOnOffState = this.deviceOnOffState;
        p.deviceType = this.deviceType;
        p.deviceFanCurrentValue = this.deviceFanCurrentValue;
        p.isDeleted = this.isDeleted;
        return p;
    }

    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("did", this.did);
        result.put("uid", this.uid);
        result.put("rid", this.rid);
        result.put("deviceUUID", this.deviceUUID);
        result.put("deviceName", this.deviceName);
        result.put("devicePOS", this.devicePOS);
        result.put("deviceImage", this.deviceImage);
        result.put("deviceOnOffState", this.deviceOnOffState);
        result.put("deviceType", this.deviceType);
        result.put("deviceFanCurrentValue", this.deviceFanCurrentValue);
        result.put("isDeleted", this.isDeleted);
        return result;
    }

    @Override
    public String toString() {
        return "Device{" +
                "did=" + did +
                ", uid='" + uid + '\'' +
                ", rid='" + rid + '\'' +
                ", deviceUUID='" + deviceUUID + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", deviceImage=" + deviceImage +
                ", devicePOS=" + devicePOS +
                ", deviceOnOffState=" + deviceOnOffState +
                ", deviceType=" + deviceType +
                ", deviceFanCurrentValue=" + deviceFanCurrentValue +
                ", isDeleted=" + isDeleted +
                '}';
    }
}