package com.eston.ui;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bartoszlipinski.recyclerviewheader2.RecyclerViewHeader;
import com.bumptech.glide.Glide;
import com.eston.EstonApp;
import com.eston.R;
import com.eston.adapter.RoomDevicesListAdapter;
import com.eston.dataBase.model.Device;
import com.eston.dataBase.model.Room;
import com.eston.dialongs.AskFroPin;
import com.eston.interfaces.DeviceItemClickListener;
import com.eston.utils.Constants;
import com.eston.utils.Networkstatus;
import com.eston.utils.SpacesItemDecoration;
import com.eston.utils.SwipeHelper;
import com.eston.utils.Utils;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.File;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

public class RoomNewActivity extends AppCompatActivity implements DeviceItemClickListener {

    private String TAG = RoomNewActivity.class.getName();
    private String pin = "";
    private String MacId = "";
    private long mLastClickTime = 0;
    private Context mContext;
    private Toolbar toolbar;
    private TextView txt_title,tvRoomName,tvLastSync;
    private ImageView iv_room_image;
    private ProgressDialog progressDialog;
    private RecyclerView recyclerView;
    private RoomDevicesListAdapter roomDevicesListAdapter;
    private ImageView ivEdit,ivDelete,ivRefresh;

    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;
    private MqttHelper mqttHelper;
    private Room topicsHelper;
    ArrayList<Room> roomArrayList = new ArrayList<>();
    String status;

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        overridePendingTransition(R.anim.anim_trans_right_in, R.anim.anim_trans_right_out);
        if (mqttHelper != null)
            mqttHelper.unSubscribeTopic(topicsHelper.getSubscribeAddress(MacId));
        Intent returnIntent = new Intent();
        setResult(Constants.ROOM_ACTIVITY_RESULT_CODE, returnIntent);
        finish();
    }

    private void getIntentData() {
        if (getIntent() != null) {
//            topicsHelper = (Room) getIntent().getSerializableExtra(Constants.TOPICS);
            Bundle args = getIntent().getBundleExtra("BUNDLE");
            assert args != null;
            topicsHelper = (Room) args.getSerializable(Constants.TOPICS);
            Log.e(TAG, "topicsHelper " + topicsHelper);
            roomArrayList = (ArrayList<Room>) args.getSerializable(Constants.ROOMS);
            MacId = roomArrayList.get(getIntent().getIntExtra("pos",0)).roomUUID;
            Log.e(TAG, "MacId:  " + MacId);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_room2);

        mContext = this;

        /*
         * Get Intent Data
         * */
        getIntentData();

        /*
         * Init Toolbar
         * */
        initToolbar();

        /*
         * Init View
         * */
        initView();

        onSyncClicked();


    }

    private void initToolbar() {
//        toolbar = findViewById(R.id.toolbar);
        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

//        toolbar_Title = toolbar.findViewById(R.id.txt_title);
        txt_title = findViewById(R.id.txt_title);
        tvRoomName = findViewById(R.id.tvRoomName);
        txt_title.setText(topicsHelper.roomName);
        tvRoomName.setText(topicsHelper.roomName);

//        ImageView iv_more = toolbar.findViewById(R.id.iv_more);
//        iv_more.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                showMenu(v);
//            }
//        });
    }

    public boolean flagFanPresent = false;
    private void initView() {

        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference("users");
        mFirebaseDatabase.keepSynced(true);

        iv_room_image = findViewById(R.id.iv_room_image);
        ivEdit = findViewById(R.id.ivEdit);
        ivDelete = findViewById(R.id.ivDelete);
        ivRefresh = findViewById(R.id.ivRefresh);
        tvLastSync = findViewById(R.id.tvLastSync);
        recyclerView = findViewById(R.id.devices_recyclerview);
        roomDevicesListAdapter = new RoomDevicesListAdapter(mContext, topicsHelper.devices, RoomNewActivity.this);

        GridLayoutManager layoutManager = new GridLayoutManager(mContext, 3);
        layoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                switch (roomDevicesListAdapter.getItemViewType(position)) {
                    case 0:
                        return 3;
                    case 1:
                        return 1;
                    default:
                        return -1;
                }
            }
        });

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(roomDevicesListAdapter);
//        RecyclerViewHeader recyclerHeader = (RecyclerViewHeader) findViewById(R.id.header);
//        recyclerHeader.attachTo(recyclerView);
        SwipeHelper swipeHelper = new SwipeHelper(this, recyclerView) {
            @Override
            public void instantiateUnderlayButton(RecyclerView.ViewHolder viewHolder, List<UnderlayButton> underlayButtons) {
                underlayButtons.add(new SwipeHelper.UnderlayButton(
                        "Delete",
                        0,
                        Color.parseColor("#FF3C30"),
                        new SwipeHelper.UnderlayButtonClickListener() {
                            @Override
                            public void onClick(int pos) {
                                onDeleteClick(pos);
                            }
                        }
                ));
            }
        };
        try {
            Glide.with(mContext)
                    .load(Uri.fromFile(new File(topicsHelper.roomImage)))
                    .centerCrop()
                    .placeholder(R.drawable.bed_room)
                    .into(iv_room_image);
        } catch (Exception e) {
            iv_room_image.setImageResource(R.drawable.bed_room);
        }

        mqttHelper = EstonApp.getMqttHelper();
//        checkHubAdded();
        getPin();
        initMqtt();

        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.e(TAG, "=======connectComplete==========");
            }

            @Override
            public void connectionLost(Throwable cause) {
                Log.e(TAG, "=======connectionLost==========");
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Log.e(TAG, "=======topic==========" + topic);
                Log.e(TAG, "=======messageArrived==========" + message);

                String[] mainArray = message.toString().split(",");
                Log.e("RoomNewActivity","MainArray Length" + mainArray.length);
                Log.e("RoomNewActivity","First" + mainArray[0]);
                Log.e("RoomNewActivity","Second" + mainArray[1]);
                Log.e("RoomNewActivity","Third" + mainArray[2]);
                Log.e("RoomNewActivity","Fourth" + mainArray[3]);
                Log.e("RoomNewActivity","Fifth" + mainArray[4]);


                if (topicsHelper.getSubscribeAddress(MacId).equals(topic)) {
                    if (message != null) {

                        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
                        String currentDateandTime = sdf.format(new Date());
                        tvLastSync.setText("Last Synced: " + currentDateandTime);
                        String  macId = "",loadStr = "",fanStr = "", spStr = "";

                        macId = mainArray[1].substring(4);
                        loadStr = mainArray[2].substring(3);
                        fanStr = mainArray[3].substring(3);
                        spStr = mainArray[4].substring(3);


                        Log.e(TAG, "macId " + macId);
                        Log.e(TAG, "topicsHelper.roomUUID " + topicsHelper.roomUUID);
                        Log.e(TAG, "Load " + loadStr);
                        Log.e(TAG, "Fan " + fanStr);
                        Log.e(TAG, "Speed " + spStr);

                        if (macId.equalsIgnoreCase(MacId)) {
                            Log.e(TAG, "macId equalsIgnoreCase");
                            for (int i = 0; i < topicsHelper.devices.size(); i++) {
                                if (topicsHelper.devices.get(i).devicePOS < 12) {
                                    topicsHelper.devices.get(i).deviceOnOffState = Integer.valueOf(String.valueOf(loadStr.charAt(i)));
                                    Log.e(TAG, "DeviceOnOffState " + topicsHelper.devices.get(i).deviceOnOffState);
                                    flagFanPresent = false;
                                } else {
                                    flagFanPresent = true;
                                }
                            }
                            Log.e(TAG, "flagFanPresent " + flagFanPresent);

                            if (flagFanPresent) {
                                Log.e(TAG, "devices size " + topicsHelper.devices.size());
                                topicsHelper.devices.get(topicsHelper.devices.size() - 1).deviceOnOffState = Integer.valueOf(fanStr);
                                Log.e(TAG, "FanOnOffState " + topicsHelper.devices.get(topicsHelper.devices.size() - 1).deviceOnOffState);

                                topicsHelper.devices.get(topicsHelper.devices.size() - 1).deviceFanCurrentValue = Integer.valueOf(spStr);
                                Log.e(TAG, "SpeedValueState " + topicsHelper.devices.get(topicsHelper.devices.size() - 1).deviceFanCurrentValue);
                            }

                            roomDevicesListAdapter.notifyDataSetChanged();
                        }
                    }
                }

//                for (int i = 0; i < roomArrayList.size(); i++) {
//                    if (topic.toString().equals(roomArrayList.get(i).getSubscribeAddress(MacId))) {
//                        if (message != null && message.toString().length() == 31) {
//                            String data = "", macId = "";
//                            macId = message.toString().substring((message.toString().indexOf("M") + 1), message.toString().indexOf("R"));
//                            data = message.toString().substring((message.toString().indexOf("R") + 1), message.toString().indexOf("@"));
//                            Log.e(TAG, "macId " + macId);
//                            Log.e(TAG, "roomArrayList.get(i).roomUUID " + roomArrayList.get(i).roomUUID);
//                            Log.e(TAG, "data " + data);
//
//                            if (macId.equalsIgnoreCase(roomArrayList.get(i).roomUUID)) {
//
//                                for (int j = 0; j < roomArrayList.get(i).devices.size(); j++) {
//                                    if (roomArrayList.get(i).devices.get(j).devicePOS <= 5) {
//                                        roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(j)));
//                                    } else if (roomArrayList.get(i).devices.get(j).devicePOS == 6) {
//                                        roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
//                                        roomArrayList.get(i).devices.get(j).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
//                                    } else if (roomArrayList.get(i).devices.get(j).devicePOS > 6 && topicsHelper.devices.get(i).devicePOS <= 12) {
//                                        roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(j + 1)));
//                                    } else if (roomArrayList.get(i).devices.get(j).devicePOS == 13) {
//                                        roomArrayList.get(i).devices.get(j).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(14)));
//                                        roomArrayList.get(i).devices.get(j).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(15)));
//                                    }
//                                }
//                                updateOnDatabase(roomArrayList.get(i), roomArrayList.get(i).devices);
//                                break;
////                                Integer deviceOnOffState_POS_0 = Integer.valueOf(String.valueOf(data.charAt(0)));
////                                Integer deviceOnOffStatePOS_1 = Integer.valueOf(String.valueOf(data.charAt(1)));
////                                if (roomArrayList.get(i).devices.size() == 2) {
////                                    roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
////                                    roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
////                                } else if (roomArrayList.get(i).devices.size() == 4) {
////                                    roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
////                                    roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
////                                    roomArrayList.get(i).devices.get(2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(2)));
////                                    roomArrayList.get(i).devices.get(3).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(3)));
////                                } else if (roomArrayList.get(i).devices.size() == 5) {
////                                    roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
////                                    roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
////                                    roomArrayList.get(i).devices.get(2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(2)));
////                                    roomArrayList.get(i).devices.get(3).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(3)));
////
////                                    roomArrayList.get(i).devices.get(4).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
////                                    roomArrayList.get(i).devices.get(4).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
////
////                                } else if (roomArrayList.get(i).devices.size() == 7) {
////                                    roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
////                                    roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
////                                    roomArrayList.get(i).devices.get(2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(2)));
////                                    roomArrayList.get(i).devices.get(3).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(3)));
////                                    roomArrayList.get(i).devices.get(4).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(4)));
////                                    roomArrayList.get(i).devices.get(5).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(5)));
////
////                                    roomArrayList.get(i).devices.get(6).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
////                                    roomArrayList.get(i).devices.get(6).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
////
////                                } else if (roomArrayList.get(i).devices.size() == 10) {
////                                    roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
////                                    roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
////                                    roomArrayList.get(i).devices.get(2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(2)));
////                                    roomArrayList.get(i).devices.get(3).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(3)));
////                                    roomArrayList.get(i).devices.get(4).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(4)));
////                                    roomArrayList.get(i).devices.get(5).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(5)));
////
////                                    roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
////                                    roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 2).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
////
////                                    roomArrayList.get(i).devices.get(6).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(8)));
////                                    roomArrayList.get(i).devices.get(7).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(9)));
////
////                                    roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 1).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(14)));
////                                    roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 1).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(15)));
////
////                                } else if (roomArrayList.get(i).devices.size() == 14) {
////                                    roomArrayList.get(i).devices.get(0).deviceOnOffState = deviceOnOffState_POS_0;
////                                    roomArrayList.get(i).devices.get(1).deviceOnOffState = deviceOnOffStatePOS_1;
////                                    roomArrayList.get(i).devices.get(2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(2)));
////                                    roomArrayList.get(i).devices.get(3).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(3)));
////                                    roomArrayList.get(i).devices.get(4).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(4)));
////                                    roomArrayList.get(i).devices.get(5).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(5)));
////
////                                    roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 2).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(6)));
////                                    roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 2).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(7)));
////
////                                    roomArrayList.get(i).devices.get(6).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(8)));
////                                    roomArrayList.get(i).devices.get(7).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(9)));
////                                    roomArrayList.get(i).devices.get(8).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(10)));
////                                    roomArrayList.get(i).devices.get(9).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(11)));
////                                    roomArrayList.get(i).devices.get(10).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(12)));
////                                    roomArrayList.get(i).devices.get(11).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(13)));
////
////                                    roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 1).deviceOnOffState = Integer.valueOf(String.valueOf(data.charAt(14)));
////                                    roomArrayList.get(i).devices.get(roomArrayList.get(i).devices.size() - 1).deviceFanCurrentValue = Integer.valueOf(String.valueOf(data.charAt(15)));
////
////                                    updateOnDatabase(roomArrayList.get(i).devices);
////                                }
//                            }
//                        }
//                    }
//                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.e(TAG, "=======deliveryComplete==========");
            }
        });

        ivEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RoomNewActivity.this, EditRoomActivity.class);
                Bundle args = new Bundle();
                args.putSerializable(Constants.ROOMS, (Serializable) roomArrayList);
                args.putSerializable(Constants.TOPICS, topicsHelper);
                intent.putExtra("BUNDLE", args);
                startActivityForResult(intent, Constants.ROOM_ACTIVITY_REQUEST_CODE);
            }
        });

        ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                status = Networkstatus.getConnectivityStatusString(getApplicationContext());
                Log.e(TAG,"Status: " + status);
                if (status.equalsIgnoreCase("3")) {
                    Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "No Internet Connection, Please retry after connecting to internet", true, RoomNewActivity.this);
                }else {
                    deleteRoom();
                }
            }
        });

        ivRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSyncClicked();
            }
        });

        tvRoomName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog macIdDialog = new Dialog(RoomNewActivity.this);
                macIdDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                macIdDialog.setContentView(R.layout.mac_id_dialog);

                TextView tvMacID = macIdDialog.findViewById(R.id.tvMacID);
                TextView tvCopy = macIdDialog.findViewById(R.id.tvCopy);

                tvMacID.setText(MacId);

                tvCopy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ClipboardManager clipMan = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        ClipData clipData = ClipData.newPlainText("label", tvMacID.getText().toString());
                        clipMan.setPrimaryClip(clipData);

                        Toast.makeText(getApplicationContext(),"Text Copied",Toast.LENGTH_SHORT).show();
                        macIdDialog.dismiss();
                    }
                });
                macIdDialog.show();
            }
        });
    }

    private void getPin() {
        String firebaseUserId = EstonApp.preferenceGetString(PREF_USER_UID, "");
        DatabaseReference userRef = mFirebaseDatabase.child(firebaseUserId).child(Constants.SETTINGS.SETTINGS);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    Object td = dataSnapshot.getValue();
                    HashMap<String, String> settings = (HashMap<String, String>) td;
                    Log.e(TAG, "settings " + settings);
                    if (settings != null) {
                        if (settings.get(Constants.SETTINGS.PIN) != null && !Objects.requireNonNull(settings.get(Constants.SETTINGS.PIN)).isEmpty()) {
                            pin = settings.get(Constants.SETTINGS.PIN);
                        }
//                        if (settings.get(Constants.SETTINGS.MACID) != null && !Objects.requireNonNull(settings.get(Constants.SETTINGS.MACID)).isEmpty()) {
//                            MacId = settings.get(Constants.SETTINGS.MACID);
//                            initMqtt();
//                        } else {
//                            AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
//                            builder.setTitle("Error");
//                            builder.setCancelable(false);
//                            builder.setMessage("Can't fetch hub from server.\nPlease setup hub from settings!!");
//                            builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                                public void onClick(DialogInterface dialog, int id) {
//                                    onBackPressed();
//                                }
//                            });
//                            builder.show();
//                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Utils.dismissProgressDialog(progressDialog);
                Log.e(TAG, "error " + error.getMessage());
            }
        });
    }

    private static String convertStringArrayToString(String[] strArr, String delimiter) {
        StringBuilder sb = new StringBuilder();
        for (String str : strArr)
            sb.append(str).append(delimiter);
        return sb.substring(0, sb.length() - 1);
    }

    private void initMqtt() {
//        if (roomArrayList.size() > 0) {
//
//            String [] macIDs = new String[roomArrayList.size()];

            for (int i=0; i<roomArrayList.size(); i++){
                mqttHelper.subscribeTopic("/" + roomArrayList.get(i).roomUUID + "/RES");
                Log.e("RoomNewActivity",roomArrayList.get(i).roomUUID);
            }
//            mqttHelper.subscribeTopic(roomArrayList.get(0).getSubscribeAddress(convertStringArrayToString(macIDs,",")));
//        }
//        mqttHelper.subscribeTopic(topicsHelper.getSubscribeAddress(MacId));
    }

    private void updateOnDatabase(Room room, ArrayList<Device> devices) {
        try {
            for (int i = 0; i < devices.size(); i++) {
                Utils.getInstance().hideSoftKeyboard(RoomNewActivity.this);
                DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.ROOMS_TABLE.ROOMS)
                        .child(room.roomUUID)
                        .child(Constants.ROOMS_TABLE.DEVICES)
                        .child(String.valueOf(devices.get(i).did));
                namesRef.updateChildren(devices.get(i).toMap());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void onSyncClicked(){
        progressDialog = Utils.showProgressDialog(RoomNewActivity.this, "Syncing...", false);
        String msg = "*,SYNC=Y,#";
        Log.e(TAG,"Final_Msg: " + msg);
        mqttHelper.publishTopicWithListener(topicsHelper.getPublishControlAddress(MacId), msg, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Utils.dismissProgressDialog(progressDialog);
                Log.e(TAG, "Publish Success");
                updateOnDatabase(topicsHelper, topicsHelper.devices);
                mLastClickTime = SystemClock.elapsedRealtime();
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Utils.dismissProgressDialog(progressDialog);
                Log.e(TAG, "Publish Fail : " + exception);
                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Publish Failed", true, RoomNewActivity.this);
            }
        });
    }

    @Override
    public void onItemClick(Object item, int position) {

//        if (SystemClock.elapsedRealtime() - mLastClickTime < 2000) {
//            return;
//        }
//        mLastClickTime = SystemClock.elapsedRealtime();

        progressDialog = Utils.showProgressDialog(RoomNewActivity.this, "Updating...", false);
        String msg = topicsHelper.getControlString(topicsHelper.roomUUID, topicsHelper.devices, position, false, 0);
        Log.e(TAG,"Final_Msg: " + msg);
        mqttHelper.publishTopicWithListener(topicsHelper.getPublishControlAddress(MacId), msg, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Utils.dismissProgressDialog(progressDialog);
                Log.e(TAG, "Publish Success");
                if (((Device) item).deviceOnOffState == 1) {
                    ((Device) item).deviceOnOffState = 0;
                } else {
                    ((Device) item).deviceOnOffState = 1;
                }
                topicsHelper.devices.set(position, ((Device) item));
                roomDevicesListAdapter.notifyItemChanged(position);
                updateOnDatabase(topicsHelper, topicsHelper.devices);
                mLastClickTime = SystemClock.elapsedRealtime();
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Utils.dismissProgressDialog(progressDialog);
                Log.e(TAG, "Publish Fail : " + exception);
                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Publish Failed", true, RoomNewActivity.this);
            }
        });
    }

    public void deleteRoom(){
        AskFroPin askFroPin = new AskFroPin(this, "Verify Pin to Delete Room", new AskFroPin.AskForPinListener() {
            @Override
            public void onDone() {
                progressDialog = Utils.showProgressDialog(RoomNewActivity.this, "Deleting...", false);
                Utils.getInstance().hideSoftKeyboard(RoomNewActivity.this);
                DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.ROOMS_TABLE.ROOMS).child(topicsHelper.roomUUID);
                namesRef.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void runnable) {
                        Utils.dismissProgressDialog(progressDialog);
                        Toast.makeText(RoomNewActivity.this, "Room Deleted", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RoomNewActivity.this,MainActivity.class));
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception runnable) {
                        Utils.dismissProgressDialog(progressDialog);
                        Toast.makeText(RoomNewActivity.this, "Error " + runnable.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        askFroPin.show(pin);
    }

    public void onDeleteClick(int position) {
//        if (Utils.isNetworkAvailable(mContext)) {
        Device device = topicsHelper.devices.get(position);
        device.isDeleted = 1;
        AskFroPin askFroPin = new AskFroPin(this, "Verify Pin for delete device!", new AskFroPin.AskForPinListener() {
            @Override
            public void onDone() {
                progressDialog = Utils.showProgressDialog(RoomNewActivity.this, "Deleting...", false);
                Utils.getInstance().hideSoftKeyboard(RoomNewActivity.this);
                DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                        .child(Constants.ROOMS_TABLE.ROOMS)
                        .child(topicsHelper.roomUUID)
                        .child(Constants.ROOMS_TABLE.DEVICES)
                        .child(String.valueOf(device.did));
                namesRef.updateChildren(device.toMap());
                Utils.dismissProgressDialog(progressDialog);
                topicsHelper.devices.remove(position);
                roomDevicesListAdapter.notifyItemRemoved(position);

//                    namesRef.updateChildren(device.toMap()).addOnSuccessListener(new OnSuccessListener<Void>() {
//                        @Override
//                        public void onSuccess(Void runnable) {
//                            Utils.dismissProgressDialog(progressDialog);
//                            topicsHelper.devices.remove(position);
//                            roomDevicesListAdapter.notifyItemRemoved(position);
//                        }
//                    }).addOnFailureListener(new OnFailureListener() {
//                        @Override
//                        public void onFailure(Exception runnable) {
//                            Utils.dismissProgressDialog(progressDialog);
//                            if (runnable != null)
//                                Toast.makeText(RoomNewActivity.this, "Error " + runnable.getMessage(), Toast.LENGTH_SHORT).show();
//                            else
//                                Toast.makeText(RoomNewActivity.this, "Something was wrong, please try again later.", Toast.LENGTH_SHORT).show();
//                        }
//                    });
            }
        });
        askFroPin.show(pin);
//        } else {
//            Utils.showNoInternetDialog(this);
//        }
    }

    @Override
    public void onFanFunctionClick(Object item, Integer IsPlus, int position) {

        if (((Device) item).deviceOnOffState == 0) {
            Utils.showSnackbarNonSticky(recyclerView, "Fan is in off mode", true, RoomNewActivity.this);
            return;
        }

//        if (SystemClock.elapsedRealtime() - mLastClickTime < 2000) {
//            return;
//        }
//        mLastClickTime = SystemClock.elapsedRealtime();
        progressDialog = Utils.showProgressDialog(RoomNewActivity.this, "Updating...", false);

        int currentCount = 0;
        if (IsPlus == 1) {
            currentCount = ((Device) item).deviceFanCurrentValue + 1;
        } else {
            currentCount = ((Device) item).deviceFanCurrentValue - 1;
        }
        Integer finalCurrentCount = currentCount;
        String msg = topicsHelper.getControlString(topicsHelper.roomUUID, topicsHelper.devices, position, true, currentCount);
        mqttHelper.publishTopicWithListener(topicsHelper.getPublishControlAddress(MacId), msg, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Utils.dismissProgressDialog(progressDialog);
                Log.e(TAG, "Publish Success");
                ((Device) item).deviceFanCurrentValue = finalCurrentCount;
                topicsHelper.devices.set(position, ((Device) item));
                roomDevicesListAdapter.notifyItemChanged(position);
                updateOnDatabase(topicsHelper, topicsHelper.devices);
                mLastClickTime = SystemClock.elapsedRealtime();
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Utils.dismissProgressDialog(progressDialog);
                mLastClickTime = SystemClock.elapsedRealtime();
                Log.e(TAG, "Publish Fail : " + exception);
                Utils.showSnackbarNonSticky(recyclerView, "Publish Failed", true, RoomNewActivity.this);
            }
        });

    }

    public void showMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenuInflater().inflate(R.menu.room_options, popup.getMenu());
        try {
            Field[] fields = popup.getClass().getDeclaredFields();
            for (Field field : fields) {
                if ("mPopup".equals(field.getName())) {
                    field.setAccessible(true);
                    Object menuPopupHelper = field.get(popup);
                    Class<?> classPopupHelper = Class.forName(menuPopupHelper.getClass().getName());
                    Method setForceIcons = classPopupHelper.getMethod("setForceShowIcon", boolean.class);
                    setForceIcons.invoke(menuPopupHelper, true);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        popup.show();
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                if (item.getItemId() == R.id.edit) {
                    Intent intent = new Intent(RoomNewActivity.this, EditRoomActivity.class);
                    Bundle args = new Bundle();
                    args.putSerializable(Constants.ROOMS, (Serializable) roomArrayList);
                    args.putSerializable(Constants.TOPICS, topicsHelper);
                    intent.putExtra("BUNDLE", args);
                    startActivityForResult(intent, Constants.ROOM_ACTIVITY_REQUEST_CODE);
                    overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);

                } else if (item.getItemId() == R.id.delete) {

                    AskFroPin askFroPin = new AskFroPin(mContext, "Verify Pin", new AskFroPin.AskForPinListener() {
                        @Override
                        public void onDone() {
                            //progressDialog = Utils.showProgressDialog(mContext, "Deleting...", false);
                            Utils.getInstance().hideSoftKeyboard(RoomNewActivity.this);
                            DatabaseReference namesRef = mFirebaseDatabase
                                    .child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                                    .child(Constants.ROOMS_TABLE.ROOMS).child(topicsHelper.roomUUID);
                            namesRef.removeValue();
                            Utils.dismissProgressDialog(progressDialog);
                            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Room deleted.", false, RoomNewActivity.this);
                            onBackPressed();

//                            mqttHelper.publishTopicWithListener(topicsHelper.getPublishRemoveRoom(HubId), "R" + topicsHelper.roomUUID + "@", new IMqttActionListener() {
//                                @Override
//                                public void onSuccess(IMqttToken asyncActionToken) {
//                                    DatabaseReference namesRef = mFirebaseDatabase
//                                            .child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
//                                            .child(Constants.ROOMS_TABLE.ROOMS).child(topicsHelper.roomUUID);
//                                    namesRef.removeValue();
//                                    Utils.dismissProgressDialog(progressDialog);
//                                    Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Room deleted.", false, RoomNewActivity.this);
//                                    onBackPressed();
//
////                                    namesRef.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
////                                        @Override
////                                        public void onSuccess(Void runnable) {
////                                            Utils.dismissProgressDialog(progressDialog);
////                                            Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Room deleted.", false, RoomNewActivity.this);
////                                            onBackPressed();
////                                        }
////                                    }).addOnFailureListener(new OnFailureListener() {
////                                        @Override
////                                        public void onFailure(Exception runnable) {
////                                            Utils.dismissProgressDialog(progressDialog);
////                                            if (runnable != null)
////                                                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Network error " + runnable.getMessage(), true, RoomNewActivity.this);
////                                            else
////                                                Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Network error, Please try again later. ", true, RoomNewActivity.this);
////                                        }
////                                    });
//                                }
//
//                                @Override
//                                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
//                                    Log.e(TAG, "Publish Fail : " + exception);
//                                    Utils.dismissProgressDialog(progressDialog);
//                                    if (exception != null)
//                                        Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Network error " + exception.getMessage(), true, RoomNewActivity.this);
//                                    else
//                                        Utils.showSnackbarNonSticky(findViewById(android.R.id.content), "Network error, Please try again later. ", true, RoomNewActivity.this);
//                                }
//                            });
                        }
                    });
                    askFroPin.show(pin);
                }
                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "onActivityResult requestCode " + requestCode + " resultCode " + resultCode);
        if (requestCode == Constants.ROOM_ACTIVITY_REQUEST_CODE && resultCode == Constants.ROOM_ACTIVITY_RESULT_CODE) {
            assert data != null;
            Bundle args = data.getBundleExtra("BUNDLE");
            assert args != null;
            topicsHelper = (Room) args.getSerializable(Constants.TOPICS);
            roomArrayList = (ArrayList<Room>) args.getSerializable(Constants.ROOMS);

            initToolbar();
            initView();
        }
    }
}
