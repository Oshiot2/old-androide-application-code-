package com.eston.dialongs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.eston.R;
import com.eston.utils.Utils;
import com.google.android.material.textfield.TextInputEditText;


public class AskFroPin {
    private String msg;
    private AskForPinListener askForPinListener;
    private Context context;

    public AskFroPin(Context context, String msg, AskForPinListener askForPinListener) {
        this.context = context;
        this.msg = msg;
        this.askForPinListener = askForPinListener;
    }

    public void show(String pin) {

        Dialog wifiDialog = new Dialog(context);
        wifiDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        wifiDialog.setContentView(R.layout.verify_in_dialog);
        wifiDialog.setTitle(msg);

        final TextInputEditText password = wifiDialog.findViewById(R.id.password_id);
        Button connect = wifiDialog.findViewById(R.id.connect_button_id);
        TextView tvTitle = wifiDialog.findViewById(R.id.tvTitle);

        tvTitle.setText(msg);

        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String passwordValue = password.getText().toString().trim();
                if (TextUtils.isEmpty(passwordValue)) {
                    password.setError("Enter Pin");
                } else if (!passwordValue.equals(pin)) {
                    password.setError("Please enter correct pin");
                } else {
                    wifiDialog.dismiss();
                    askForPinListener.onDone();
                }
            }
        });
        wifiDialog.show();
    }

    public interface AskForPinListener {

        void onDone();

    }
}
