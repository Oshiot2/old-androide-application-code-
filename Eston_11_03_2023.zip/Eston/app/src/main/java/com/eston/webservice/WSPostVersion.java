package com.eston.webservice;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

import okhttp3.FormBody;
import okhttp3.RequestBody;

public class WSPostVersion {

    private String TAG = WSPostVersion.class.getName();
    private Context context;
    private String message = "";
    private int status = 0;
    private boolean success;
    private String zip_file_url = "";

    public WSPostVersion(Context context) {
        this.context = context;
    }

    public int getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public boolean isSuccess() {
        return success;
    }

    public String executeService(final String version) {

        final String url = WSConstants.BASE_URL + WSConstants.METHOD_POST_CHECK_VERSION;
        Log.e(TAG, "URL ==>  " + url);
        final String response = new WSUtils().callServiceHttpPost(context, url, generateJsonBody(version));
        Log.e(TAG, "Response ==>  " + response);
        return parseResponse(response);
    }

    /*
    This method is used to generate the json body for Add Video
   */
    private RequestBody generateJsonBody(String version) {

        return new FormBody.Builder()
                .add(WSConstants.VERSION, version)
                .build();
    }

    private String parseResponse(final String response) {

        if (response != null && response.trim().length() > 0) {
            try {

                final JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.length() > 0) {

                    message = jsonObject.optString(WSConstants.PARAMS_MESSAGE);
                    status = jsonObject.getInt(WSConstants.PARAMS_CODE);

                    if (status == (WSConstants.PARAMS_SUCCESS)) {
                        success = true;
                        JSONObject result = jsonObject.getJSONObject(WSConstants.PARAMS_RESULT);
                        String version = result.getString(WSConstants.VERSION);
                        String fileName = result.getString(WSConstants.PARAMS_ZIP_FILE);
                        zip_file_url = WSConstants.BASE_URL + WSConstants.APPEND_FILE_PATH + fileName;
                        Log.e(TAG, "=====URL=======" + zip_file_url);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return zip_file_url;
    }
}
