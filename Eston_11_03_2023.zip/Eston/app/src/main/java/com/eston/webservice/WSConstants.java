package com.eston.webservice;

/**
 * Created by techno-30 on 24/1/18.
 */

public interface WSConstants {

    long CONNECTION_TIMEOUT = 12000;
    long OTA_TIMEOUT = 120000;

    String BASE_URL = "http://design.technostacks.com/"; //Live

    String WIFI_SETUP = "http://192.168.4.1/wifisave?";

    String PARAM_SLASH = "/";

    String PARAMS_CODE = "response_code";
    String PARAMS_MESSAGE = "msg";
    String PARAMS_RESULT = "result";
    String PARAMS_ZIP_FILE = "zip_file";
    int PARAMS_SUCCESS = 200;

    // Version API
    String METHOD_POST_CHECK_VERSION = "versionapi/checkversion.php";

    // URL for .bin File Update in Local
    String HTTP = "http://";

    //String LOCAL_UPDATE_FILE = "http://192.168.43.204/update";
    String LOCAL_USERNAME = "technostacks";
    String LOCAL_PASSWORD = "technoota";

    // Append Zip File Path
    String APPEND_FILE_PATH = "versionapi/uploads/";

    // Params
    String VERSION = "version";
    String UPDATE = "update";

}
