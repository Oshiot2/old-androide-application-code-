package com.eston.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class Networkstatus {

    public static int TYPE_WIFI = 1;
    public static int TYPE_MOBILE = 2;
    public static int TYPE_NOT_CONNECTED = 0;

    public static int getConnectivityStatus(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (null != activeNetwork) {
            if(activeNetwork.getType() == ConnectivityManager.TYPE_WIFI)
                return TYPE_WIFI;

            if(activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE)
                return TYPE_MOBILE;
        }
        return TYPE_NOT_CONNECTED;
    }

    public static String getConnectivityStatusString(Context context) {
        int conn = Networkstatus.getConnectivityStatus(context);
        String status = null;
        if (conn == Networkstatus.TYPE_WIFI) {
            status = "1"; //Wifi is detected
        } else if (conn == Networkstatus.TYPE_MOBILE) {
            status = "2"; //Mobile data connection is detected
        } else if (conn == Networkstatus.TYPE_NOT_CONNECTED) {
            status = "3"; //Not connected to Internetconnection
        }
        return status;
    }

}
