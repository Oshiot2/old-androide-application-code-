package com.eston.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.eston.EstonApp;
import com.eston.R;
import com.eston.adapter.DeviceSelectionExpandableListAdapter;
import com.eston.dataBase.model.Device;
import com.eston.dataBase.model.Room;
import com.eston.utils.Constants;
import com.eston.utils.Utils;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

import static com.eston.utils.Constants.USERDATA.PREF_USER_UID;

public class RoomSelectionForSchedulerActivity extends AppCompatActivity {

    private String TAG = RoomSelectionForSchedulerActivity.class.getName();

    private Context mContext;
    private TextView toolbar_Title;
    private ExpandableListView expListView;
    private ProgressBar progressRoom;
    private TextView txt_NoROOM;

    DeviceSelectionExpandableListAdapter listAdapter;
    ArrayList<Room> roomArrayList = new ArrayList<>();
    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_trans_right_in, R.anim.anim_trans_right_out);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(Utils.getCurrentTheme());
        setContentView(R.layout.activity_room_selection2);

        mContext = this;

        /*
         * Init Toolbar
         * */
        initToolbar();

        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference("users");
        mFirebaseDatabase.keepSynced(true);

        expListView = findViewById(R.id.lvExp_Devices_select);
        progressRoom = findViewById(R.id.progressRoom);
        txt_NoROOM = findViewById(R.id.txt_NoROOM);
        getRoomList();
    }

    private void initToolbar() {
        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        toolbar_Title = findViewById(R.id.txt_title);
        toolbar_Title.setText("Select Device");

    }

    private void initView() {

        if (roomArrayList.size() <= 0) {
            txt_NoROOM.setVisibility(View.VISIBLE);
            expListView.setVisibility(View.GONE);
            progressRoom.setVisibility(View.GONE);
            return;
        }

        listAdapter = new DeviceSelectionExpandableListAdapter(this, roomArrayList);
        expListView.setAdapter(listAdapter);
        expListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                return false;
            }
        });
        expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
            }
        });
        expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {

            }
        });
        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                Intent intent = new Intent(RoomSelectionForSchedulerActivity.this, CreateSchedulerActivity.class);
                Bundle args = new Bundle();
                args.putSerializable(Constants.ROOMS, (Serializable) roomArrayList);
                args.putSerializable(Constants.GROUP_POS, groupPosition);
                args.putSerializable(Constants.CHILD_POS, childPosition);
                intent.putExtra("BUNDLE", args);
                startActivityForResult(intent, Constants.ROOM_ACTIVITY_REQUEST_CODE);
                overridePendingTransition(R.anim.anim_trans_left_in, R.anim.anim_trans_left_out);
                return false;
            }
        });
    }

    private void getRoomList() {

        DatabaseReference namesRef = mFirebaseDatabase.child(EstonApp.preferenceGetString(PREF_USER_UID, ""))
                .child(Constants.ROOMS_TABLE.ROOMS);

        namesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.getValue() != null) {
                    roomArrayList = new ArrayList<Room>();
                    for (DataSnapshot child : snapshot.getChildren()) {
                        try {
                            Room room = child.getValue(Room.class);
                            ArrayList<Device> devices = new ArrayList<Device>();
                            for (int i = 0; i < room.devices.size(); i++) {
                                if (room.devices.get(i) != null && room.devices.get(i).isDeleted == 0)
                                    devices.add(room.devices.get(i));
                            }
                            room.devices = devices;
                            roomArrayList.add(room);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    initView();
                    txt_NoROOM.setVisibility(View.GONE);
                    expListView.setVisibility(View.VISIBLE);
                    progressRoom.setVisibility(View.GONE);
                } else {
                    txt_NoROOM.setText("Please create room from settings");
                    txt_NoROOM.setVisibility(View.VISIBLE);
                    expListView.setVisibility(View.GONE);
                    progressRoom.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                txt_NoROOM.setText("Network error " + error.getMessage());
                txt_NoROOM.setVisibility(View.VISIBLE);
                expListView.setVisibility(View.GONE);
                progressRoom.setVisibility(View.GONE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "onActivityResult requestCode " + requestCode + " resultCode " + resultCode);
        if (requestCode == Constants.ROOM_ACTIVITY_REQUEST_CODE && resultCode == Constants.ROOM_ACTIVITY_RESULT_CODE) {
            Intent returnIntent = new Intent();
            setResult(Constants.ROOM_ACTIVITY_RESULT_CODE, returnIntent);
            onBackPressed();
        }
    }
}
